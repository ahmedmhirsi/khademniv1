<?php
include '../offer/db_connect.php';

session_start();

// Vérifier si l'utilisateur est connecté
$user_id = null;
$user = null;
$userFavorites = [];

if (isset($_SESSION['user_id'])) {
    $user_id = $_SESSION['user_id'];

    // Récupérer les informations de l'utilisateur connecté
    $query = "SELECT * FROM users WHERE user_id = :user_id";
    $stmt = $pdo->prepare($query);
    $stmt->execute([':user_id' => $user_id]);
    $user = $stmt->fetch(PDO::FETCH_ASSOC);

}

?>
<!doctype html>
<html lang="en" dir="ltr" data-bs-theme="auto">
<head>

    <!-- Include JavaScript for color modes -->
    <script src="./assets/js/color-modes.js"></script>

    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- Update the 'content' attribute to reflect the actual content description -->
    <meta name="description" content="your_description_goes_here">

    <!-- Modify the 'content' attribute to include appropriate keywords -->
    <meta name="keywords" content="your_keywords_goes_here">

    <meta name="author" content="tigmatemplate">
    <meta name="generator" content="Bootstrap">

    <!-- Change the text within the <title> tag to match the webpage's content -->
    <title>Khademni - Paiment</title>

    <!-- 
        Set the website's favicon and Apple touch icon using the files in the assets/logo folder. You can change these files to your own icons by replacing them with the same names and sizes.

        Be careful if you change the site.webmanifest file, as you need to update the src attribute of the icons array to match the new path of your icon files. Otherwise, your icons may not display correctly on some devices. 
    -->

	<link rel="manifest" href="./assets/logo/site.webmanifest">

    <!-- Stylesheets -->
    <link rel="stylesheet" href="./assets/libraries/aos/aos.css">
    <link rel="stylesheet" href="./assets/css/main.min.css">
    <link rel="stylesheet" href="./assets/css/style.css">

    <!-- Open Graph Meta Tags for Social Sharing -->
    <!-- Update the 'title' and 'description' content below to enhance social sharing -->
    <meta property="og:title" content="your_title_goes_here">
    <meta property="og:description" content="your_description_goes_here">
    <!-- Update with actual absolute image URL like: https://example.com/main.jpg -->
    <meta property="og:image" content="your_absolute_image_url_goes_here">
    <!-- Update with the absolute URL of the content like: https://example.com/index.html -->
    <meta property="og:url" content="your_absolute_content_url_goes_here">
    <!-- Update with the type of object you’re sharing. (e.g., article, website, etc.) -->
    <meta property="og:type" content="website">
    <!-- Defines the content language -->
    <meta property="og:locale" content="en_US">

    
    <!-- X/Twitter Card Meta Tags for Social Sharing -->
    <meta name="twitter:card" content="summary_large_image">
    <!-- Update with your X/Twitter handle -->
    <meta name="twitter:site" content="@yourtwitterhandle"> 
    <!-- Update the 'title' and 'description' content below to enhance social sharing -->
    <meta name="twitter:title" content="your_title_goes_here"> 
    <meta name="twitter:description" content="your_description_goes_here">
    <!-- Update with actual absolute image URL like: https://example.com/main.jpg -->
    <meta name="twitter:image" content="your_absolute_image_url_goes_here"> 
    
    <!-- 
        The following line specifies the canonical URL for this page.
        Replace your_canonical_url_goes_here with the actual canonical URL if needed like: https://example.com/index.html
        Or just remove it!!!!
    -->
    <link rel="canonical" href="your_canonical_url_goes_here">
	<link rel="stylesheet" href="../offer/styles.css">

</head>
<body>
<header>
    <div class="logo">Khademni</div>
    <nav>
        <a href="../index.php" class="<?php echo basename($_SERVER['PHP_SELF']) == 'index.php' ? 'active' : ''; ?>">Home</a>
        <a href="list_jobs.php" class="<?php echo basename($_SERVER['PHP_SELF']) == 'list_jobs.php' ? 'active' : ''; ?>">Offres d'emploi</a>
        <a href="favorites.php" class="<?php echo basename($_SERVER['PHP_SELF']) == 'favorites.php' ? 'active' : ''; ?>">Favoris</a>
        <a href="../quiz/blog.php">Test & Quiz</a>
        <a href="../paiment/pricing.php">Paiment</a>

        <?php if ($isLoggedIn): ?>
            <div class="profile-menu">
                <img src="../user/controllers/<?php echo htmlspecialchars($user['pdp'] ?? ''); ?>" alt="Profile Picture" class="profile-pic" style="width: 100px; height: auto;">
                <div class="dropdown-menu">
                    <a href="../user/views/layouts/main.php">Voir Profil</a>
                    <a href="../user/controllers/logout.php">Se Déconnecter</a>
                </div>
            </div>
        <?php else: ?>
            <a href="../auth/login.php" class="button">Se connecter</a>
        <?php endif; ?>
    </nav>
</header>
	

		<div class="container my-5">
			<div class="row align-items-center align-items-xl-stretch flex-column flex-xl-row">
				<div class="col-12 col-sm-10 col-md-7 col-lg-6 col-xl-4 mt-5">
					<div class="p-5 h-100 d-flex flex-column bg-body-tertiary shadow rounded-4">
						<h2>Offre 100 khd</h2>
						<div class="my-2">
							<span class="fs-1 text-body-secondary fw-bold">10</span>
							<span class="fs-1 text-dak fw-bolder essential">dt</span>
						</div>
						<p class="lead">
							Commence sans engagement et explore les fonctionnalités de base. Idéal pour les nouveaux utilisateurs.

						</p>
						<hr class="opacity-10">
						<h4 class="my-4">Fonctionnalités incluses:</h4>
						<div class="my-1 text-body-secondary">
							<span class="text-primary">
								<svg xmlns="http://www.w3.org/2000/svg" width="25" height="25" fill="currentColor" class="bi bi-check" viewBox="0 0 16 16">
									<path d="M10.97 4.97a.75.75 0 0 1 1.07 1.05l-3.99 4.99a.75.75 0 0 1-1.08.02L4.324 8.384a.75.75 0 1 1 1.06-1.06l2.094 2.093 3.473-4.425a.267.267 0 0 1 .02-.022z"/>
								</svg>
							</span>
							<span>
								Accès limité à la plateforme							</span>
						</div>
						<div class="mt-2 text-body-secondary">
							<span class="text-primary">
								<svg xmlns="http://www.w3.org/2000/svg" width="25" height="25" fill="currentColor" class="bi bi-check" viewBox="0 0 16 16">
									<path d="M10.97 4.97a.75.75 0 0 1 1.07 1.05l-3.99 4.99a.75.75 0 0 1-1.08.02L4.324 8.384a.75.75 0 1 1 1.06-1.06l2.094 2.093 3.473-4.425a.267.267 0 0 1 .02-.022z"/>
								</svg>
							</span>
							<span>
								Création d’un profil de base							</span>
						</div>
						<div class="mt-2 text-body-secondary">
							<span class="text-primary">
								<svg xmlns="http://www.w3.org/2000/svg" width="25" height="25" fill="currentColor" class="bi bi-check" viewBox="0 0 16 16">
									<path d="M10.97 4.97a.75.75 0 0 1 1.07 1.05l-3.99 4.99a.75.75 0 0 1-1.08.02L4.324 8.384a.75.75 0 1 1 1.06-1.06l2.094 2.093 3.473-4.425a.267.267 0 0 1 .02-.022z"/>
								</svg>
							</span>
							<span>
								Voir les offres disponibles
							</span>
						</div>
						<div class="mt-2 text-body-secondary">
							<span class="text-primary">
								<svg xmlns="http://www.w3.org/2000/svg" width="25" height="25" fill="currentColor" class="bi bi-check" viewBox="0 0 16 16">
									<path d="M10.97 4.97a.75.75 0 0 1 1.07 1.05l-3.99 4.99a.75.75 0 0 1-1.08.02L4.324 8.384a.75.75 0 1 1 1.06-1.06l2.094 2.093 3.473-4.425a.267.267 0 0 1 .02-.022z"/>
								</svg>
							</span>
							<span>
								Postulation à une offre
							</span>
						</div>
						<div class="mt-auto">
							<button class="btn btn-primary text-white mt-4 w-100" onclick="window.location.href='frontend/index.html'">
								Start
							</button>
						</div>
					</div>
				</div>

				<div class="col-12 col-sm-10 col-md-7 col-lg-6 col-xl-4 mt-5 position-relative">
					<div class="p-5 h-100 d-flex flex-column bg-body-tertiary shadow rounded-4">
						<span class="badge position-absolute translate-middle top-0 start-75 text-bg-success px-3 py-2 rounded-4">Most Popular</span>
						<h2>Offre 300 khd</h2>
						<div class="my-2">
							<span class="fs-1 text-body-secondary fw-bold">15</span>
							<span class="fs-1 text-dak fw-bolder premium">dt</span>
						</div>
						<p class="lead">
							Parfait pour les utilisateurs réguliers. Bénéficiez de plus de fonctions pour booster votre productivité.
						</p>
						<hr class="opacity-10">
						<h4 class="my-4">Fonctionnalités incluses :	</h4>
						<div class="my-1 text-body-secondary">
							<span class="text-primary">
								<svg xmlns="http://www.w3.org/2000/svg" width="25" height="25" fill="currentColor" class="bi bi-check" viewBox="0 0 16 16">
									<path d="M10.97 4.97a.75.75 0 0 1 1.07 1.05l-3.99 4.99a.75.75 0 0 1-1.08.02L4.324 8.384a.75.75 0 1 1 1.06-1.06l2.094 2.093 3.473-4.425a.267.267 0 0 1 .02-.022z"/>
								</svg>
							</span>
							<span>
								Toutes les fonctions de l'offre gratuite							</span>
						</div>
						<div class="mt-2 text-body-secondary">
							<span class="text-primary">
								<svg xmlns="http://www.w3.org/2000/svg" width="25" height="25" fill="currentColor" class="bi bi-check" viewBox="0 0 16 16">
									<path d="M10.97 4.97a.75.75 0 0 1 1.07 1.05l-3.99 4.99a.75.75 0 0 1-1.08.02L4.324 8.384a.75.75 0 1 1 1.06-1.06l2.094 2.093 3.473-4.425a.267.267 0 0 1 .02-.022z"/>
								</svg>
							</span>
							<span>
								 Création de profil complet avec portfolio

							</span>
						</div>
						<div class="mt-2 text-body-secondary">
							<span class="text-primary">
								<svg xmlns="http://www.w3.org/2000/svg" width="25" height="25" fill="currentColor" class="bi bi-check" viewBox="0 0 16 16">
									<path d="M10.97 4.97a.75.75 0 0 1 1.07 1.05l-3.99 4.99a.75.75 0 0 1-1.08.02L4.324 8.384a.75.75 0 1 1 1.06-1.06l2.094 2.093 3.473-4.425a.267.267 0 0 1 .02-.022z"/>
								</svg>
							</span>
							<span>
								Possibilité de contacter directement les recruteurs							</span>
						</div>
						<div class="mt-2 text-body-secondary">
							<span class="text-primary">
								<svg xmlns="http://www.w3.org/2000/svg" width="25" height="25" fill="currentColor" class="bi bi-check" viewBox="0 0 16 16">
									<path d="M10.97 4.97a.75.75 0 0 1 1.07 1.05l-3.99 4.99a.75.75 0 0 1-1.08.02L4.324 8.384a.75.75 0 1 1 1.06-1.06l2.094 2.093 3.473-4.425a.267.267 0 0 1 .02-.022z"/>
								</svg>
							</span>
							<span>
								Accès aux statistiques de consultation de profil							</span>
						</div>
						<div class="mt-2 text-body-secondary">
							<span class="text-primary">
								<svg xmlns="http://www.w3.org/2000/svg" width="25" height="25" fill="currentColor" class="bi bi-check" viewBox="0 0 16 16">
									<path d="M10.97 4.97a.75.75 0 0 1 1.07 1.05l-3.99 4.99a.75.75 0 0 1-1.08.02L4.324 8.384a.75.75 0 1 1 1.06-1.06l2.094 2.093 3.473-4.425a.267.267 0 0 1 .02-.022z"/>
								</svg>
							</span>
							<span>
								Téléchargement de documents (CV, lettre de motivation, etc.)							</span>
						</div>
						<div class="mt-auto">
							<button class="btn btn-primary text-white mt-4 w-100" onclick="window.location.href='frontend/index.html'">
								Start
							</button>
						</div>
					</div>
				</div>

				<div class="col-12 col-sm-10 col-md-7 col-lg-6 col-xl-4 mt-5">
					<div class="p-5 h-100 d-flex flex-column bg-body-tertiary shadow rounded-4">
						<h2>Offre 600 khd</h2>
						<div class="my-2">
							<span class="fs-1 text-body-secondary fw-bold">30</span>
							<span class="fs-1 text-dak fw-bolder advanced">dt</span>
						</div>
						<p class="lead">
							Pour les pros qui ont besoin de tout. Accès complet, intégrations avancées et plus encore.</p>
						<hr class="opacity-10">
						<h4 class="my-4">Fonctionnalités incluses :</h4>
						<div class="my-1 text-body-secondary">
							<span class="text-primary">
								<svg xmlns="http://www.w3.org/2000/svg" width="25" height="25" fill="currentColor" class="bi bi-check" viewBox="0 0 16 16">
									<path d="M10.97 4.97a.75.75 0 0 1 1.07 1.05l-3.99 4.99a.75.75 0 0 1-1.08.02L4.324 8.384a.75.75 0 1 1 1.06-1.06l2.094 2.093 3.473-4.425a.267.267 0 0 1 .02-.022z"/>
								</svg>
							</span>
							<span>
								Toutes les fonctions de l’offre Business							</span>
						</div>
						<div class="mt-2 text-body-secondary">
							<span class="text-primary">
								<svg xmlns="http://www.w3.org/2000/svg" width="25" height="25" fill="currentColor" class="bi bi-check" viewBox="0 0 16 16">
									<path d="M10.97 4.97a.75.75 0 0 1 1.07 1.05l-3.99 4.99a.75.75 0 0 1-1.08.02L4.324 8.384a.75.75 0 1 1 1.06-1.06l2.094 2.093 3.473-4.425a.267.267 0 0 1 .02-.022z"/>
								</svg>
							</span>
							<span>
								Support téléphonique
							</span>
						</div>
						<div class="mt-2 text-body-secondary">
							<span class="text-primary">
								<svg xmlns="http://www.w3.org/2000/svg" width="25" height="25" fill="currentColor" class="bi bi-check" viewBox="0 0 16 16">
									<path d="M10.97 4.97a.75.75 0 0 1 1.07 1.05l-3.99 4.99a.75.75 0 0 1-1.08.02L4.324 8.384a.75.75 0 1 1 1.06-1.06l2.094 2.093 3.473-4.425a.267.267 0 0 1 .02-.022z"/>
								</svg>
							</span>
							<span>
								Intégrations API
							</span>
						</div>
						<div class="mt-2 text-body-secondary">
							<span class="text-primary">
								<svg xmlns="http://www.w3.org/2000/svg" width="25" height="25" fill="currentColor" class="bi bi-check" viewBox="0 0 16 16">
									<path d="M10.97 4.97a.75.75 0 0 1 1.07 1.05l-3.99 4.99a.75.75 0 0 1-1.08.02L4.324 8.384a.75.75 0 1 1 1.06-1.06l2.094 2.093 3.473-4.425a.267.267 0 0 1 .02-.022z"/>
								</svg>
							</span>
							<span>
								Mise à jour prioritaire des fonctionnalités
							</span>
						</div>
						<div class="mt-2 text-body-secondary">
							<span class="text-primary">
								<svg xmlns="http://www.w3.org/2000/svg" width="25" height="25" fill="currentColor" class="bi bi-check" viewBox="0 0 16 16">
									<path d="M10.97 4.97a.75.75 0 0 1 1.07 1.05l-3.99 4.99a.75.75 0 0 1-1.08.02L4.324 8.384a.75.75 0 1 1 1.06-1.06l2.094 2.093 3.473-4.425a.267.267 0 0 1 .02-.022z"/>
								</svg>
							</span>
							<span>
								Dashboard avancé
							</span>
						</div>
						<div class="mt-2 text-body-secondary">
							<span class="text-primary">
								<svg xmlns="http://www.w3.org/2000/svg" width="25" height="25" fill="currentColor" class="bi bi-check" viewBox="0 0 16 16">
									<path d="M10.97 4.97a.75.75 0 0 1 1.07 1.05l-3.99 4.99a.75.75 0 0 1-1.08.02L4.324 8.384a.75.75 0 1 1 1.06-1.06l2.094 2.093 3.473-4.425a.267.267 0 0 1 .02-.022z"/>
								</svg>
							</span>
							<span>
								Téléchargement illimité
							</span>
						</div>
						<div class="mt-auto">
							<button class="btn btn-primary text-white mt-4 w-100" onclick="window.location.href='frontend/index.html'">
								Start
							</button>
						</div>
					</div>
				</div>
			</div>
		</div>
	</div>

	<!-- compare plans -->
	<div class="overflow-hidden py-5">
		<div class="container py-5">
			<div class="max-w-2xl pt-7 pb-9">
				<h2 class="m-0 text-primary-emphasis text-base leading-7 fw-semibold">
					Compare plans by features
				</h2>
				<div class="m-0 mt-2 text-body-emphasis text-4xl leading-snug tracking-tight fw-bold">
					You have Free Unlimited Updates and Premium Support on each package.
				</div>
			</div>


			<div class="overflow-auto overflow-xl-hidden">
				<div style="min-width: 1000px !important;">
					<div class="row align-items-center py-2 fw-bolder">
						<div class="col-6 fs-3">
							Tigma Essential
						</div>
						<div class="col-2">
							Essential
						</div>
						<div class="col-2">
							Premium
						</div>
						<div class="col-2">
							Advanced
						</div>
					</div>
					<hr class="opacity-10">

					<div class="row py-2">
						<div class="col-6 fw-bold">
							<div class="row">
								<div class="col-8">
									Monthly fees
								</div>
								<div class="col-4">
									<a href="javascript:;" data-bs-toggle="tooltip" data-bs-title="Keep team shipping simple and take control of your company." class="text-body-secondary">
										<svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" fill="currentColor" class="bi bi-main-circle" viewBox="0 0 16 16">
											<path d="M8 15A7 7 0 1 1 8 1a7 7 0 0 1 0 14zm0 1A8 8 0 1 0 8 0a8 8 0 0 0 0 16z"/>
											<path d="m8.93 6.588-2.29.287-.082.38.45.083c.294.07.352.176.288.469l-.738 3.468c-.194.897.105 1.319.808 1.319.545 0 1.178-.252 1.465-.598l.088-.416c-.2.176-.492.246-.686.246-.275 0-.375-.193-.304-.533L8.93 6.588zM9 4.5a1 1 0 1 1-2 0 1 1 0 0 1 2 0z"/>
										</svg>
									</a>
								</div>
							</div>
						</div>
						<div class="col-2 text-body-secondary">
							10dt/mois
						</div>
						<div class="col-2 text-body-secondary">
							15dt/mois
						</div>
						<div class="col-2 text-body-secondary">
							30dt/mois
						</div>
					</div>
					<hr class="opacity-10">

					<div class="row py-2">
						<div class="col-6 fw-bold">
							<div class="row">
								<div class="col-8">
									Postulation sur les offres
								</div>
								<div class="col-4">
									<a href="javascript:;" data-bs-toggle="tooltip" data-bs-title="Keep team shipping simple and take control of your company." class="text-body-secondary">
										<svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" fill="currentColor" class="bi bi-main-circle" viewBox="0 0 16 16">
											<path d="M8 15A7 7 0 1 1 8 1a7 7 0 0 1 0 14zm0 1A8 8 0 1 0 8 0a8 8 0 0 0 0 16z"/>
											<path d="m8.93 6.588-2.29.287-.082.38.45.083c.294.07.352.176.288.469l-.738 3.468c-.194.897.105 1.319.808 1.319.545 0 1.178-.252 1.465-.598l.088-.416c-.2.176-.492.246-.686.246-.275 0-.375-.193-.304-.533L8.93 6.588zM9 4.5a1 1 0 1 1-2 0 1 1 0 0 1 2 0z"/>
										</svg>
									</a>
								</div>
							</div>
						</div>
						<div class="col-2 text-primary">
							<svg xmlns="http://www.w3.org/2000/svg" width="25" height="25" fill="currentColor" class="bi bi-check" viewBox="0 0 16 16">
								<path d="M10.97 4.97a.75.75 0 0 1 1.07 1.05l-3.99 4.99a.75.75 0 0 1-1.08.02L4.324 8.384a.75.75 0 1 1 1.06-1.06l2.094 2.093 3.473-4.425a.267.267 0 0 1 .02-.022z"/>
							</svg>
						</div>
						<div class="col-2 text-primary">
							<svg xmlns="http://www.w3.org/2000/svg" width="25" height="25" fill="currentColor" class="bi bi-check" viewBox="0 0 16 16">
								<path d="M10.97 4.97a.75.75 0 0 1 1.07 1.05l-3.99 4.99a.75.75 0 0 1-1.08.02L4.324 8.384a.75.75 0 1 1 1.06-1.06l2.094 2.093 3.473-4.425a.267.267 0 0 1 .02-.022z"/>
							</svg>
						</div>
						<div class="col-2 text-primary">
							<svg xmlns="http://www.w3.org/2000/svg" width="25" height="25" fill="currentColor" class="bi bi-check" viewBox="0 0 16 16">
								<path d="M10.97 4.97a.75.75 0 0 1 1.07 1.05l-3.99 4.99a.75.75 0 0 1-1.08.02L4.324 8.384a.75.75 0 1 1 1.06-1.06l2.094 2.093 3.473-4.425a.267.267 0 0 1 .02-.022z"/>
							</svg>
						</div>
					</div>
					<hr class="opacity-10">
					
					<div class="row py-2">
						<div class="col-6 fw-bold">
							<div class="row">
								<div class="col-8">
									Création de profil
								</div>
								<div class="col-4">
									<a href="javascript:;" data-bs-toggle="tooltip" data-bs-title="Keep team shipping simple and take control of your company." class="text-body-secondary">
										<svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" fill="currentColor" class="bi bi-main-circle" viewBox="0 0 16 16">
											<path d="M8 15A7 7 0 1 1 8 1a7 7 0 0 1 0 14zm0 1A8 8 0 1 0 8 0a8 8 0 0 0 0 16z"/>
											<path d="m8.93 6.588-2.29.287-.082.38.45.083c.294.07.352.176.288.469l-.738 3.468c-.194.897.105 1.319.808 1.319.545 0 1.178-.252 1.465-.598l.088-.416c-.2.176-.492.246-.686.246-.275 0-.375-.193-.304-.533L8.93 6.588zM9 4.5a1 1 0 1 1-2 0 1 1 0 0 1 2 0z"/>
										</svg>
									</a>
								</div>
							</div>
						</div>
						<div class="col-2 text-primary">
							<svg xmlns="http://www.w3.org/2000/svg" width="25" height="25" fill="currentColor" class="bi bi-check" viewBox="0 0 16 16">
								<path d="M10.97 4.97a.75.75 0 0 1 1.07 1.05l-3.99 4.99a.75.75 0 0 1-1.08.02L4.324 8.384a.75.75 0 1 1 1.06-1.06l2.094 2.093 3.473-4.425a.267.267 0 0 1 .02-.022z"/>
							</svg>
							
						</div>
						<div class="col-2 text-primary">
							<svg xmlns="http://www.w3.org/2000/svg" width="25" height="25" fill="currentColor" class="bi bi-check" viewBox="0 0 16 16">
								<path d="M10.97 4.97a.75.75 0 0 1 1.07 1.05l-3.99 4.99a.75.75 0 0 1-1.08.02L4.324 8.384a.75.75 0 1 1 1.06-1.06l2.094 2.093 3.473-4.425a.267.267 0 0 1 .02-.022z"/>
							</svg>
						</div>
						<div class="col-2 text-primary">
							<svg xmlns="http://www.w3.org/2000/svg" width="25" height="25" fill="currentColor" class="bi bi-check" viewBox="0 0 16 16">
								<path d="M10.97 4.97a.75.75 0 0 1 1.07 1.05l-3.99 4.99a.75.75 0 0 1-1.08.02L4.324 8.384a.75.75 0 1 1 1.06-1.06l2.094 2.093 3.473-4.425a.267.267 0 0 1 .02-.022z"/>
							</svg>
						</div>
					</div>
					<hr class="opacity-10">

					<div class="row py-2">
						<div class="col-6 fw-bold">
							
							
							<div class="row">
								<div class="col-8">
									Coins offerts								</div>
								<div class="col-4">
									<a href="javascript:;" data-bs-toggle="tooltip" data-bs-title="Keep team shipping simple and take control of your company." class="text-body-secondary">
										<svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" fill="currentColor" class="bi bi-main-circle" viewBox="0 0 16 16">
											<path d="M8 15A7 7 0 1 1 8 1a7 7 0 0 1 0 14zm0 1A8 8 0 1 0 8 0a8 8 0 0 0 0 16z"/>
											<path d="m8.93 6.588-2.29.287-.082.38.45.083c.294.07.352.176.288.469l-.738 3.468c-.194.897.105 1.319.808 1.319.545 0 1.178-.252 1.465-.598l.088-.416c-.2.176-.492.246-.686.246-.275 0-.375-.193-.304-.533L8.93 6.588zM9 4.5a1 1 0 1 1-2 0 1 1 0 0 1 2 0z"/>
										</svg>
									</a>
								</div>
							</div>
						</div>
						<div class="col-2 text-body-secondary">
						<p>100 khd</p>
						</div>
						<div class="col-2 text-body-secondary">
							300 khd
						</div>
						<div class="col-2 text-body-secondary">
							600 khd
						</div>
					</div>
					<hr class="opacity-10">

					<div class="row py-2">
						<div class="col-6 fw-bold">
							<div class="row">
								<div class="col-8">
									Accès aux offres premium								</div>
								<div class="col-4">
									<a href="javascript:;" data-bs-toggle="tooltip" data-bs-title="Keep team shipping simple and take control of your company." class="text-body-secondary">
										<svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" fill="currentColor" class="bi bi-main-circle" viewBox="0 0 16 16">
											<path d="M8 15A7 7 0 1 1 8 1a7 7 0 0 1 0 14zm0 1A8 8 0 1 0 8 0a8 8 0 0 0 0 16z"/>
											<path d="m8.93 6.588-2.29.287-.082.38.45.083c.294.07.352.176.288.469l-.738 3.468c-.194.897.105 1.319.808 1.319.545 0 1.178-.252 1.465-.598l.088-.416c-.2.176-.492.246-.686.246-.275 0-.375-.193-.304-.533L8.93 6.588zM9 4.5a1 1 0 1 1-2 0 1 1 0 0 1 2 0z"/>
										</svg>
									</a>
								</div>
							</div>
						</div>
						<div class="col-2 text-primary">
							
						</div>
						<div class="col-2 text-primary">
							<svg xmlns="http://www.w3.org/2000/svg" width="25" height="25" fill="currentColor" class="bi bi-check" viewBox="0 0 16 16">
								<path d="M10.97 4.97a.75.75 0 0 1 1.07 1.05l-3.99 4.99a.75.75 0 0 1-1.08.02L4.324 8.384a.75.75 0 1 1 1.06-1.06l2.094 2.093 3.473-4.425a.267.267 0 0 1 .02-.022z"/>
							</svg>
						</div>
						<div class="col-2 text-primary">
							<svg xmlns="http://www.w3.org/2000/svg" width="25" height="25" fill="currentColor" class="bi bi-check" viewBox="0 0 16 16">
								<path d="M10.97 4.97a.75.75 0 0 1 1.07 1.05l-3.99 4.99a.75.75 0 0 1-1.08.02L4.324 8.384a.75.75 0 1 1 1.06-1.06l2.094 2.093 3.473-4.425a.267.267 0 0 1 .02-.022z"/>
							</svg>
						</div>
					</div>
					<hr class="opacity-10">







	<!-- Back to top button -->
	<button type="button" class="btn btn-primary btn-back-to-top rounded-circle justify-content-center align-items-center p-2 text-white">
		<svg xmlns="http://www.w3.org/2000/svg" width="30" height="30" fill="currentColor" class="bi bi-arrow-up-short" viewBox="0 0 16 16"> <path fill-rule="evenodd" d="M8 12a.5.5 0 0 0 .5-.5V5.707l2.146 2.147a.5.5 0 0 0 .708-.708l-3-3a.5.5 0 0 0-.708 0l-3 3a.5.5 0 1 0 .708.708L7.5 5.707V11.5a.5.5 0 0 0 .5.5"/> </svg>
	</button>


	<!-- Bootstrap JavaScript: Bundle with Popper -->
	<script src="./assets/libraries/bootstrap/js/bootstrap.bundle.min.js"></script>
	<script src="./assets/libraries/aos/aos.js"></script>
	<script src="./assets/js/scripts.js"></script>


</body>
</html>