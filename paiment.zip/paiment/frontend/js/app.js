document.addEventListener('DOMContentLoaded', function() {
    const paymentForm = document.getElementById('payment-form');
    const paymentList = document.getElementById('payment-list');

    // Function to create a new payment
    paymentForm.addEventListener('submit', function(event) {
        event.preventDefault();
        const formData = new FormData(paymentForm);

        fetch('backend/controllers/PaymentController.php?action=create', {
            method: 'POST',
            body: formData
        })
        .then(response => response.json())
        .then(data => {
            if (data.success) {
                alert('Payment created successfully!');
                loadPayments();
                paymentForm.reset();
            } else {
                alert('Error creating payment: ' + data.message);
            }
        })
        .catch(error => console.error('Error:', error));
    });

    // Function to load payments
    function loadPayments() {
        fetch('backend/controllers/PaymentController.php?action=list')
        .then(response => response.json())
        .then(data => {
            paymentList.innerHTML = '';
            data.payments.forEach(payment => {
                const listItem = document.createElement('li');
                listItem.textContent = `Payment ID: ${payment.id}, Amount: ${payment.montant}`;
                const editButton = document.createElement('button');
                editButton.textContent = 'Edit';
                editButton.onclick = () => editPayment(payment.id);
                listItem.appendChild(editButton);
                paymentList.appendChild(listItem);
            });
        })
        .catch(error => console.error('Error:', error));
    }

    // Function to edit a payment
    function editPayment(paymentId) {
        // Logic to fetch payment details and populate the form for editing
        fetch(`backend/controllers/PaymentController.php?action=view&id=${paymentId}`)
        .then(response => response.json())
        .then(data => {
            if (data.success) {
                const payment = data.payment;
                paymentForm.elements['id'].value = payment.id;
                paymentForm.elements['montant'].value = payment.montant;
                // Populate other fields as necessary
            } else {
                alert('Error fetching payment details: ' + data.message);
            }
        })
        .catch(error => console.error('Error:', error));
    }

    // Initial load of payments
    loadPayments();
});

document.getElementById('createPaymentBtn').addEventListener('click', function () {
    window.location.href = 'create-payment.html';
});