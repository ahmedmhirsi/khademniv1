<?php
// filepath: c:\xampp\htdocs\valid\payment-processing-app\backend\delete_payment.php

// Database connection
try {
    $pdo = new PDO('mysql:host=localhost;dbname=khademni', 'root', '');
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
} catch (PDOException $e) {
    die("Database connection failed: " . $e->getMessage());
}

// Get payment ID and type
$id = $_GET['id'] ?? null;
$type = $_GET['type'] ?? null;

if ($id && $type) {
    if ($type === 'Carte Bancaire') {
        $stmt = $pdo->prepare("DELETE FROM paiement_bancaire WHERE id = :id");
    } elseif ($type === 'Virement') {
        $stmt = $pdo->prepare("DELETE FROM paiement_virement WHERE id = :id");
    } else {
        die("Invalid payment type.");
    }

    $stmt->execute([':id' => $id]);
}

// Redirect back to the list
header("Location: /backend/models/list-payments.php");
exit;
?>