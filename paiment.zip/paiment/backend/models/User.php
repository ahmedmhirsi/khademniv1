<?php
class User {
    private $id;
    private $nom;
    private $email;
    private $mot_de_passe;

    public function __construct($nom, $email, $mot_de_passe) {
        $this->nom = $nom;
        $this->email = $email;
        $this->mot_de_passe = password_hash($mot_de_passe, PASSWORD_DEFAULT);
    }

    public function getId() {
        return $this->id;
    }

    public function getNom() {
        return $this->nom;
    }

    public function getEmail() {
        return $this->email;
    }

    public function setNom($nom) {
        $this->nom = $nom;
    }

    public function setEmail($email) {
        $this->email = $email;
    }

    public function setMotDePasse($mot_de_passe) {
        $this->mot_de_passe = password_hash($mot_de_passe, PASSWORD_DEFAULT);
    }

    public function authenticate($mot_de_passe) {
        return password_verify($mot_de_passe, $this->mot_de_passe);
    }
}
?>