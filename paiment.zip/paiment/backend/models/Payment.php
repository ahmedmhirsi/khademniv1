<?php

class Payment {
    private $id;
    private $type;
    private $type_carte;
    private $numero_masque;
    private $nom_sur_carte;
    private $date_expiration;
    private $montant;
    private $user_id;
    private $date_paiement;

    public function __construct($id, $type, $type_carte, $numero_masque, $nom_sur_carte, $date_expiration, $montant, $user_id, $date_paiement) {
        $this->id = $id;
        $this->type = $type;
        $this->type_carte = $type_carte;
        $this->numero_masque = $numero_masque;
        $this->nom_sur_carte = $nom_sur_carte;
        $this->date_expiration = $date_expiration;
        $this->montant = $montant;
        $this->user_id = $user_id;
        $this->date_paiement = $date_paiement;
    }

    public function getId() {
        return $this->id;
    }

    public function getType() {
        return $this->type;
    }

    public function getTypeCarte() {
        return $this->type_carte;
    }

    public function getNumeroMasque() {
        return $this->numero_masque;
    }

    public function getNomSurCarte() {
        return $this->nom_sur_carte;
    }

    public function getDateExpiration() {
        return $this->date_expiration;
    }

    public function getMontant() {
        return $this->montant;
    }

    public function getUserId() {
        return $this->user_id;
    }

    public function getDatePaiement() {
        return $this->date_paiement;
    }

    public function setId($id) {
        $this->id = $id;
    }

    public function setType($type) {
        $this->type = $type;
    }

    public function setTypeCarte($type_carte) {
        $this->type_carte = $type_carte;
    }

    public function setNumeroMasque($numero_masque) {
        $this->numero_masque = $numero_masque;
    }

    public function setNomSurCarte($nom_sur_carte) {
        $this->nom_sur_carte = $nom_sur_carte;
    }

    public function setDateExpiration($date_expiration) {
        $this->date_expiration = $date_expiration;
    }

    public function setMontant($montant) {
        $this->montant = $montant;
    }

    public function setUserId($user_id) {
        $this->user_id = $user_id;
    }

    public function setDatePaiement($date_paiement) {
        $this->date_paiement = $date_paiement;
    }
}

?>