<?php
// filepath: c:\xampp\htdocs\valid\payment-processing-app\backend\get-payments.php

header('Content-Type: application/json');

try {
    // Connexion à la base de données
    $pdo = new PDO('mysql:host=localhost;dbname=khademni', username: 'root', password: '');
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

    // Requête pour récupérer les paiements
    $query = "
        SELECT id, 'Carte Bancaire' AS type, CONCAT('Card: ', numero_masque, ', Name: ', nom_sur_carte, ', Exp: ', date_expiration) AS details, montant, date_paiement
        FROM paiement_bancaire
        UNION ALL
        SELECT id, 'Virement' AS type, CONCAT('Bank: ', nom_banque, ', IBAN: ', iban, ', Holder: ', nom_titulaire) AS details, montant, date_paiement
        FROM paiement_virement
        ORDER BY date_paiement DESC
    ";
    $stmt = $pdo->query($query);

    // Renvoyer les données sous forme de JSON
    $payments = $stmt->fetchAll(PDO::FETCH_ASSOC);
    echo json_encode($payments);
} catch (PDOException $e) {
    echo json_encode(['error' => $e->getMessage()]);
}