<?php
// filepath: c:\xampp\htdocs\valid\payment-processing-app\backend\edit_payment.php

// Database connection
try {
    $pdo = new PDO('mysql:host=localhost;dbname=khademni', 'root', '');
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
} catch (PDOException $e) {
    die("Database connection failed: " . $e->getMessage());
}

// Get form data
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $id = $_POST['id'] ?? null;
    $type = $_POST['type'] ?? null;

    if ($type === 'Carte Bancaire') {
        $nom_sur_carte = $_POST['nom_sur_carte'] ?? '';
        $numero_masque = $_POST['numero_masque'] ?? '';
        $type_carte = $_POST['type_carte'] ?? '';
        $date_expiration = $_POST['date_expiration'] ?? '';
        $montant = $_POST['montant'] ?? '';

        $stmt = $pdo->prepare("UPDATE paiement_bancaire SET 
            nom_sur_carte = :nom_sur_carte, 
            numero_masque = :numero_masque, 
            type_carte = :type_carte, 
            date_expiration = :date_expiration, 
            montant = :montant 
            WHERE id = :id");
        $stmt->execute([
            ':nom_sur_carte' => $nom_sur_carte,
            ':numero_masque' => $numero_masque,
            ':type_carte' => $type_carte,
            ':date_expiration' => $date_expiration,
            ':montant' => $montant,
            ':id' => $id
        ]);
    } elseif ($type === 'Virement') {
        $nom_banque = $_POST['nom_banque'] ?? '';
        $iban = $_POST['iban'] ?? '';
        $nom_titulaire = $_POST['nom_titulaire'] ?? '';
        $montant = $_POST['montant'] ?? '';

        $stmt = $pdo->prepare("UPDATE paiement_virement SET 
            nom_banque = :nom_banque, 
            iban = :iban, 
            nom_titulaire = :nom_titulaire, 
            montant = :montant 
            WHERE id = :id");
        $stmt->execute([
            ':nom_banque' => $nom_banque,
            ':iban' => $iban,
            ':nom_titulaire' => $nom_titulaire,
            ':montant' => $montant,
            ':id' => $id
        ]);
    }

    // Redirect back to the list
    header("Location: /backend/models/list-payments.php");
    exit;
}
?>