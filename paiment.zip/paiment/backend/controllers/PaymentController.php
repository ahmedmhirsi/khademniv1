<?php
class PaymentController {
    private $db;

    public function __construct($database) {
        $this->db = $database;
    }

    public function createPayment($data) {
        $stmt = $this->db->prepare("INSERT INTO payments (type, type_carte, numero_masque, nom_sur_carte, date_expiration, montant, user_id, date_paiement) VALUES (?, ?, ?, ?, ?, ?, ?, ?)");
        return $stmt->execute([$data['type'], $data['type_carte'], $data['numero_masque'], $data['nom_sur_carte'], $data['date_expiration'], $data['montant'], $data['user_id'], $data['date_paiement']]);
    }

    public function editPayment($id, $data) {
        $stmt = $this->db->prepare("UPDATE payments SET type = ?, type_carte = ?, numero_masque = ?, nom_sur_carte = ?, date_expiration = ?, montant = ?, user_id = ?, date_paiement = ? WHERE id = ?");
        return $stmt->execute([$data['type'], $data['type_carte'], $data['numero_masque'], $data['nom_sur_carte'], $data['date_expiration'], $data['montant'], $data['user_id'], $data['date_paiement'], $id]);
    }

    public function deletePayment($id) {
        $stmt = $this->db->prepare("DELETE FROM payments WHERE id = ?");
        return $stmt->execute([$id]);
    }

    public function listPayments() {
        $stmt = $this->db->query("SELECT * FROM payments");
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }
}
?>