<!-- filepath: c:\xampp\htdocs\valid\payment-processing-app\frontend\views\list-payments.php -->
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>List Payments</title>
    <link rel="stylesheet" href="../frontend/css/styles.css">
    <style>
    body {
      background-color: #f9fafb;
      padding: 20px;
    }
    .table-container {
      background: white;
      padding: 20px;
      border-radius: 12px;
      box-shadow: 0 2px 8px rgba(0,0,0,0.1);
    }
    .btn-custom {
      border-radius: 8px;
    }
  </style>
</head>
<body>
    <div class="container">
        <h1>Payments List</h1>
        <table id="paymentsTable">
            <thead>
                <tr>
                    <th>ID</th>
                    <th>Type</th>
                    <th>Details</th>
                    <th>Amount</th>
                    <th>Date of Payment</th>
                    <th>Actions</th>
                </tr>
            </thead>
            <tbody>
                <?php
                // Database connection
                try {
                    $pdo = new PDO('mysql:host=localhost;dbname=khademni', 'root', '');
                    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
                } catch (PDOException $e) {
                    die("Database connection failed: " . $e->getMessage());
                }

                // Fetch payments from both tables
                $query = "
                    SELECT id, 'Carte Bancaire' AS type, CONCAT('Card: ', numero_masque, ', Name: ', nom_sur_carte, ', Exp: ', date_expiration) AS details, montant, date_paiement
                    FROM paiement_bancaire
                    UNION ALL
                    SELECT id, 'Virement' AS type, CONCAT('Bank: ', nom_banque, ', IBAN: ', iban, ', Holder: ', nom_titulaire) AS details, montant, date_paiement
                    FROM paiement_virement
                    ORDER BY date_paiement DESC
                ";
                $stmt = $pdo->query($query);

                // Display payments
                while ($row = $stmt->fetch(PDO::FETCH_ASSOC)) {
                    echo "<tr>";
                    echo "<td>{$row['id']}</td>";
                    echo "<td>{$row['type']}</td>";
                    echo "<td>{$row['details']}</td>";
                    echo "<td>{$row['montant']} DT</td>";
                    echo "<td>{$row['date_paiement']}</td>";
                    echo "<td>
                            <a href='../frontend/views/edit-payment.html?id={$row['id']}&type={$row['type']}'>Edit</a> |
                            <a href='../frontend/views/delete-payment.html?id={$row['id']}&type={$row['type']}' onclick='return confirm(\"Are you sure you want to delete this payment?\")'>Delete</a>
                          </td>";
                    echo "</tr>";
                }
                ?>
            </tbody>
        </table>
        <button id="createPaymentBtn" onclick="window.location.href='../frontend/views/create-payment.html'">Create New Payment</button>
    </div>
</body>
</html>