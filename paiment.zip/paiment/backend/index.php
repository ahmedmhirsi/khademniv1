<?php
require_once 'config/database.php';
require_once 'controllers/PaymentController.php';
require_once 'controllers/UserController.php';

$database = new Database();
$db = $database->getConnection();

$paymentController = new PaymentController($db);
$userController = new UserController($db);

$requestMethod = $_SERVER['REQUEST_METHOD'];
$requestUri = explode('/', trim($_SERVER['REQUEST_URI'], '/'));

if (count($requestUri) > 1) {
    $resource = $requestUri[1];

    switch ($resource) {
        case 'payments':
            switch ($requestMethod) {
                case 'GET':
                    if (isset($requestUri[2])) {
                        $paymentController->viewPayment($requestUri[2]);
                    } else {
                        $paymentController->listPayments();
                    }
                    break;
                case 'POST':
                    $paymentController->createPayment();
                    break;
                case 'PUT':
                    if (isset($requestUri[2])) {
                        $paymentController->editPayment($requestUri[2]);
                    }
                    break;
                case 'DELETE':
                    if (isset($requestUri[2])) {
                        $paymentController->deletePayment($requestUri[2]);
                    }
                    break;
                default:
                    http_response_code(405);
                    break;
            }
            break;

        case 'users':
            switch ($requestMethod) {
                case 'POST':
                    $userController->createUser();
                    break;
                case 'GET':
                    if (isset($requestUri[2])) {
                        $userController->getUser($requestUri[2]);
                    }
                    break;
                default:
                    http_response_code(405);
                    break;
            }
            break;

        default:
            http_response_code(404);
            break;
    }
} else {
    http_response_code(400);
}
?>