<?php
include '../controllers/favoritesController.php';
include '../models/favoritesModel.php';
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="../assets/css/styles.css">
                <link href="../../../iconn.png" rel="icon">

    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">

    <title>Mes Favoris</title>
</head>
<body>
<header>
            <div class="logo">Khademni</div>
            <nav>
                 <a href="../../../index.php" class="<?php echo basename($_SERVER['PHP_SELF']) == 'index.php' ? 'active' : ''; ?>">Home</a>
        <a href="listeView.php" class="<?php echo basename($_SERVER['PHP_SELF']) == 'list_jobs.php' ? 'active' : ''; ?>">Offres d'emploi</a>
        <a href="favoritesView.php" class="<?php echo basename($_SERVER['PHP_SELF']) == 'favorites.php' ? 'active' : ''; ?>">Favoris</a>
        <a href="../../../quiz/views/frontoffice/quiz_list.php" class="<?php echo basename($_SERVER['PHP_SELF']) == 'blog.php' ? 'active' : ''; ?>">Test & Quiz</a>
        <a href="../../../valid/payment-processing-app/frontend/index.php" class="<?php echo basename($_SERVER['PHP_SELF']) == 'pricing.php' ? 'active' : ''; ?>">Paiment</a>
                <?php if (isset($user['nom_utilisateur'])): ?>
                    <div class="profile-menu">
                    <img src="../../../user/controllers/<?php echo htmlspecialchars($user['pdp'] ?? ''); ?>" alt="Profile Picture" class="profile-pic" style="width: 100px; height: auto;">
                    <div class="dropdown-menu">
                <a href="../../../user/views/layouts/main/main.php">Voir Profil</a>
                <a href="../../../user/controllers/logout.php">Se Déconnecter</a>
                </div>
            </div>
                <?php else: ?>
                    <a href="../login/login.php" class="button">Se connecter</a>
                <?php endif; ?>
            </nav>
        </header>

    <main>
    <h2>Liste des favoris</h2>

    <div class="job-list" id="job-list">
        <?php foreach ($favoris as $offre): ?>
            <div class="job-card">
                <div class="job-header">
                    <h3 class="job-title"><?php echo htmlspecialchars($offre['titre']); ?></h3>
                    <!-- Icône étoile pour ajouter aux favoris -->
                    <i class="fa-star favorite-icon fas" data-offre-id="<?php echo $offre['id']; ?>"></i>
                </div>
                <p class="job-details">
                    <strong>Entreprise:</strong> <?php echo htmlspecialchars($offre['nom_utilisateur'] ?? ''); ?><br>
                    <strong>Description:</strong> <?php echo htmlspecialchars($offre['description'] ?? ''); ?><br>
                    <strong>Lieu:</strong> <?php echo htmlspecialchars($offre['adresse'] ?? 'Non spécifié'); ?><br>
                    <a href="job_detailsView.php?id=<?php echo $offre['id']; ?>">Voir les détails</a>
                </p>
                <img src="../../../user/controllers/<?php echo htmlspecialchars($offre['pdp'] ?? ''); ?>" alt="Logo de l'entreprise" style="width: 100px; height: 60px;"><br>
                </div>
        <?php endforeach; ?>
    </div>
    </main>
    <footer>
        <p>Contactez-nous : contact@jobfinder.com</p>
        <p><a href="about.html">À propos</a> | <a href="privacy.html">Politique de confidentialité</a></p>
    </footer>
    <script src="../assets/js/script.js"></script>

</body>
</html>