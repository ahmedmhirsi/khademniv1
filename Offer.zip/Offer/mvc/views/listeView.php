<?php
include '../controllers/listeController.php';
include '../models/listeModel.php';
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="../assets/css/styles.css">
            <link href="../../../iconn.png" rel="icon">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
    <title>Liste des offres d'emploi</title>
</head>
<body>
<header>
            <div class="logo">Khademni</div>
            <nav>
                 <a href="../../../index.php" class="<?php echo basename($_SERVER['PHP_SELF']) == 'index.php' ? 'active' : ''; ?>">Home</a>
        <a href="listeView.php" class="<?php echo basename($_SERVER['PHP_SELF']) == 'list_jobs.php' ? 'active' : ''; ?>">Offres d'emploi</a>
        <a href="favoritesView.php" class="<?php echo basename($_SERVER['PHP_SELF']) == 'favorites.php' ? 'active' : ''; ?>">Favoris</a>
        <a href="../../../quiz/views/frontoffice/quiz_list.php" class="<?php echo basename($_SERVER['PHP_SELF']) == 'blog.php' ? 'active' : ''; ?>">Test & Quiz</a>
        <a href="../../../valid/payment-processing-app/frontend/index.php" class="<?php echo basename($_SERVER['PHP_SELF']) == 'pricing.php' ? 'active' : ''; ?>">Paiment</a>
                <?php if (isset($user['username'])): ?>
                    <div class="profile-menu">
                    <img src="../../../user/controllers/<?php echo htmlspecialchars($user['pdp'] ?? ''); ?>" alt="Profile Picture" class="profile-pic" style="width: 100px; height: auto;">
                    <div class="dropdown-menu">
                <a href="../../../user/views/layouts/main/main.php">Voir Profil</a>
                <a href="../../../user/controllers/logout.php">Se Déconnecter</a>
                </div>
            </div>
                <?php else: ?>
                    <a href="../login/login.php" class="button">Se connecter</a>
                <?php endif; ?>
            </nav>
        </header>

<main>
    <h2>Liste des offres d'emploi</h2>
    <button class="filter-toggle" onclick="toggleFilterForm()">Filtrer par</button>
    <form method="GET" action="listeView.php" class="filter-form">
        <div class="filter-container">
            <div class="filter-group">
                <label for="titre">Titre :</label>
                <input type="text" id="titre" name="titre" value="<?php echo htmlspecialchars($titre); ?>">
            </div>
            <div class="filter-group">
                <label for="lieu">Lieu :</label>
                <input type="text" id="lieu" name="lieu" value="<?php echo htmlspecialchars($lieu); ?>">
            </div>
            <div class="filter-group">
                <label for="salaire">Salaire minimum :</label>
                <input type="number" id="salaire" name="salaire" value="<?php echo htmlspecialchars($salaire); ?>">
            </div>
            <div class="filter-group">
                <label for="contrat">Type de contrat :</label>
                <select id="contrat" name="contrat">
                    <option value="">Tous</option>
                    <option value="CDI" <?php if ($contrat == 'CDI') echo 'selected'; ?>>CDI</option>
                    <option value="CDD" <?php if ($contrat == 'CDD') echo 'selected'; ?>>CDD</option>
                    <option value="Stage" <?php if ($contrat == 'Stage') echo 'selected'; ?>>Stage</option>
                    <option value="Freelance" <?php if ($contrat == 'Freelance') echo 'selected'; ?>>Freelance</option>
                </select>
            </div>
            <button type="submit" class="button">Rechercher</button>
        </div>
    </form>

    <div class="sort-options">
        <span>Trier par :</span>
        <a href="listeView.php?sort=titre" class="<?php echo ($_GET['sort'] ?? '') == 'titre' ? 'active' : ''; ?>">Titre</a> |
        <a href="listeView.php?sort=salaire" class="<?php echo ($_GET['sort'] ?? '') == 'salaire' ? 'active' : ''; ?>">Salaire</a> |
        <a href="listeView.php?sort=contrat" class="<?php echo ($_GET['sort'] ?? '') == 'contrat' ? 'active' : ''; ?>">Type de contrat</a> |
        <a href="listeView.php?sort=entreprise" class="<?php echo ($_GET['sort'] ?? '') == 'entreprise' ? 'active' : ''; ?>">Nom de l'entreprise</a> |
        <a href="listeView.php?sort=datelimite" class="<?php echo ($_GET['sort'] ?? '') == 'datelimite' ? 'active' : ''; ?>">Date limite</a> |
        <a href="listeView.php?sort=experience" class="<?php echo ($_GET['sort'] ?? '') == 'experience' ? 'active' : ''; ?>">Expérience</a> |
        <a href="listeView.php?sort=postes" class="<?php echo ($_GET['sort'] ?? '') == 'postes' ? 'active' : ''; ?>">Nombre de postes</a>
    </div>

    <div class="job-list" id="job-list">
        <?php foreach ($offres as $offre): ?>
            <div class="job-card">
                <div class="job-header">
                    <h3 class="job-title"><?php echo htmlspecialchars($offre['titre']); ?></h3>
                    <?php if ($isLoggedIn): ?>
                        <!-- Icône des favoris -->
                        <i class="fa-star favorite-icon <?php echo in_array($offre['id'], $userFavorites) ? 'fas' : 'far'; ?>" 
                           title="Ajouter aux favoris" data-offre-id="<?php echo $offre['id']; ?>"></i>
                        <!-- Icône pour copier le lien -->
                        <div class="share-container">
                            <i class="fas fa-link copy-link-icon" onclick="toggleShareMenu(this)" title="Partager"></i>
                            <div class="share-menu">
                                <!-- Partager via Messenger -->
                                <a href="https://www.messenger.com/t/" 
                                   onclick="handleShareClick(event, '<?php echo 'http://' . $_SERVER['HTTP_HOST'] . '/khadm/Offer/job_details.php?id=' . $offre['id']; ?>')"
                                   target="_blank">
                                    <i class="fab fa-facebook-messenger"></i> Envoyer via Messenger
                                </a>
                                <!-- Partager sur Facebook -->
                                <a href="https://www.facebook.com/sharer/sharer.php?u=<?php echo urlencode('http://' . $_SERVER['HTTP_HOST'] . '/khadm/Offer/job_details.php?id=' . $offre['id']); ?>" 
                                   onclick="handleShareClick(event, '<?php echo 'http://' . $_SERVER['HTTP_HOST'] . '/khadm/Offer/job_details.php?id=' . $offre['id']; ?>')"
                                   target="_blank">
                                    <i class="fab fa-facebook"></i> Partager sur Facebook
                                </a>
                                <!-- Partager par Gmail -->
                                <a href="https://mail.google.com/mail/u/0/#inbox?compose=new <?php echo htmlspecialchars($offre['titre']); ?>&body=Voici une offre intéressante: <?php echo 'http://' . $_SERVER['HTTP_HOST'] . '/khadm/Offer/job_details.php?id=' . $offre['id']; ?>"
                                   onclick="handleShareClick(event, '<?php echo 'http://' . $_SERVER['HTTP_HOST'] . '/khadm/Offer/job_details.php?id=' . $offre['id']; ?>')">
                                    <i class="fas fa-envelope"></i> Partager par Gmail
                                </a>
                                <!-- Partager sur Instagram -->
                                <a href="https://www.instagram.com/direct/inbox/" 
                                   onclick="handleShareClick(event, '<?php echo 'http://' . $_SERVER['HTTP_HOST'] . '/khadm/Offer/job_details.php?id=' . $offre['id']; ?>')"
                                   target="_blank">
                                    <i class="fab fa-instagram"></i> Partager sur Instagram
                                </a>
                                <a href="#" 
       onclick="copyLink('<?php echo 'http://' . $_SERVER['HTTP_HOST'] . '/khadm/Offer/job_details.php?id=' . $offre['id']; ?>')">
        <i class="fas fa-copy"></i> Copier le lien
    </a>
                                
                            </div>
                        </div>
                    <?php endif; ?>
                </div>
                <p class="job-details">
                    <strong>Entreprise:</strong> <?php echo htmlspecialchars($offre['nom_utilisateur'] ?? ''); ?><br>
                    <strong>Description:</strong> <?php echo htmlspecialchars($offre['description'] ?? ''); ?><br>
                    <strong>Lieu:</strong> <?php echo htmlspecialchars($offre['adresse'] ?? 'Non spécifié'); ?><br>
                    <a href="job_detailsView.php?id=<?php echo $offre['id']; ?>">Voir les détails</a>
                </p>
                <div class="job-footer">
                    <img src="../../../user/controllers/<?php echo htmlspecialchars($offre['pdp'] ?? ''); ?>" alt="Logo de l'entreprise" style="width: 100px; height: 60px;"><br>
                    
                    <!-- Case à cocher pour la comparaison -->
                    <label>
                        <input type="checkbox" class="compare-checkbox" data-offre-id="<?php echo $offre['id']; ?>">
                        <i class="fas fa-balance-scale"></i> Ajouter à la comparaison
                    </label>
                    
                </div>
            </div>
        <?php endforeach; ?>
    </div>
    <br>
<center>
    <div class="compare-actions">
        <button id="compare-button" onclick="redirectToComparison()">Comparer les offres sélectionnées</button>
    </div></center>

    <div class="pagination">
        <?php for ($i = 1; $i <= $totalPages; $i++): ?>
            <a href="?page=<?php echo $i; ?>" class="<?php if ($i == $page) echo 'active'; ?>"><?php echo $i; ?></a>
        <?php endfor; ?>
    </div>
</main>

<footer>
    <p>Contactez-nous : contact@jobfinder.com</p>
    <p><a href="about.html">À propos</a> | <a href="privacy.html">Politique de confidentialité</a></p>
</footer>

<script src="../assets/js/script.js"></script>
</body>
</html>


