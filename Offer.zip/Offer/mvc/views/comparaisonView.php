<?php
include '../controllers/comparaisonController.php';
include '../models//comparaisonModel.php';
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="../assets/css/styles.css">
    <title>Comparaison des offres</title>
                <link href="../../../iconn.png" rel="icon">

    <style>
        .comparison-table {
            margin: 20px auto;
            width: 90%;
            max-width: 1200px;
            border-collapse: collapse;
            background-color: #fff;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
            border-radius: 8px;
            overflow: hidden;
        }

        .comparison-table table {
            width: 100%;
            border-collapse: collapse;
        }

        .comparison-table th, .comparison-table td {
            padding: 15px;
            text-align: center;
            border: 1px solid #ddd;
        }

        .comparison-table th {
            background-color:rgb(58, 110, 70);
            color: #fff;
            font-weight: bold;
        }

        .comparison-table tr:nth-child(even) {
            background-color: #f2f2f2;
        }

        .comparison-table tr:hover {
            background-color: #e9f5ff;
        }

        .comparison-table td {
            font-size: 14px;
            color: #555;
        }

        .comparison-table th:first-child, .comparison-table td:first-child {
            text-align: left;
            font-weight: bold;
            background-color: #f7f7f7;
        }

        .comparison-table th:first-child {
            background-color:rgb(58, 110, 70);
            color: #fff;
        }

        @media (max-width: 768px) {
            .comparison-table table {
                font-size: 12px;
            }

            .comparison-table th, .comparison-table td {
                padding: 10px;
            }
        }
    </style>
</head>
<body>
<header>
    <div class="logo">Khademni</div>
    <nav>
        <a href="../../../index.php" class="<?php echo basename($_SERVER['PHP_SELF']) == 'index.php' ? 'active' : ''; ?>">Home</a>
        <a href="listeView.php" class="<?php echo basename($_SERVER['PHP_SELF']) == 'list_jobs.php' ? 'active' : ''; ?>">Offres d'emploi</a>
        <a href="favoritesView.php" class="<?php echo basename($_SERVER['PHP_SELF']) == 'favorites.php' ? 'active' : ''; ?>">Favoris</a>
        <a href="../../../quiz/views/frontoffice/quiz_list.php" class="<?php echo basename($_SERVER['PHP_SELF']) == 'blog.php' ? 'active' : ''; ?>">Test & Quiz</a>
        <a href="../../../valid/payment-processing-app/frontend/index.php" class="<?php echo basename($_SERVER['PHP_SELF']) == 'pricing.php' ? 'active' : ''; ?>">Paiment</a>
        
        <?php if ($isLoggedIn): ?>
            <div class="profile-menu">
                <img src="../../../user/controllers/<?php echo htmlspecialchars($user['pdp'] ?? ''); ?>" alt="Profile Picture" class="profile-pic" style="width: 100px; height: auto;">
                <div class="dropdown-menu">
                    <a href="../../../user/views/layouts/main/main.php">Voir Profil</a>
                    <a href="../../../user/controllers/logout.php">Se Déconnecter</a>
                </div>
            </div>
        <?php else: ?>
            <a href="../auth/login.php" class="button">Se connecter</a>
        <?php endif; ?>
    </nav>
</header>
<br>
   <center> <h2>Comparaison des offres</h2></center>
    <div class="comparison-table">
        <table>
            <thead>
                <tr>
                    <th>Propriété</th>
                    <?php foreach ($offres as $offre): ?>
                        <th><?php echo htmlspecialchars($offre['titre']); ?></th>
                    <?php endforeach; ?>
                </tr>
            </thead>
            <tbody>
                <?php
                $fields = [
                    'titre' => 'Titre',
                    'description' => 'Description',
                    'competences' => 'Compétences',
                    'experience' => 'Expérience',
                    'contrat' => 'Type de contrat',
                    'salaire' => 'Salaire',
                    'date_limite' => 'Date limite',
                    'nom_entreprise' => 'Nom de l\'entreprise',
                    'secteur' => 'Secteur',
                    'adresse' => 'Adresse',
                    'email_contact' => 'Email de contact',
                    'telephone' => 'Téléphone',
                    'site_web' => 'Site web',
                    'lieu_travail' => 'Lieu de travail',
                    'horaires' => 'Horaires',
                    'nombre_postes' => 'Nombre de postes',
                    'documents' => 'Documents requis',
                    'date_creation' => 'Date de création',
                ];

                foreach ($fields as $field => $label): ?>
                    <tr>
                        <td><?php echo $label; ?></td>
                        <?php foreach ($offres as $offre): ?>
                            <td><?php echo htmlspecialchars($offre[$field] ?? 'Non spécifié'); ?></td>
                        <?php endforeach; ?>
                    </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    </div>
    <footer>
    <p>Contactez-nous : contact@jobfinder.com</p>
    <p><a href="about.html">À propos</a> | <a href="privacy.html">Politique de confidentialité</a></p>
</footer>
</body>
</html>