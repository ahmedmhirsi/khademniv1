<?php
include '../controllers/job_detailsController.php';
include '../models/job_detailsModel.php';
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="../assets/css/detail.css">
                <link href="../../../iconn.png" rel="icon">

    <title>Détails de l'offre d'emploi</title>
    <style>
        /* Style pour la section des formations recommandées */
.recommended-trainings {
    background-color: #f9f9f9;
    padding: 20px;
    border-radius: 8px;
    margin-top: 20px;
    box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
}

.recommended-trainings h3 {
    font-size: 1.8em;
    color: #333;
    margin-bottom: 15px;
    border-bottom: 2px solid #007bff;
    display: inline-block;
    padding-bottom: 5px;
}

.recommended-trainings ul {
    list-style-type: none;
    padding: 0;
}

.recommended-trainings li {
    background-color: #fff;
    border: 1px solid #ddd;
    border-radius: 8px;
    margin-bottom: 15px;
    padding: 15px;
    transition: transform 0.2s, box-shadow 0.2s;
}

.recommended-trainings li:hover {
    transform: translateY(-5px);
    box-shadow: 0 6px 10px rgba(0, 0, 0, 0.15);
}

.recommended-trainings h4 {
    font-size: 1.5em;
    color: #007bff;
    margin-bottom: 10px;
}

.recommended-trainings p {
    margin: 5px 0;
    color: #555;
}

.recommended-trainings a {
    display: inline-block;
    margin-top: 10px;
    color: #fff;
    background-color: #007bff;
    padding: 8px 12px;
    border-radius: 5px;
    text-decoration: none;
    transition: background-color 0.2s;
}

.recommended-trainings a:hover {
    background-color: #0056b3;
}
    </style>
</head>
<body>
<header>
            <div class="logo">Khademni</div>
            <nav>
                 <a href="../../../index.php" class="<?php echo basename($_SERVER['PHP_SELF']) == 'index.php' ? 'active' : ''; ?>">Home</a>
        <a href="listeView.php" class="<?php echo basename($_SERVER['PHP_SELF']) == 'list_jobs.php' ? 'active' : ''; ?>">Offres d'emploi</a>
        <a href="favoritesView.php" class="<?php echo basename($_SERVER['PHP_SELF']) == 'favorites.php' ? 'active' : ''; ?>">Favoris</a>
        <a href="../../../quiz/views/frontoffice/quiz_list.php" class="<?php echo basename($_SERVER['PHP_SELF']) == 'blog.php' ? 'active' : ''; ?>">Test & Quiz</a>
        <a href="../../../valid/payment-processing-app/frontend/index.php" class="<?php echo basename($_SERVER['PHP_SELF']) == 'pricing.php' ? 'active' : ''; ?>">Paiment</a>
                <?php if (isset($user['nom_utilisateur'])): ?>
                    <div class="profile-menu">
                    <img src="../../../user/controllers/<?php echo htmlspecialchars($user['pdp'] ?? ''); ?>" alt="Profile Picture" class="profile-pic" style="width: 100px; height: auto;">
                    <div class="dropdown-menu">
                <a href="../../../user/views/layouts/main/main.php">Voir Profil</a>
                <a href="../../../user/controllers/logout.php">Se Déconnecter</a>
                </div>
            </div>
                <?php else: ?>
                    <a href="../login/login.php" class="button">Se connecter</a>
                <?php endif; ?>
            </nav>
        </header>
<main>
    <div class="job-details-container">
        <div class="job-details-header">
            <h2 class="job-details-title"><?php echo htmlspecialchars($offre['titre']); ?></h2>
            <p class="job-details-company"><?php echo htmlspecialchars($offre['nom_entreprise']); ?> - <?php echo htmlspecialchars($offre['lieu_travail'] ?? 'Non spécifié'); ?></p>
        </div>
        <div class="job-details-body">
            <p><strong>Description du poste :</strong><br><?php echo htmlspecialchars($offre['description']); ?></p>
            <p><strong>Compétences requises :</strong><br><?php echo htmlspecialchars($offre['competences']); ?></p>
            <p><strong>Expérience :</strong><br><?php echo htmlspecialchars($offre['experience']); ?></p>
            <p><strong>Type de contrat :</strong><br><?php echo htmlspecialchars($offre['contrat']); ?></p>
            <p><strong>Salaire :</strong><br><?php echo htmlspecialchars($offre['salaire']); ?></p>
            <p><strong>Date limite :</strong><br><?php echo htmlspecialchars($offre['date_limite']); ?></p>
            <p><strong>Nom de l'entreprise :</strong><br><?php echo htmlspecialchars($offre['nom_entreprise']); ?></p>
            <p><strong>Secteur :</strong><br><?php echo htmlspecialchars($offre['secteur']); ?></p>
            <p><strong>Adresse :</strong><br><?php echo htmlspecialchars($offre['adresse']); ?></p>
            <p><strong>Email de contact :</strong><br><?php echo htmlspecialchars($offre['email_contact']); ?></p>
            <p><strong>Téléphone :</strong><br><?php echo htmlspecialchars($offre['telephone']); ?></p>
            <p><strong>Site web :</strong><br><a href="<?php echo htmlspecialchars($offre['site_web']); ?>"><?php echo htmlspecialchars($offre['site_web']); ?></a></p>
            <p><strong>Horaires :</strong><br><?php echo htmlspecialchars($offre['horaires']); ?></p>
            <p><strong>Nombre de postes :</strong><br><?php echo htmlspecialchars($offre['nombre_postes']); ?></p>
            <p><strong>Documents requis :</strong><br><?php echo htmlspecialchars($offre['documents']); ?></p>
        </div>
        <div class="recommended-trainings">
            <h3>Formations recommandées</h3>
            <?php if (!empty($formations)): ?>
                <ul>
                    <?php foreach ($formations as $formation): ?>
                        <li>
                            <h4><?php echo htmlspecialchars($formation['titre']); ?></h4>
                            <p><strong>Description :</strong> <?php echo htmlspecialchars($formation['description']); ?></p>
                            <p><strong>Localisation :</strong> <?php echo htmlspecialchars($formation['localisation']); ?></p>
                            <p><strong>Durée :</strong> <?php echo htmlspecialchars($formation['duree']); ?></p>
                            <p><strong>Prix :</strong> <?php echo htmlspecialchars($formation['prix']); ?> TND</p>
                            <p><strong>Date de début :</strong> <?php echo htmlspecialchars($formation['date_debut']); ?></p>
                            <p><strong>Date de fin :</strong> <?php echo htmlspecialchars($formation['date_fin']); ?></p>
                            <p><strong>Compétences :</strong> <?php echo htmlspecialchars($formation['competences']); ?></p>
                            <a href="<?php echo htmlspecialchars($formation['lien']); ?>" target="_blank">Voir la formation</a>
                        </li>
                    <?php endforeach; ?>
                </ul>
            <?php else: ?>
                <p>Aucune formation recommandée pour cette offre.</p>
            <?php endif; ?>
        </div>
        <div class="job-details-footer">
            <a href="list_jobs.php" id="retour">Retour à la liste des offres</a>
            <?php if ($isLoggedIn): ?>
                <a href="../../../postulation/postuler.php?id=<?php echo $id; ?>" class="button">Postuler</a>
            <?php else: ?>
                <a href="../auth/login.php" class="button">Se connecter pour postuler</a>
            <?php endif; ?>
            <a href="../models/export_pdf.php?id=<?php echo $id; ?>" class="button">Exporter en PDF</a>
        </div>
    </div>
</main>

<footer>
    <p>Contactez-nous : contact@jobfinder.com</p>
    <p><a href="about.html">À propos</a> | <a href="privacy.html">Politique de confidentialité</a></p>
</footer>
</body>
</html>