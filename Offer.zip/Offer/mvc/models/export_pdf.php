<?php
require_once('../pdf/fpdf.php'); // Assurez-vous que FPDF est installé
include '../config/db_connect.php';

$id = isset($_GET['id']) ? $_GET['id'] : '';
if (!$id) {
    die("ID de l'offre non spécifié.");
}

// Récupérer les détails de l'offre
$query = "SELECT * FROM offres_emploi WHERE id = :id";
$stmt = $pdo->prepare($query);
$stmt->execute(['id' => $id]);
$offre = $stmt->fetch(PDO::FETCH_ASSOC);

if (!$offre) {
    die("Offre d'emploi non trouvée.");
}

// Créer une instance FPDF
$pdf = new FPDF();
$pdf->AddPage();
$pdf->SetFont('Arial', 'B', 16);

// Titre de l'offre
$pdf->Cell(0, 10, utf8_decode($offre['titre']), 0, 1, 'C');
$pdf->Ln(10);

// Contenu de l'offre
$pdf->SetFont('Arial', '', 12);
$pdf->MultiCell(0, 10, utf8_decode("Description : " . $offre['description']));
$pdf->MultiCell(0, 10, utf8_decode("Compétences : " . $offre['competences']));
$pdf->MultiCell(0, 10, utf8_decode("Expérience : " . $offre['experience']));
$pdf->MultiCell(0, 10, utf8_decode("Type de contrat : " . $offre['contrat']));
$pdf->MultiCell(0, 10, utf8_decode("Salaire : " . $offre['salaire']));
$pdf->MultiCell(0, 10, utf8_decode("Date limite : " . $offre['date_limite']));
$pdf->MultiCell(0, 10, utf8_decode("Nom de l'entreprise : " . $offre['nom_entreprise']));
$pdf->MultiCell(0, 10, utf8_decode("Secteur : " . $offre['secteur']));
$pdf->MultiCell(0, 10, utf8_decode("Adresse : " . $offre['adresse']));
$pdf->MultiCell(0, 10, utf8_decode("Email de contact : " . $offre['email_contact']));
$pdf->MultiCell(0, 10, utf8_decode("Téléphone : " . $offre['telephone']));
$pdf->MultiCell(0, 10, utf8_decode("Site web : " . $offre['site_web']));
$pdf->MultiCell(0, 10, utf8_decode("Lieu de travail : " . $offre['lieu_travail']));
$pdf->MultiCell(0, 10, utf8_decode("Horaires : " . $offre['horaires']));
$pdf->MultiCell(0, 10, utf8_decode("Nombre de postes : " . $offre['nombre_postes']));
$pdf->MultiCell(0, 10, utf8_decode("Documents requis : " . $offre['documents']));

// Générer le fichier PDF
$pdf->Output('D', 'offre_' . $id . '.pdf');
?>