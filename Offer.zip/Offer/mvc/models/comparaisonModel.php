<?php
include '../config/db_connect.php';
$ids = $_GET['ids'] ?? [];
if (empty($ids)) {
    echo "Aucune offre sélectionnée pour la comparaison.";
    exit;
}

$placeholders = implode(',', array_fill(0, count($ids), '?'));
$query = "SELECT offres_emploi.*, users.nom_utilisateur AS nom_entreprise 
          FROM offres_emploi 
          JOIN users ON offres_emploi.user_id = users.user_id 
          WHERE offres_emploi.id IN ($placeholders)";
$stmt = $pdo->prepare($query);
$stmt->execute($ids);
$offres = $stmt->fetchAll(PDO::FETCH_ASSOC);
?>
