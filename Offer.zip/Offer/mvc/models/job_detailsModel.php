<?php
include '../config/db_connect.php';
// Récupérer l'ID de l'offre d'emploi depuis l'URL
$id = isset($_GET['id']) ? $_GET['id'] : '';

if ($id) {
    // Préparer la requête pour récupérer les détails de l'offre
    $query = "SELECT * FROM offres_emploi WHERE id = :id";
    $stmt = $pdo->prepare($query);
    $stmt->execute(['id' => $id]);
    $offre = $stmt->fetch(PDO::FETCH_ASSOC);

    if (!$offre) {
        echo "Offre d'emploi non trouvée.";
        exit;
    }

    // Récupérer les formations liées aux compétences de l'offre
    $competences = $offre['competences'];
    $competencesArray = explode(',', $competences); // Séparer les compétences par une virgule
    $placeholders = implode(' OR competences LIKE ', array_fill(0, count($competencesArray), ':competence'));

    // Corriger la requête SQL pour utiliser les bons placeholders
    $formationsQuery = "SELECT * FROM formations WHERE " . implode(' OR ', array_map(function ($index) {
        return "competences LIKE :competence$index";
    }, array_keys($competencesArray)));

    $formationsStmt = $pdo->prepare($formationsQuery);

    $params = [];
    foreach ($competencesArray as $index => $competence) {
        $params[":competence$index"] = '%' . trim($competence) . '%';
    }

    $formationsStmt->execute($params);
    $formations = $formationsStmt->fetchAll(PDO::FETCH_ASSOC);
} else {
    echo "ID de l'offre d'emploi non spécifié.";
    exit;
}
?>