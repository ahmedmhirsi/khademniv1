<?php 
include '../config/db_connect.php';

// Récupérer les filtres
$titre = $_GET['titre'] ?? '';
$lieu = $_GET['lieu'] ?? '';
$salaire = $_GET['salaire'] ?? '';
$contrat = $_GET['contrat'] ?? '';
$page = $_GET['page'] ?? 1;
$limit = 9;
$offset = ($page - 1) * $limit;

// Construire la requête SQL avec les filtres
$query = "SELECT offres_emploi.*, users.nom_utilisateur, users.pdp
          FROM offres_emploi 
          JOIN users ON offres_emploi.user_id = users.user_id 
          WHERE statut = 'active'";
$params = [];

if ($titre) {
    $query .= " AND titre LIKE :titre";
    $params[':titre'] = '%' . $titre . '%';
}
if ($lieu) {
    $query .= " AND lieu_travail LIKE :lieu";
    $params[':lieu'] = '%' . $lieu . '%';
}
if ($salaire) {
    $query .= " AND salaire >= :salaire";
    $params[':salaire'] = (int)$salaire;
}
if ($contrat) {
    $query .= " AND contrat = :contrat";
    $params[':contrat'] = $contrat;
}

$sort = $_GET['sort'] ?? '';

if ($sort) {
    if ($sort == 'titre') {
        $query .= " ORDER BY titre ASC";
    } elseif ($sort == 'salaire') {
        $query .= " ORDER BY salaire DESC";
    } elseif ($sort == 'contrat') {
        $query .= " ORDER BY contrat ASC";
    } elseif ($sort == 'entreprise') {
        $query .= " ORDER BY nom_utilisateur ASC"; // Tri par nom de l'entreprise
    } elseif ($sort == 'datelimite') {
        $query .= " ORDER BY date_limite ASC"; // Tri par date limite
    } elseif ($sort == 'experience') {
        $query .= " ORDER BY experience DESC"; // Tri par expérience (plus d'expérience en premier)
    } elseif ($sort == 'postes') {
        $query .= " ORDER BY nombre_postes DESC"; // Tri par nombre de postes (plus de postes en premier)
    }
} else {
    $query .= " ORDER BY RAND()"; // Par défaut, tri aléatoire
}

// Ajouter la limite pour la pagination
$query .= " LIMIT $limit OFFSET $offset";

// Exécuter la requête
$stmt = $pdo->prepare($query);
$stmt->execute($params);
$offres = $stmt->fetchAll(PDO::FETCH_ASSOC);

// Récupérer le nombre total d'offres pour la pagination
$totalQuery = "SELECT COUNT(*) 
               FROM offres_emploi 
               JOIN users ON offres_emploi.user_id = users.user_id
               WHERE statut = 'active'";
$totalParams = [];

if ($titre) {
    $totalQuery .= " AND titre LIKE :titre";
    $totalParams[':titre'] = '%' . $titre . '%';
}
if ($lieu) {
    $totalQuery .= " AND lieu_travail LIKE :lieu";
    $totalParams[':lieu'] = '%' . $lieu . '%';
}
if ($salaire) {
    $totalQuery .= " AND salaire >= :salaire";
    $totalParams[':salaire'] = (int)$salaire;
}
if ($contrat) {
    $totalQuery .= " AND contrat = :contrat";
    $totalParams[':contrat'] = $contrat;
}

$totalStmt = $pdo->prepare($totalQuery);
$totalStmt->execute($totalParams);
$totalOffres = $totalStmt->fetchColumn();
$totalPages = ceil($totalOffres / $limit);

$activePage = 'jobs';
?>
