<?php
include '../config/db_connect.php';
session_start();

// Vérifier si l'utilisateur est connecté
if (!isset($_SESSION["user"]) || !isset($_SESSION["user"]["user_id"])) {
    echo json_encode(['success' => false, 'message' => 'Utilisateur non connecté']);
    exit;
}

$user_id = $_SESSION["user"]["user_id"];
$data = json_decode(file_get_contents('php://input'), true);
$offre_id = $data['offre_id'] ?? null;

if ($offre_id) {
    // Vérifier si l'offre est déjà dans les favoris
    $query = "SELECT * FROM favoris WHERE user_id = :user_id AND offre_id = :offre_id";
    $stmt = $pdo->prepare($query);
    $stmt->execute([':user_id' => $user_id, ':offre_id' => $offre_id]);
    $favori = $stmt->fetch(PDO::FETCH_ASSOC);

    if ($favori) {
        // Supprimer des favoris
        $query = "DELETE FROM favoris WHERE user_id = :user_id AND offre_id = :offre_id";
        $stmt = $pdo->prepare($query);
        $stmt->execute([':user_id' => $user_id, ':offre_id' => $offre_id]);
        echo json_encode(['success' => true, 'message' => 'Supprimé des favoris']);
    } else {
        // Ajouter aux favoris
        $query = "INSERT INTO favoris (user_id, offre_id) VALUES (:user_id, :offre_id)";
        $stmt = $pdo->prepare($query);
        $stmt->execute([':user_id' => $user_id, ':offre_id' => $offre_id]);
        echo json_encode(['success' => true, 'message' => 'Ajouté aux favoris']);
    }
} else {
    echo json_encode(['success' => false, 'message' => 'ID de l\'offre manquant']);
}
?>