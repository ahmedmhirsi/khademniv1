<?php 
include '../config/db_connect.php';
// Récupérer les favoris de l'utilisateur
$query = "SELECT offres_emploi.*, users.nom_utilisateur, users.pdp 
          FROM favoris 
          JOIN offres_emploi ON favoris.offre_id = offres_emploi.id 
          JOIN users ON offres_emploi.user_id = users.user_id
          WHERE favoris.user_id = :user_id";
$stmt = $pdo->prepare($query);
$stmt->execute([':user_id' => $user_id]);
$favoris = $stmt->fetchAll(PDO::FETCH_ASSOC);
?>