<?php
include '../config/db_connect.php';
session_start();
if (!isset($_SESSION["user"]) || !isset($_SESSION["user"]["user_id"])) {
    header('Location: ../auth/login.php');
    exit;
}


$user_id = $_SESSION["user"]["user_id"];
$query = "SELECT * FROM users WHERE user_id = :user_id";
$stmt = $pdo->prepare($query);
$stmt->execute([':user_id' => $user_id]);
$user = $stmt->fetch(PDO::FETCH_ASSOC);
?>