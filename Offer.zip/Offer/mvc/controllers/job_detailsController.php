<?php
include '../config/db_connect.php';
session_start();

// Vérifier si l'utilisateur est connecté
$isLoggedIn = isset($_SESSION["user"]) && isset($_SESSION["user"]["user_id"]);

if ($isLoggedIn) {
    $user_id = $_SESSION["user"]["user_id"];
    $query = "SELECT * FROM users WHERE user_id = :user_id";
    $stmt = $pdo->prepare($query);
    $stmt->execute([':user_id' => $user_id]);
    $user = $stmt->fetch(PDO::FETCH_ASSOC);

    // Récupérer les favoris de l'utilisateur
    $favoritesQuery = "SELECT offre_id FROM favoris WHERE user_id = :user_id";
    $favoritesStmt = $pdo->prepare($favoritesQuery);
    $favoritesStmt->execute([':user_id' => $user_id]);
    $userFavorites = $favoritesStmt->fetchAll(PDO::FETCH_COLUMN);
} else {
    $userFavorites = []; // Pas de favoris si l'utilisateur n'est pas connecté
}
?>