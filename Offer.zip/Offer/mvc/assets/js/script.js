document.querySelectorAll('.favorite-icon').forEach(icon => {
    icon.addEventListener('click', function () {
        const offreId = this.getAttribute('data-offre-id');
        console.log('ID de l\'offre:', offreId); // Vérifiez si l'ID est correct

        fetch('../models/add_to_favorites.php', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({ offre_id: offreId })
        })
        .then(response => response.json())
        .then(data => {
            console.log('Réponse du serveur:', data); // Vérifiez la réponse du serveur
            if (data.success) {
                // Alterner entre étoile pleine et vide
                this.classList.toggle('fas');
                this.classList.toggle('far');
                alert(data.message); // Affiche un message de succès ou d'erreur
            } else {
                alert(data.message); // Affiche un message d'erreur
            }
        })
        .catch(error => {
            console.error('Erreur:', error);
        });
    });
});

let selectedOffers = [];

document.querySelectorAll('.compare-checkbox').forEach(checkbox => {
    checkbox.addEventListener('change', function () {
        const offreId = this.getAttribute('data-offre-id');
        if (this.checked) {
            selectedOffers.push(offreId);
        } else {
            selectedOffers = selectedOffers.filter(id => id !== offreId);
        }
    });
});

function redirectToComparison() {
    if (selectedOffers.length === 0) {
        alert('Veuillez sélectionner au moins une offre pour comparer.');
        return;
    }
    const queryString = selectedOffers.map(id => `ids[]=${id}`).join('&');
    window.location.href = `../views/comparaisonView.php?${queryString}`;
}

function toggleFilterForm() {
    const filterForm = document.querySelector('.filter-form');
    if (filterForm) {
        // Basculer la classe active
        filterForm.classList.toggle('active');
        // Afficher ou masquer le formulaire
        if (filterForm.classList.contains('active')) {
            filterForm.style.display = 'flex'; // Affiche le formulaire
        } else {
            filterForm.style.display = 'none'; // Cache le formulaire
        }
    } else {
        console.error("Le formulaire de filtre n'a pas été trouvé.");
    }
}

document.addEventListener('DOMContentLoaded', function () {
    const messagesContainer = document.getElementById('chatbot-messages');
    const inputField = document.getElementById('chatbot-input');
    const sendButton = document.getElementById('chatbot-send');

    // Fonction pour afficher un message dans le chatbot
    function addMessage(sender, text) {
        const message = document.createElement('div');
        message.className = sender === 'user' ? 'user-message' : 'bot-message';
        message.textContent = text;
        messagesContainer.appendChild(message);
        messagesContainer.scrollTop = messagesContainer.scrollHeight; // Scroll vers le bas
    }

    // Fonction pour envoyer une requête au serveur
    function sendMessageToServer(message) {
        fetch('chatbot_handler.php', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
            },
            body: JSON.stringify({ message }),
        })
            .then((response) => response.json())
            .then((data) => {
                addMessage('bot', data.reply);
            })
            .catch((error) => {
                console.error('Erreur:', error);
                addMessage('bot', 'Désolé, une erreur est survenue.');
            });
    }

    // Gérer l'envoi du message
    sendButton.addEventListener('click', function () {
        const userMessage = inputField.value.trim();
        if (userMessage) {
            addMessage('user', userMessage);
            sendMessageToServer(userMessage);
            inputField.value = '';
        }
    });

    inputField.addEventListener('keypress', function (e) {
        if (e.key === 'Enter') {
            sendButton.click();
        }
    });
});

function copyLink(link) {
    navigator.clipboard.writeText(link).then(() => {
        alert(`Lien copié : Vous pouvez maintenant le coller et l'envoyer.`);
    }).catch(err => {
        console.error('Erreur lors de la copie du lien : ', err);
    });
}

function toggleShareMenu(icon) {
    const shareMenu = icon.nextElementSibling;
    if (shareMenu.style.display === "block") {
        shareMenu.style.display = "none";
    } else {
        shareMenu.style.display = "block";
    }
}

// Fermer le menu si on clique en dehors
document.addEventListener("click", function (event) {
    const shareMenus = document.querySelectorAll(".share-menu");
    shareMenus.forEach(menu => {
        if (!menu.contains(event.target) && !menu.previousElementSibling.contains(event.target)) {
            menu.style.display = "none";
        }
    });
});

function handleShareClick(event, link) {
    event.preventDefault(); // Empêche la redirection immédiate
    navigator.clipboard.writeText(link).then(() => {
        alert(`Lien copié : Vous pouvez maintenant le coller et l'envoyer.`);
        setTimeout(() => {
            window.open(event.target.closest('a').href, '_blank'); // Redirige après un court délai
        }, 100); // Délai de 500ms pour afficher l'alerte
    }).catch(err => {
        console.error('Erreur lors de la copie du lien : ', err);
    });
}