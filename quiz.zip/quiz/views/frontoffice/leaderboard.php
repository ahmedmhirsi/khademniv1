<?php
require_once '../../controllers/LeaderboardController.php';
require_once '../../controllers/UserController.php';
require_once '../../controllers/ReferralController.php';

$leaderboardController = new LeaderboardController();
$userController = new UserController();
$referralController = new ReferralController();
$leaderboard = $leaderboardController->getLeaderboard(10);
$currentUser = $userController->getCurrentUser();

$referralCode = null;
$referralStats = null;
$referralLink = null;
if ($currentUser) {
    $codeResult = $referralController->generateReferralCode($currentUser['id']);
    if ($codeResult['success']) {
        $referralCode = $codeResult['code'];
        $referralLink = "http://localhost/trash2treasure_gamification4/views/frontoffice/register.php?ref=" . urlencode($referralCode);
    }
    $referralStats = $referralController->getReferralStats($currentUser['id']);
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Leaderboard - Trash2Treasure</title>
    <link href="https://cdn.jsdelivr.net/npm/tailwindcss@2.0.2/dist/tailwind.min.css" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700&family=Montserrat:wght@400;600;700&display=swap" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css" rel="stylesheet">
    <style>
        :root {
            --forest-green: #1b4332;
            --leaf-green: #2d6a4f;
            --mint-green: #74c69d;
            --light-mint: #b7e4c7;
            --cream: #f8f9fa;
            --soft-white: #ffffff;
            --water-blue: #4fc3f7;
        }

        body {
            font-family: 'Poppins', sans-serif;
            background: linear-gradient(135deg, var(--cream) 0%, var(--soft-white) 100%);
            background-attachment: fixed;
            color: #2d3748;
            overflow-x: hidden;
            position: relative;
            min-height: 100vh;
        }

        .eco-bg {
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background: url("data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 1440 810'%3E%3Cpath d='M0 200C200 150 400 250 600 200C800 150 1000 300 1200 250C1400 200 1600 350 1800 300' fill='none' stroke='%2374c69d' stroke-width='3' opacity='0.15'/%3E%3Cpath d='M0 400C200 350 400 450 600 400C800 350 1000 500 1200 450C1400 400 1600 550 1800 500' fill='none' stroke='%232d6a4f' stroke-width='2' opacity='0.1'/%3E%3C/svg%3E");
            background-size: cover;
            z-index: -1;
            animation: canopy 40s infinite ease-in-out;
        }

        @keyframes canopy {
            0% { transform: translateY(0) scale(1); }
            50% { transform: translateY(-15px) scale(1.01); }
            100% { transform: translateY(0) scale(1); }
        }

        .leaf {
            position: absolute;
            width: 18px;
            height: 18px;
            background: url("data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 24 24' fill='%2374c69d'%3E%3Cpath d='M17 8C8 10 5.9 16.17 5.9 16.17c-1.5 3.83.83 5.86 2.62 6.67 2.37 1.06 5.92.24 5.92.24 3.78-.85 6.66-3.35 7.05-8.8 2.77-1 4.45-2.68 4.45-4.85C26 4.24 19 5.22 17 8zM10.45 16.89a5.2 5.2 0 01-2.91-3.4c-.13-.68.04-1.57.52-2.32a3.02 3.02 0 012.02-1.15c.39-.07.77-.05 1.15.06.76.22 1.47.7 2.09 1.42.62.72 1.07 1.61 1.21 2.63.07.51.07.99 0 1.45-.14.93-.57 1.76-1.23 2.45-.67.69-1.51 1.25-2.45 1.68a7.72 7.72 0 01-2.88.65 5.59 5.59 0 01-2.9-.55c-.76-.34-1.41-.85-1.93-1.5'/%3E%3C/svg%3E");
            background-size: cover;
            opacity: 0.5;
            animation: fall 20s infinite linear;
            pointer-events: none;
        }

        @keyframes fall {
            0% { transform: translateY(-100vh) rotate(0deg); opacity: 0.5; }
            100% { transform: translateY(100vh) rotate(360deg); opacity: 0; }
        }

        .firefly {
            position: absolute;
            width: 5px;
            height: 5px;
            background: var(--mint-green);
            border-radius: 50%;
            opacity: 0.6;
            animation: firefly 10s infinite ease-in-out;
            pointer-events: none;
            box-shadow: 0 0 5px var(--mint-green);
        }

        @keyframes firefly {
            0% { transform: translate(0, 0) scale(0.5); opacity: 0.6; }
            50% { transform: translate(40px, -40px) scale(1); opacity: 0.8; }
            100% { transform: translate(0, 0) scale(0.5); opacity: 0.6; }
        }

        .ripple {
            position: absolute;
            width: 20px;
            height: 20px;
            background: radial-gradient(circle, var(--water-blue) 10%, transparent 70%);
            border-radius: 50%;
            opacity: 0;
            animation: ripple 5s infinite ease-out;
            pointer-events: none;
        }

        @keyframes ripple {
            0% { transform: scale(0); opacity: 0.5; }
            50% { transform: scale(3); opacity: 0.3; }
            100% { transform: scale(5); opacity: 0; }
        }

        .leaderboard-section {
            background: rgba(255, 255, 255, 0.9);
            backdrop-filter: blur(10px);
            border-radius: 1.5rem;
            border: 1px solid rgba(45, 106, 79, 0.15);
            position: relative;
            transition: transform 0.6s ease, box-shadow 0.6s ease;
            overflow: hidden;
            box-shadow: 0 10px 30px rgba(45, 106, 79, 0.1);
            z-index: 10;
        }

        .leaderboard-section:hover {
            transform: perspective(1200px) rotateX(2deg) rotateY(2deg);
            box-shadow: 0 15px 35px rgba(45, 106, 79, 0.15);
        }

        .animated-btn {
            position: relative;
            overflow: hidden;
            background: linear-gradient(45deg, var(--forest-green), var(--leaf-green));
            padding: 0.75rem 1.5rem;
            border-radius: 1.5rem;
            color: var(--soft-white);
            font-family: 'Montserrat', sans-serif;
            font-weight: 600;
            text-transform: uppercase;
            box-shadow: 0 5px 15px rgba(45, 106, 79, 0.3);
            transition: all 0.4s ease;
            letter-spacing: 0.5px;
            font-size: 0.85rem;
            z-index: 20;
        }

        .animated-btn:hover {
            transform: translateY(-5px) scale(1.05);
            box-shadow: 0 8px 20px rgba(45, 106, 79, 0.4);
        }

        .animated-btn::before {
            content: '';
            position: absolute;
            top: 0;
            left: -100%;
            width: 100%;
            height: 100%;
            background: linear-gradient(90deg, transparent, rgba(255, 255, 255, 0.2), transparent);
            transition: 0.6s;
        }

        .animated-btn:hover::before {
            left: 100%;
        }

        .leaderboard-btn {
            background: linear-gradient(45deg, var(--leaf-green), var(--mint-green));
            z-index: 30;
        }

        .logout-btn {
            background: linear-gradient(45deg, #c53030, #e53e3e);
        }

        .referral-btn {
            background: linear-gradient(45deg, var(--mint-green), var(--water-blue));
        }

        .leaderboard-card {
            background: rgba(255, 255, 255, 0.85);
            backdrop-filter: blur(8px);
            border: 1px solid rgba(45, 106, 79, 0.15);
            border-radius: 1rem;
            transition: all 0.5s ease;
            transform: perspective(1000px);
            position: relative;
            overflow: hidden;
            box-shadow: 0 5px 15px rgba(45, 106, 79, 0.08);
        }

        .leaderboard-card:hover {
            transform: perspective(1000px) translateY(-8px);
            box-shadow: 0 15px 30px rgba(45, 106, 79, 0.15);
        }

        .leaderboard-card::before {
            content: '';
            position: absolute;
            top: ifel;
            left: 0;
            width: 100%;
            height: 100%;
            background: url("data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 100 100'%3E%3Cpath d='M0 0v100h100V0H0zm50 50c-11.05 0-20-8.95-20-20s8.95-20 20-20 20 8.95 20 20-8.95 20-20 20z' fill='%2374c69d' fill-opacity='0.05'/%3E%3C/svg%3E");
            opacity: 0.3;
        }

        .eco-badge {
            background: rgba(45, 106, 79, 0.1);
            color: var(--leaf-green);
            border-radius: 9999px;
            font-size: 0.75rem;
            padding: 0.25rem 0.75rem;
            display: inline-flex;
            align-items: center;
            margin-bottom: 0.75rem;
        }

        .eco-badge i {
            font-size: 0.75rem;
            margin-right: 0.25rem;
        }

        .back-arrow {
            background: linear-gradient(45deg, var(--forest-green), var(--leaf-green));
            color: var(--soft-white);
            border-radius: 50%;
            padding: 8px;
            display: flex;
            align-items: center;
            justify-content: center;
            transition: all 0.3s ease;
            box-shadow: 0 2px 5px rgba(45, 106, 79, 0.3);
        }

        .back-arrow:hover {
            transform: translateX(-3px);
            box-shadow: 0 4px 10px rgba(45, 106, 79, 0.4);
        }

        .empty-state {
            background: rgba(255, 255, 255, 0.85);
            backdrop-filter: blur(8px);
            border-radius: 1rem;
            padding: 2rem;
            text-align: center;
            box-shadow: 0 5px 15px rgba(45, 106, 79, 0.08);
            border: 1px dashed rgba(45, 106, 79, 0.3);
        }

        .footer-note {
            text-align: center;
            color: var(--leaf-green);
            font-weight: 500;
            font-family: 'Montserrat', sans-serif;
        }

        .medal {
            font-size: 1.5rem;
            margin-right: 0.5rem;
        }

        .gold { color: #FFD700; }
        .silver { color: #C0C0C0; }
        .bronze { color: #CD7F32; }

        .current-user {
            background: rgba(45, 106, 79, 0.1);
            font-weight: bold;
        }

        .search-container {
            position: relative;
            max-width: 400px;
            margin: 0 auto 2rem;
        }

        .search-input {
            width: 100%;
            padding: 0.75rem 1rem 0.75rem 2.5rem;
            border: 1px solid rgba(45, 106, 79, 0.3);
            border-radius: 1rem;
            background: rgba(255, 255, 255, 0.9);
            font-family: 'Poppins', sans-serif;
            font-size: 0.9rem;
            color: var(--forest-green);
            transition: all 0.3s ease;
            box-shadow: 0 2px 5px rgba(45, 106, 79, 0.1);
        }

        .search-input:focus {
            outline: none;
            border-color: var(--leaf-green);
            box-shadow: 0 4px 10px rgba(45, 106, 79, 0.2);
        }

        .search-input::placeholder {
            color: var(--leaf-green);
            opacity: 0.7;
        }

        .search-icon {
            position: absolute;
            left: 0.75rem;
            top: 50%;
            transform: translateY(-50%);
            color: var(--leaf-green);
            font-size: 1rem;
        }

        .no-results {
            text-align: center;
            color: var(--forest-green);
            font-family: 'Montserrat', sans-serif;
            font-size: 1rem;
            margin-top: 1rem;
            display: none;
        }

        .referral-section {
            background: rgba(255, 255, 255, 0.85);
            backdrop-filter: blur(8px);
            border-radius: 1rem;
            padding: 1.5rem;
            margin-bottom: 2rem;
            box-shadow: 0 5px 15px rgba(45, 106, 79, 0.08);
            border: 1px solid rgba(45, 106, 79, 0.15);
        }

        .referral-input {
            background: rgba(255, 255, 255, 0.9);
            border: 1px solid rgba(45, 106, 79, 0.3);
            border-radius: 0.5rem;
            padding: 0.5rem;
            width: 100%;
            font-family: 'Poppins', sans-serif;
            color: var(--forest-green);
        }

        .referral-input:focus {
            outline: none;
            border-color: var(--leaf-green);
            box-shadow: 0 2px 5px rgba(45, 106, 79, 0.2);
        }

        @media (max-width: 768px) {
            .leaderboard-section {
                transform: none;
            }

            .leaderboard-section:hover {
                transform: none;
            }

            .animated-btn {
                padding: 0.75rem 1.5rem;
                font-size: 0.85rem;
            }

            .search-container {
                max-width: 100%;
            }
        }
    </style>
</head>
<body>
<br>
                <div class="flex justify-center mb-8">
                    <a href="quiz_list.php" class="animated-btn leaderboard-btn"><i class="fas fa-question-circle mr-3"></i>Join the Challenge</a>
                </div>

                <?php if (count($leaderboard) > 0): ?>
                    <div class="search-container">
                        <i class="fas fa-search search-icon"></i>
                        <input type="text" id="leaderboard-search" class="search-input" placeholder="Search user..." aria-label="Search leaderboard by username">
                    </div>
                    <div class="leaderboard-card p-6">
                        <table class="w-full text-left" id="leaderboard-table">
                            <thead>
                                <tr class="text-forest-green">
                                    <th class="p-4">Rank</th>
                                    <th class="p-4">Eco-Warrior</th>
                                    <th class="p-4">Eco-Points</th>
                                    <th class="p-4">Quizzes Taken</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php foreach ($leaderboard as $index => $entry): ?>
                                    <tr class="border-t border-gray-200 <?php echo ($currentUser && $entry['user_id'] == $currentUser['id']) ? 'current-user' : ''; ?>" data-username="<?php echo htmlspecialchars($entry['username']); ?>">
                                        <td class="p-4">
                                            <?php
                                            $rank = $index + 1;
                                            if ($rank == 1) {
                                                echo '<i class="fas fa-medal gold medal"></i>';
                                            } elseif ($rank == 2) {
                                                echo '<i class="fas fa-medal silver medal"></i>';
                                            } elseif ($rank == 3) {
                                                echo '<i class="fas fa-medal bronze medal"></i>';
                                            } else {
                                                echo $rank;
                                            }
                                            ?>
                                        </td>
                                        <td class="p-4"><?php echo htmlspecialchars($entry['username']); ?></td>
                                        <td class="p-4"><?php echo htmlspecialchars($entry['total_eco_points']); ?> <i class="fas fa-leaf text-leaf-green"></i></td>
                                        <td class="p-4"><?php echo htmlspecialchars($entry['quizzes_taken']); ?></td>
                                    </tr>
                                <?php endforeach; ?>
                            </tbody>
                        </table>
                        <p class="no-results" id="no-results">No Eco-Warriors found matching your search.</p>
                    </div>
                    <p class="footer-note mt-8">Keep quizzing to climb the ranks and become an Eco Champion!</p>
                <?php else: ?>
                    <div class="empty-state">
                        <i class="fas fa-seedling w-16 h-16 mx-auto text-leaf-green mb-4"></i>
                        <h3 class="text-xl font-semibold font-montserrat text-forest-green mb-2">No Leaders Yet</h3>
                        <p class="text-gray-500">Be the first eco-warrior to join the leaderboard!</p>
                        <a href="quiz_list.php" class="animated-btn mt-4"><i class="fas fa-play-circle mr-2"></i>Start a Quiz</a>
                    </div>
                <?php endif; ?>
            </div>
        </div>
    </div>

    <script>
        // Firefly animation
        const firefliesContainer = document.getElementById('fireflies');
        for (let i = 0; i < 25; i++) {
            const firefly = document.createElement('div');
            firefly.className = 'firefly';
            firefly.style.left = `${Math.random() * 100}vw`;
            firefly.style.top = `${Math.random() * 100}vh`;
            firefly.style.animationDelay = `${Math.random() * 5}s`;
            firefly.style.animationDuration = `${6 + Math.random() * 4}s`;
            firefliesContainer.appendChild(firefly);
        }

        // Falling leaves
        for (let i = 0; i < 15; i++) {
            const leaf = document.createElement('div');
            leaf.className = 'leaf';
            leaf.style.left = `${Math.random() * 100}vw`;
            leaf.style.animationDelay = `${Math.random() * 10}s`;
            leaf.style.animationDuration = `${15 + Math.random() * 10}s`;
            firefliesContainer.appendChild(leaf);
        }

        // Water ripple effect
        const ripplesContainer = document.getElementById('ripples');
        for (let i = 0; i < 10; i++) {
            const ripple = document.createElement('div');
            ripple.className = 'ripple';
            ripple.style.left = `${Math.random() * 100}vw`;
            ripple.style.top = `${Math.random() * 100}vh`;
            ripple.style.animationDelay = `${Math.random() * 5}s`;
            ripple.style.animationDuration = `${3 + Math.random() * 2}s`;
            ripplesContainer.appendChild(ripple);
        }

        // Leaderboard search functionality
        const searchInput = document.getElementById('leaderboard-search');
        const leaderboardTable = document.getElementById('leaderboard-table');
        const rows = leaderboardTable.querySelectorAll('tbody tr');
        const noResults = document.getElementById('no-results');

        searchInput.addEventListener('input', () => {
            const query = searchInput.value.trim().toLowerCase();
            let hasResults = false;

            rows.forEach(row => {
                const username = row.getAttribute('data-username').toLowerCase();
                if (username.includes(query)) {
                    row.style.display = '';
                    hasResults = true;
                } else {
                    row.style.display = 'none';
                }
            });

            noResults.style.display = hasResults ? 'none' : 'block';
        });

        // Copy to clipboard function
        function copyToClipboard(text) {
            navigator.clipboard.writeText(text).then(() => {
                alert('Copied to clipboard!');
            }).catch(err => {
                console.error('Failed to copy: ', err);
            });
        }
    </script>
</body>
</html>