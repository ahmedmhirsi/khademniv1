document.addEventListener('DOMContentLoaded', () => {
    // Common functionality for both pages
    const totalQuestions = document.querySelectorAll('.question').length || document.querySelectorAll