<?php
require_once '../../controllers/QuizController.php';
require_once '../../controllers/QuestionController.php';
require_once 'fpdf186/fpdf.php'; // Assurez-vous que FPDF est installé

// Vérifiez si l'ID du quiz est fourni
$quizId = filter_input(INPUT_GET, 'id', FILTER_SANITIZE_NUMBER_INT);
if (!$quizId) {
    die('Quiz ID is required.');
}

// Récupérez les détails du quiz et les questions
$quizController = new QuizController();
$questionController = new QuestionController();

$quiz = $quizController->showQuiz($quizId);
$questions = $questionController->listQuestionsByQuiz($quizId);

if (!$quiz || empty($questions)) {
    die('Quiz not found or no questions available.');
}

// Créez un nouveau PDF
$pdf = new FPDF();
$pdf->AddPage();
$pdf->SetFont('Arial', 'B', 16);

// Titre du quiz
$pdf->Cell(0, 10, utf8_decode($quiz['title']), 0, 1, 'C');
$pdf->Ln(10);

// Ajoutez les questions et réponses
foreach ($questions as $index => $question) {
    $pdf->SetFont('Arial', 'B', 12);
    $pdf->Cell(0, 10, utf8_decode("Question " . ($index + 1) . ": " . $question['question_text']), 0, 1);
    $pdf->SetFont('Arial', '', 12);
    $pdf->Cell(0, 10, utf8_decode("A. " . $question['option_a']), 0, 1);
    $pdf->Cell(0, 10, utf8_decode("B. " . $question['option_b']), 0, 1);
    if (!empty($question['option_c'])) {
        $pdf->Cell(0, 10, utf8_decode("C. " . $question['option_c']), 0, 1);
    }
    if (!empty($question['option_d'])) {
        $pdf->Cell(0, 10, utf8_decode("D. " . $question['option_d']), 0, 1);
    }
    $pdf->Cell(0, 10, utf8_decode("Correct Answer: " . $question['option_' . $question['correct_option']]), 0, 1);
    $pdf->Ln(5);
}

// Téléchargez le PDF
$pdf->Output('D', 'Quiz_' . $quizId . '_Questions.pdf');
?>