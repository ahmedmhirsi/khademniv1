<?php
// Start session safely
if (session_status() !== PHP_SESSION_ACTIVE) {
    session_start();
}

// Include necessary controller files
require_once '../../controllers/QuizController.php';
require_once '../../controllers/QuestionController.php';
require_once '../../controllers/LeaderboardController.php';
require_once '../../controllers/UserController.php';
// Initialize controllers
$quizController = new QuizController();
$questionController = new QuestionController();
$leaderboardController = new LeaderboardController();
$userController = new UserController();

// Check if user is logged in
$currentUser = $userController->getCurrentUser();
if (!$currentUser) {
    header('Location: login.php');
    exit;
}

// Get quiz ID from URL
$quizId = filter_input(INPUT_GET, 'id', FILTER_SANITIZE_NUMBER_INT);

if (!$quizId) {
    header('Location: error.php?message=Quiz ID not provided');
    exit;
}

// Fetch quiz details
$quiz = $quizController->showQuiz($quizId);
if (!$quiz) {
    header('Location: error.php?message=Quiz not found');
    exit;
}

// Fetch questions associated with the quiz
$questions = $questionController->listQuestionsByQuiz($quizId);
if (empty($questions)) {
    header('Location: error.php?message=No questions found');
    exit;
}

// Check if the form has been submitted
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Process submitted answers
    $userAnswers = $_POST['answers'] ?? [];
    $timeTaken = (int)($_POST['timeTaken'] ?? 600);
    $score = 0;
    $totalQuestions = count($questions);
    $results = [];

    foreach ($questions as $question) {
        $questionId = $question['id'];
        $correctAnswer = $question['correct_option'];
        $userAnswer = $userAnswers[$questionId] ?? null;

        $isCorrect = $userAnswer === $correctAnswer;
        if ($isCorrect) {
            $score++;
        }

        $results[] = [
            'question_text' => $question['question_text'],
            'user_answer' => $userAnswer ? $question['option_' . $userAnswer] : 'Not answered',
            'correct_answer' => $question['option_' . $correctAnswer],
            'is_correct' => $isCorrect
        ];
    }

    $percentage = ($totalQuestions > 0) ? ($score / $totalQuestions) * 100 : 0;

    $badgeLevel = '';
    $badgeIcon = '';
    $badgeMessage = '';
    
    if ($percentage >= 90) {
        $badgeLevel = 'Sustainability Champion';
        $badgeIcon = 'fas fa-award';
        $badgeMessage = 'Outstanding! Your knowledge of sustainable practices is exceptional!';
    } elseif ($percentage >= 75) {
        $badgeLevel = 'Eco Warrior';
        $badgeIcon = 'fas fa-tree';
        $badgeMessage = 'Great job! You\'re well on your way to becoming a sustainability expert!';
    } elseif ($percentage >= 50) {
        $badgeLevel = 'Green Explorer';
        $badgeIcon = 'fas fa-compass';
        $badgeMessage = 'Good effort! You\'re making progress on your sustainability journey!';
    } else {
        $badgeLevel = 'Eco Seedling';
        $badgeIcon = 'fas fa-seedling';
        $badgeMessage = 'Keep learning! Every step toward sustainability counts!';
    }

    $ecoPoints = ceil($percentage / 10) * 5;
    if (isset($_POST['timedMode']) && $_POST['timedMode'] === 'on') {
        $bonusPoints = floor((600 - $timeTaken) / 6);
        $ecoPoints += max(0, $bonusPoints);
    }
    $ecoPoints = max(0, $ecoPoints);

    // Save score to leaderboard
    $scoreObj = new Score(null, $currentUser['id'], $quizId, $score, $ecoPoints, null);
    $leaderboardController->saveScore($scoreObj);
?>

<!DOCTYPE html>
<html lang="en" data-theme="forest">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Quiz Results - Trash2Treasure</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700&family=Montserrat:wght@400;600;700&display=swap" rel="stylesheet">
    <style>
        :root {
            --forest-green: #1b4332;
            --leaf-green: #2d6a4f;
            --mint-green: #74c69d;
            --ocean-blue: #4fc3f7;
            --desert-sand: #d4a373;
            --error-red: #e53e3e;
        }

        [data-theme="forest"] {
            --primary: var(--forest-green);
            --secondary: #4a5568;
            --accent: var(--mint-green);
            --error: var(--error-red);
        }

        [data-theme="ocean"] {
            --primary: #2b6cb0;
            --secondary: #2d3748;
            --accent: var(--ocean-blue);
            --error: var(--error-red);
        }

        [data-theme="desert"] {
            --primary: #7b4e2a;
            --secondary: #4a5568;
            --accent: var(--desert-sand);
            --error: var(--error-red);
        }

        body {
            font-family: 'Poppins', sans-serif;
            background: linear-gradient(135deg, #f8f9fa 0%, #ffffff 100%);
            color: var(--secondary);
            min-height: 100vh;
            position: relative;
            overflow-x: hidden;
        }

        .eco-bg {
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background: url("data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 1440 810'%3E%3Cpath d='M0 200C200 150 400 250 600 200C800 150 1000 300 1200 250C1400 200 1600 350 1800 300' fill='none' stroke='%2374c69d' stroke-width='3' opacity='0.15'/%3E%3Cpath d='M0 400C200 350 400 450 600 400C800 350 1000 500 1200 450C1400 400 1600 550 1800 500' fill='none' stroke='%232d6a4f' stroke-width='2' opacity='0.1'/%3E%3C/svg%3E");
            background-size: cover;
            z-index: -1;
            animation: canopy 40s infinite ease-in-out;
        }

        @keyframes canopy {
            0% { transform: translateY(0) scale(1); }
            50% { transform: translateY(-15px) scale(1.01); }
            100% { transform: translateY(0) scale(1); }
        }

        .leaf {
            position: absolute;
            width: 18px;
            height: 18px;
            background: url("data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 24 24' fill='%2374c69d'%3E%3Cpath d='M17 8C8 10 5.9 16.17 5.9 16.17c-1.5 3.83.83 5.86 2.62 6.67 2.37 1.06 5.92.24 5.92.24 3.78-.85 6.66-3.35 7.05-8.8 2.77-1 4.45-2.68 4.45-4.85C26 4.24 19 5.22 17 8zM10.45 16.89a5.2 5.2 0 01-2.91-3.4c-.13-.68.04-1.57.52-2.32a3.02 3.02 0 012.02-1.15c.39-.07.77-.05 1.15.06.76.22 1.47.7 2.09 1.42.62.72 1.07 1.61 1.21 2.63.07.51.07.99 0 1.45-.14.93-.57 1.76-1.23 2.45-.67.69-1.51 1.25-2.45 1.68a7.72 7.72 0 01-2.88.65 5.59 5.59 0 01-2.9-.55c-.76-.34-1.41-.85-1.93-1.5'/%3E%3C/svg%3E");
            background-size: cover;
            opacity: 0.5;
            animation: fall 20s infinite linear;
            pointer-events: none;
        }

        @keyframes fall {
            0% { transform: translateY(-100vh) rotate(0deg); opacity: 0.5; }
            100% { transform: translateY(100vh) rotate(360deg); opacity: 0; }
        }

        .firefly {
            position: absolute;
            width: 5px;
            height: 5px;
            background: var(--accent);
            border-radius: 50%;
            opacity: 0.6;
            animation: firefly 10s infinite ease-in-out;
            pointer-events: none;
            box-shadow: 0 0 5px var(--accent);
        }

        @keyframes firefly {
            0% { transform: translate(0, 0) scale(0.5); opacity: 0.6; }
            50% { transform: translate(40px, -40px) scale(1); opacity: 0.8; }
            100% { transform: translate(0, 0) scale(0.5); opacity: 0.6; }
        }

        .ripple {
            position: absolute;
            width: 20px;
            height: 20px;
            background: radial-gradient(circle, var(--accent) 10%, transparent 70%);
            border-radius: 50%;
            opacity: 0;
            animation: ripple 5s infinite ease-out;
            pointer-events: none;
        }

        @keyframes ripple {
            0% { transform: scale(0); opacity: 0.5; }
            50% { transform: scale(3); opacity: 0.3; }
            100% { transform: scale(5); opacity: 0; }
        }

        .hero-section {
            background: rgba(255, 255, 255, 0.9);
            backdrop-filter: blur(10px);
            border-radius: 1.5rem;
            border: 1px solid rgba(45, 106, 79, 0.15);
            box-shadow: 0 10px 30px rgba(45, 106, 79, 0.1);
            transition: transform 0.3s ease, box-shadow 0.3s ease;
        }

        .hero-section:hover {
            transform: translateY(-4px);
            box-shadow: 0 12px 20px rgba(45, 106, 79, 0.12);
        }

        .feature-card {
            background: rgba(255, 255, 255, 0.85);
            backdrop-filter: blur(8px);
            border: 1px solid rgba(45, 106, 79, 0.15);
            border-radius: 1rem;
            box-shadow: 0 5px 15px rgba(45, 106, 79, 0.08);
            transition: transform 0.3s ease, box-shadow 0.3s ease;
            position: relative;
            overflow: hidden;
        }

        .feature-card:hover {
            transform: translateY(-4px);
            box-shadow: 0 10px 20px rgba(45, 106, 79, 0.12);
        }

        /* Respect prefers-reduced-motion */
        @media (prefers-reduced-motion: reduce) {
            .hero-section,
            .feature-card {
                transition: none;
            }
            .hero-section:hover,
            .feature-card:hover {
                transform: none;
                box-shadow: 0 10px 30px rgba(45, 106, 79, 0.1); /* Maintain initial shadow */
            }
        }

        .animated-btn {
            position: relative;
            overflow: hidden;
            background: linear-gradient(45deg, var(--primary), var(--accent));
            padding: 0.75rem 1.5rem;
            border-radius: 1.5rem;
            color: #ffffff;
            font-family: 'Montserrat', sans-serif;
            font-weight: 600;
            text-transform: uppercase;
            box-shadow: 0 5px 15px rgba(45, 106, 79, 0.3);
            transition: all 0.4s ease;
            letter-spacing: 0.5px;
            font-size: 0.85rem;
        }

        .animated-btn:hover {
            transform: translateY(-5px) scale(1.05);
            box-shadow: 0 8px 20px rgba(45, 106, 79, 0.4);
        }

        .animated-btn::before {
            content: '';
            position: absolute;
            top: 0;
            left: -100%;
            width: 100%;
            height: 100%;
            background: linear-gradient(90deg, transparent, rgba(255, 255, 255, 0.2), transparent);
            transition: 0.6s;
        }

        .animated-btn:hover::before {
            left: 100%;
        }

        .logout-btn {
            background: linear-gradient(45deg, #c53030, #e53e3e);
        }

        .theme-selector select {
            background: rgba(255, 255, 255, 0.9);
            border: 1px solid var(--secondary);
            padding: 0.5rem;
            border-radius: 0.5rem;
            transition: all 0.3s ease;
        }

        .theme-selector select:hover {
            background: rgba(255, 255, 255, 1);
            border-color: var(--accent);
        }

        .timed-mode .toggle-switch {
            width: 2.5rem;
            height: 1.25rem;
            background: #e5e7eb;
            border-radius: 9999px;
            position: relative;
            transition: all 0.3s ease;
        }

        .timed-mode .toggle-switch::after {
            content: '';
            position: absolute;
            width: 1rem;
            height: 1rem;
            background: #a0aec0;
            border-radius: 50%;
            top: 0.125rem;
            left: 0.125rem;
            transition: all 0.3s ease;
        }

        .timed-mode input:checked + .toggle-switch {
            background: var(--accent);
        }

        .timed-mode input:checked + .toggle-switch::after {
            left: 1.25rem;
            background: #ffffff;
        }

        .timer {
            display: flex;
            align-items: center;
            color: var(--primary);
            font-weight: 500;
        }

        .timer.warning {
            color: var(--error);
        }

        .progress-container {
            background: #e5e7eb;
            border-radius: 9999px;
            height: 0.5rem;
            margin-bottom: 1rem;
        }

        .progress-bar {
            background: var(--accent);
            border-radius: 9999px;
            height: 100%;
            width: 0;
            transition: width 0.3s ease;
        }

        .question {
            display: none;
            opacity: 0;
            transition: opacity 0.3s ease;
        }

        .question.active {
            display: block;
            opacity: 1;
        }

        .option-label {
            display: flex;
            align-items: center;
            cursor: pointer;
            padding: 0.5rem;
            border-radius: 0.5rem;
            transition: background 0.3s ease;
        }

        .option-label:hover {
            background: rgba(0, 0, 0, 0.05);
        }

        .option-input {
            display: none;
        }

        .option-radio {
            width: 1.25rem;
            height: 1.25rem;
            border: 2px solid var(--secondary);
            border-radius: 50%;
            margin-right: 0.75rem;
            position: relative;
        }

        .option-input:checked + .option-radio {
            border-color: var(--accent);
            background: var(--accent);
        }

        .option-input:checked + .option-radio::after {
            content: '';
            position: absolute;
            width: 0.5rem;
            height: 0.5rem;
            background: #ffffff;
            border-radius: 50%;
            top: 50%;
            left: 50%;
            transform: translate(-50%, -50%);
        }

        .option-text {
            color: var(--secondary);
        }

        .earth-tip {
            background: rgba(255, 255, 255, 0.9);
            padding: 0.5rem;
            border-radius: 0.5rem;
        }

        .score-circle-container {
            display: flex;
            justify-content: center;
            margin: 1.5rem 0;
        }

        .score-circle {
            width: 120px;
            height: 120px;
            border-radius: 50%;
            position: relative;
            display: flex;
            align-items: center;
            justify-content: center;
        }

        .score-text {
            background: #ffffff;
            width: 100px;
            height: 100px;
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 1.5rem;
            font-weight: 600;
            color: var(--primary);
        }

        .badge-container .feature-icon {
            background: rgba(255, 255, 255, 0.9);
            width: 3rem;
            height: 3rem;
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            color: var(--accent);
        }

        .answer-item {
            opacity: 0;
            border-radius: 0.5rem;
        }

        .answer-item.correct {
            background: rgba(116, 198, 157, 0.1);
        }

        .answer-item.incorrect {
            background: rgba(229, 62, 62, 0.1);
        }

        .leaf-bullet {
            display: flex;
            align-items: center;
        }

        .social-icon {
            width: 2rem;
            height: 2rem;
            background: var(--accent);
            color: #ffffff;
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            transition: all 0.3s ease;
        }

        .social-icon:hover {
            background: var(--primary);
        }

        .glow-text {
            text-shadow: 0 0 5px rgba(0, 0, 0, 0.2);
        }

        .stats-value {
            color: var(--primary);
            font-weight: 600;
        }

        .back-arrow i {
            color: var(--primary);
            transition: all 0.3s ease;
        }

        .back-arrow:hover i {
            color: var(--accent);
        }

        @media (max-width: 640px) {
            .hero-section {
                padding: 1rem;
            }

            .score-circle {
                width: 100px;
                height: 100px;
            }

            .score-text {
                width: 80px;
                height: 80px;
                font-size: 1.25rem;
            }
        }
        header .logo {
    
        font-size: 24px;
        font-weight: 700;
        color: #5f687b;
    
}
    </style>
</head>
<body>
    <div class="eco-bg"></div>
    <div id="fireflies" class="fixed inset-0 pointer-events-none"></div>
    <div id="ripples" class="fixed inset-0 pointer-events-none"></div>
    <main class="container mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <section class="hero-section text-primary rounded-lg mb-8">
            <div class="p-8 md:p-12">
                <div class="flex justify-between items-center mb-8">
                    <a href="quiz_list.php" class="back-arrow" aria-label="Back to quiz list">
                        <i class="fas fa-arrow-left w-5 h-5"></i>
                    </a>
                    <div class="text-center">
                        <h1 class="text-2xl sm:text-3xl font-bold font-montserrat glow-text">Quiz Results</h1>
                        <p class="text-secondary mt-2 max-w-lg mx-auto"><?php echo htmlspecialchars($quiz['title']); ?> Results</p>
                    </div>
                    <div class="flex items-center space-x-4">
                    </div>
                </div>
                <div class="feature-card p-6">
                    <h2 class="text-xl font-semibold font-montserrat text-primary mb-4"><?php echo htmlspecialchars($quiz['title']); ?></h2>
                    <div class="score-circle-container">
                        <div class="score-circle" style="background: conic-gradient(var(--accent) <?php echo $percentage; ?>%, #e5e7eb <?php echo $percentage; ?>%);">
                            <div class="score-text"><?php echo number_format($percentage, 0); ?>%</div>
                        </div>
                    </div>
                    <p class="text-center text-secondary mt-4">Your Score: <span class="stats-value"><?php echo $score; ?> / <?php echo $totalQuestions; ?></span></p>
                    <div class="badge-container mt-6 text-center">
                        <div class="feature-icon mx-auto">
                            <i class="<?php echo $badgeIcon; ?> text-2xl"></i>
                        </div>
                        <div class="badge-level text-lg font-semibold text-primary mt-4"><?php echo $badgeLevel; ?></div>
                        <p class="badge-message text-secondary mt-2"><?php echo $badgeMessage; ?></p>
                    </div>
                    <div class="eco-points mt-4 text-center">
                        <i class="fas fa-leaf text-accent mr-2"></i>
                        You earned <span class="stats-value"><?php echo $ecoPoints; ?></span> EcoPoints!
                    </div>
                    <div class="earth-tip mt-6 flex items-center">
                        <i class="fas fa-lightbulb text-accent mr-3"></i>
                        <p class="text-secondary">Every quiz you take helps you learn sustainable practices that reduce your carbon footprint!</p>
                    </div>
                    <div class="answer-review mt-8">
                        <h3 class="text-lg font-semibold font-montserrat text-primary mb-4">Your Answers</h3>
                        <?php foreach ($results as $index => $result): ?>
                            <div class="feature-card answer-item p-4 mb-4 <?php echo $result['is_correct'] ? 'correct' : 'incorrect'; ?>">
                                <h4 class="text-base font-medium text-primary">Question <?php echo $index + 1; ?>: <?php echo htmlspecialchars($result['question_text']); ?></h4>
                                <?php if ($result['is_correct']): ?>
                                    <p class="text-secondary mt-2 leaf-bullet"><i class="fas fa-check-circle text-accent mr-2"></i> Correct! You selected: <span class="font-medium"><?php echo htmlspecialchars($result['user_answer']); ?></span></p>
                                <?php else: ?>
                                    <p class="text-secondary mt-2 leaf-bullet"><i class="fas fa-times-circle text-error mr-2"></i> Incorrect. You selected: <span class="font-medium"><?php echo htmlspecialchars($result['user_answer']); ?></span></p>
                                    <p class="text-secondary leaf-bullet">Correct answer: <span class="font-medium"><?php echo htmlspecialchars($result['correct_answer']); ?></span></p>
                                <?php endif; ?>
                            </div>
                        <?php endforeach; ?>
                    </div>
                    <div class="action-buttons flex justify-center gap-4 mt-8 flex-col sm:flex-row">
                        <a href="take_quiz.php?id=<?php echo $quizId; ?>" class="animated-btn" aria-label="Retake this quiz">
                            <i class="fas fa-redo mr-2"></i> Retake Quiz
                        </a>
                        <a href="quiz_list.php" class="animated-btn leaderboard-btn" aria-label="View more quizzes">
                            <i class="fas fa-th-list mr-2"></i> More Challenges
                        </a>
                        <a href="generate_pdf.php?id=<?php echo $quizId; ?>" class="animated-btn" aria-label="Download PDF">
                            <i class="fas fa-file-pdf mr-2"></i> Download PDF
                        </a>
                    </div>
                    <div class="social-share mt-8 text-center">
                        <h4 class="text-base font-semibold font-montserrat text-primary mb-4">Share Your Achievement</h4>
                        <div class="social-icons flex justify-center gap-4">
                            <?php
                            $shareText = urlencode("I scored $percentage% on the {$quiz['title']} EcoChallenge! 🌍 Join me at Trash2Treasure!");
                            $shareUrl = urlencode("https://trash2treasure.com/quiz_list.php");
                            ?>
                            <a href="https://www.facebook.com/sharer/sharer.php?u=<?php echo $shareUrl; ?>" target="_blank" rel="noopener noreferrer" class="social-icon" aria-label="Share on Facebook"><i class="fab fa-facebook-f"></i></a>
                            <a href="https://twitter.com/intent/tweet?text=<?php echo $shareText; ?>&url=<?php echo $shareUrl; ?>" target="_blank" rel="noopener noreferrer" class="social-icon" aria-label="Share on Twitter"><i class="fab fa-twitter"></i></a>
                            <a href="https://www.linkedin.com/sharing/share-offsite/?url=<?php echo $shareUrl; ?>" target="_blank" rel="noopener noreferrer" class="social-icon" aria-label="Share on LinkedIn"><i class="fab fa-linkedin-in"></i></a>
                        </div>
                    </div>
                </div>
            </div>
        </section>
    </main>
    <script>
        // Firefly animation
        const firefliesContainer = document.getElementById('fireflies');
        for (let i = 0; i < 25; i++) {
            const firefly = document.createElement('div');
            firefly.className = 'firefly';
            firefly.style.left = `${Math.random() * 100}vw`;
            firefly.style.top = `${Math.random() * 100}vh`;
            firefly.style.animationDelay = `${Math.random() * 5}s`;
            firefly.style.animationDuration = `${6 + Math.random() * 4}s`;
            firefliesContainer.appendChild(firefly);
        }

        // Falling leaves
        for (let i = 0; i < 15; i++) {
            const leaf = document.createElement('div');
            leaf.className = 'leaf';
            leaf.style.left = `${Math.random() * 100}vw`;
            leaf.style.animationDelay = `${Math.random() * 10}s`;
            leaf.style.animationDuration = `${15 + Math.random() * 10}s`;
            firefliesContainer.appendChild(leaf);
        }

        // Water ripple effect
        const ripplesContainer = document.getElementById('ripples');
        for (let i = 0; i < 10; i++) {
            const ripple = document.createElement('div');
            ripple.className = 'ripple';
            ripple.style.left = `${Math.random() * 100}vw`;
            ripple.style.top = `${Math.random() * 100}vh`;
            ripple.style.animationDelay = `${Math.random() * 5}s`;
            ripple.style.animationDuration = `${3 + Math.random() * 2}s`;
            ripplesContainer.appendChild(ripple);
        }

        // Answer animation
        document.querySelectorAll('.answer-item').forEach((item, index) => {
            setTimeout(() => {
                item.style.transition = 'opacity 0.5s ease';
                item.style.opacity = '1';
            }, index * 500);
        });
    </script>
</body>
</html>
<?php
} else {
?>
<!DOCTYPE html>
<html lang="en" data-theme="forest">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>EcoChallenge Quiz - <?php echo htmlspecialchars($quiz['title']); ?></title>
    <script src="https://cdn.tailwindcss.com"></script>
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700&family=Montserrat:wght@400;600;700&display=swap" rel="stylesheet">
    <style>
        :root {
            --forest-green: #1b4332;
            --leaf-green: #2d6a4f;
            --mint-green: #74c69d;
            --ocean-blue: #4fc3f7;
            --desert-sand: #d4a373;
            --error-red: #e53e3e;
        }

        [data-theme="forest"] {
            --primary: var(--forest-green);
            --secondary: #4a5568;
            --accent: var(--mint-green);
            --error: var(--error-red);
        }

        [data-theme="ocean"] {
            --primary: #2b6cb0;
            --secondary: #2d3748;
            --accent: var(--ocean-blue);
            --error: var(--error-red);
        }

        [data-theme="desert"] {
            --primary: #7b4e2a;
            --secondary: #4a5568;
            --accent: var(--desert-sand);
            --error: var(--error-red);
        }

        body {
            font-family: 'Poppins', sans-serif;
            background: linear-gradient(135deg, #f8f9fa 0%, #ffffff 100%);
            color: var(--secondary);
            min-height: 100vh;
            position: relative;
            overflow-x: hidden;
        }

        .eco-bg {
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background: url("data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 1440 810'%3E%3Cpath d='M0 200C200 150 400 250 600 200C800 150 1000 300 1200 250C1400 200 1600 350 1800 300' fill='none' stroke='%2374c69d' stroke-width='3' opacity='0.15'/%3E%3Cpath d='M0 400C200 350 400 450 600 400C800 350 1000 500 1200 450C1400 400 1600 550 1800 500' fill='none' stroke='%232d6a4f' stroke-width='2' opacity='0.1'/%3E%3C/svg%3E");
            background-size: cover;
            z-index: -1;
            animation: canopy 40s infinite ease-in-out;
        }

        @keyframes canopy {
            0% { transform: translateY(0) scale(1); }
            50% { transform: translateY(-15px) scale(1.01); }
            100% { transform: translateY(0) scale(1); }
        }

        .leaf {
            position: absolute;
            width: 18px;
            height: 18px;
            background: url("data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 24 24' fill='%2374c69d'%3E%3Cpath d='M17 8C8 10 5.9 16.17 5.9 16.17c-1.5 3.83.83 5.86 2.62 6.67 2.37 1.06 5.92.24 5.92.24 3.78-.85 6.66-3.35 7.05-8.8 2.77-1 4.45-2.68 4.45-4.85C26 4.24 19 5.22 17 8zM10.45 16.89a5.2 5.2 0 01-2.91-3.4c-.13-.68.04-1.57.52-2.32a3.02 3.02 0 012.02-1.15c.39-.07.77-.05 1.15.06.76.22 1.47.7 2.09 1.42.62.72 1.07 1.61 1.21 2.63.07.51.07.99 0 1.45-.14.93-.57 1.76-1.23 2.45-.67.69-1.51 1.25-2.45 1.68a7.72 7.72 0 01-2.88.65 5.59 5.59 0 01-2.9-.55c-.76-.34-1.41-.85-1.93-1.5'/%3E%3C/svg%3E");
            background-size: cover;
            opacity: 0.5;
            animation: fall 20s infinite linear;
            pointer-events: none;
        }

        @keyframes fall {
            0% { transform: translateY(-100vh) rotate(0deg); opacity: 0.5; }
            100% { transform: translateY(100vh) rotate(360deg); opacity: 0; }
        }

        .firefly {
            position: absolute;
            width: 5px;
            height: 5px;
            background: var(--accent);
            border-radius: 50%;
            opacity: 0.6;
            animation: firefly 10s infinite ease-in-out;
            pointer-events: none;
            box-shadow: 0 0 5px var(--accent);
        }

        @keyframes firefly {
            0% { transform: translate(0, 0) scale(0.5); opacity: 0.6; }
            50% { transform: translate(40px, -40px) scale(1); opacity: 0.8; }
            100% { transform: translate(0, 0) scale(0.5); opacity: 0.6; }
        }

        .ripple {
            position: absolute;
            width: 20px;
            height: 20px;
            background: radial-gradient(circle, var(--accent) 10%, transparent 70%);
            border-radius: 50%;
            opacity: 0;
            animation: ripple 5s infinite ease-out;
            pointer-events: none;
        }

        @keyframes ripple {
            0% { transform: scale(0); opacity: 0.5; }
            50% { transform: scale(3); opacity: 0.3; }
            100% { transform: scale(5); opacity: 0; }
        }

        .hero-section {
            background: rgba(255, 255, 255, 0.9);
            backdrop-filter: blur(10px);
            border-radius: 1.5rem;
            border: 1px solid rgba(45, 106, 79, 0.15);
            box-shadow: 0 10px 30px rgba(45, 106, 79, 0.1);
            transition: transform 0.3s ease, box-shadow 0.3s ease;
        }

        .hero-section:hover {
            transform: translateY(-4px);
            box-shadow: 0 12px 20px rgba(45, 106, 79, 0.12);
        }

        .feature-card {
            background: rgba(255, 255, 255, 0.85);
            backdrop-filter: blur(8px);
            border: 1px solid rgba(45, 106, 79, 0.15);
            border-radius: 1rem;
            box-shadow: 0 5px 15px rgba(45, 106, 79, 0.08);
            transition: transform 0.3s ease, box-shadow 0.3s ease;
            position: relative;
            overflow: hidden;
        }

        .feature-card:hover {
            transform: translateY(-4px);
            box-shadow: 0 10px 20px rgba(45, 106, 79, 0.12);
        }

        /* Respect prefers-reduced-motion */
        @media (prefers-reduced-motion: reduce) {
            .hero-section,
            .feature-card {
                transition: none;
            }
            .hero-section:hover,
            .feature-card:hover {
                transform: none;
                box-shadow: 0 10px 30px rgba(45, 106, 79, 0.1); /* Maintain initial shadow */
            }
        }

        .animated-btn {
            position: relative;
            overflow: hidden;
            background: linear-gradient(45deg, var(--primary), var(--accent));
            padding: 0.75rem 1.5rem;
            border-radius: 1.5rem;
            color: #ffffff;
            font-family: 'Montserrat', sans-serif;
            font-weight: 600;
            text-transform: uppercase;
            box-shadow: 0 5px 15px rgba(45, 106, 79, 0.3);
            transition: all 0.4s ease;
            letter-spacing: 0.5px;
            font-size: 0.85rem;
        }

        .animated-btn:hover {
            transform: translateY(-5px) scale(1.05);
            box-shadow: 0 8px 20px rgba(45, 106, 79, 0.4);
        }

        .animated-btn::before {
            content: '';
            position: absolute;
            top: 0;
            left: -100%;
            width: 100%;
            height: 100%;
            background: linear-gradient(90deg, transparent, rgba(255, 255, 255, 0.2), transparent);
            transition: 0.6s;
        }

        .animated-btn:hover::before {
            left: 100%;
        }

        .logout-btn {
            background: linear-gradient(45deg, #c53030, #e53e3e);
        }

        .theme-selector select {
            background: rgba(255, 255, 255, 0.9);
            border: 1px solid var(--secondary);
            padding: 0.5rem;
            border-radius: 0.5rem;
            transition: all 0.3s ease;
        }

        .theme-selector select:hover {
            background: rgba(255, 255, 255, 1);
            border-color: var(--accent);
        }

        .timed-mode .toggle-switch {
            width: 2.5rem;
            height: 1.25rem;
            background: #e5e7eb;
            border-radius: 9999px;
            position: relative;
            transition: all 0.3s ease;
        }

        .timed-mode .toggle-switch::after {
            content: '';
            position: absolute;
            width: 1rem;
            height: 1rem;
            background: #a0aec0;
            border-radius: 50%;
            top: 0.125rem;
            left: 0.125rem;
            transition: all 0.3s ease;
        }

        .timed-mode input:checked + .toggle-switch {
            background: var(--accent);
        }

        .timed-mode input:checked + .toggle-switch::after {
            left: 1.25rem;
            background: #ffffff;
        }

        .timer {
            display: flex;
            align-items: center;
            color: var(--primary);
            font-weight: 500;
        }

        .timer.warning {
            color: var(--error);
        }

        .progress-container {
            background: #e5e7eb;
            border-radius: 9999px;
            height: 0.5rem;
            margin-bottom: 1rem;
        }

        .progress-bar {
            background: var(--accent);
            border-radius: 9999px;
            height: 100%;
            width: 0;
            transition: width 0.3s ease;
        }

        .question {
            display: none;
            opacity: 0;
            transition: opacity 0.3s ease;
        }

        .question.active {
            display: block;
            opacity: 1;
        }

        .option-label {
            display: flex;
            align-items: center;
            cursor: pointer;
            padding: 0.5rem;
            border-radius: 0.5rem;
            transition: background 0.3s ease;
        }

        .option-label:hover {
            background: rgba(0, 0, 0, 0.05);
        }

        .option-input {
            display: none;
        }

        .option-radio {
            width: 1.25rem;
            height: 1.25rem;
            border: 2px solid var(--secondary);
            border-radius: 50%;
            margin-right: 0.75rem;
            position: relative;
        }

        .option-input:checked + .option-radio {
            border-color: var(--accent);
            background: var(--accent);
        }

        .option-input:checked + .option-radio::after {
            content: '';
            position: absolute;
            width: 0.5rem;
            height: 0.5rem;
            background: #ffffff;
            border-radius: 50%;
            top: 50%;
            left: 50%;
            transform: translate(-50%, -50%);
        }

        .option-text {
            color: var(--secondary);
        }

        .earth-tip {
            background: rgba(255, 255, 255, 0.9);
            padding: 0.5rem;
            border-radius: 0.5rem;
        }

        .score-circle-container {
            display: flex;
            justify-content: center;
            margin: 1.5rem 0;
        }

        .score-circle {
            width: 120px;
            height: 120px;
            border-radius: 50%;
            position: relative;
            display: flex;
            align-items: center;
            justify-content: center;
        }

        .score-text {
            background: #ffffff;
            width: 100px;
            height: 100px;
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 1.5rem;
            font-weight: 600;
            color: var(--primary);
        }

        .badge-container .feature-icon {
            background: rgba(255, 255, 255, 0.9);
            width: 3rem;
            height: 3rem;
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            color: var(--accent);
        }

        .answer-item {
            opacity: 0;
            border-radius: 0.5rem;
        }

        .answer-item.correct {
            background: rgba(116, 198, 157, 0.1);
        }

        .answer-item.incorrect {
            background: rgba(229, 62, 62, 0.1);
        }

        .leaf-bullet {
            display: flex;
            align-items: center;
        }

        .social-icon {
            width: 2rem;
            height: 2rem;
            background: var(--accent);
            color: #ffffff;
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            transition: all 0.3s ease;
        }

        .social-icon:hover {
            background: var(--primary);
        }

        .glow-text {
            text-shadow: 0 0 5px rgba(0, 0, 0, 0.2);
        }

        .stats-value {
            color: var(--primary);
            font-weight: 600;
        }

        .back-arrow i {
            color: var(--primary);
            transition: all 0.3s ease;
        }

        .back-arrow:hover i {
            color: var(--accent);
        }

        @media (max-width: 640px) {
            .hero-section {
                padding: 1rem;
            }

            .score-circle {
                width: 100px;
                height: 100px;
            }

            .score-text {
                width: 80px;
                height: 80px;
                font-size: 1.25rem;
            }
        }
    </style>
</head>
<body>
    <div class="eco-bg"></div>
    <div id="fireflies" class="fixed inset-0 pointer-events-none"></div>
    <div id="ripples" class="fixed inset-0 pointer-events-none"></div>
    <main class="container mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <section class="hero-section text-primary rounded-lg mb-8">
            <div class="p-8 md:p-12">
                <div class="flex justify-between items-center mb-8">
                    <a href="quiz_list.php" class="back-arrow" aria-label="Back to quiz list">
                        <i class="fas fa-arrow-left w-5 h-5"></i>
                    </a>
                    <div class="text-center">
                        <h1 class="text-2xl sm:text-3xl font-bold font-montserrat glow-text"><?php echo htmlspecialchars($quiz['title']); ?></h1>
                        <p class="text-secondary mt-2 max-w-lg mx-auto"><?php echo htmlspecialchars($quiz['description']); ?></p>
                    </div>
                    <div class="flex items-center space-x-4">
                        <span class="text-primary font-semibold"><?php echo htmlspecialchars($currentUser['username']); ?></span>
                        <a href="logout.php" class="animated-btn logout-btn" aria-label="Log out">
                            <i class="fas fa-sign-out-alt mr-2"></i>Log Out
                        </a>
                    </div>
                </div>
                <div class="quiz-controls flex flex-col sm:flex-row gap-4 mb-6" aria-label="Quiz controls">
                    <div class="theme-selector">
                        <label for="themeSelect" class="text-primary font-medium">Select Theme:</label>
                        <select id="themeSelect" class="ml-2 p-3 rounded-lg bg-[rgba(255,255,255,0.9)] border border-secondary" aria-label="Select theme">
                            <option value="forest" selected data-icon="leaf">Forest</option>
                            <option value="ocean" data-icon="water">Ocean</option>
                            <option value="desert" data-icon="sun">Desert</option>
                        </select>
                    </div>
                    <label class="timed-mode inline-flex items-center cursor-pointer" for="timedMode">
                        <input type="checkbox" id="timedMode" name="timedMode" class="opacity-0 absolute" aria-checked="false">
                        <span class="toggle-switch"></span>
                        <span class="timed-mode-label text-primary font-medium">Timed Mode: Off</span>
                    </label>
                    <div id="timerDisplay" class="timer" style="display: none;" aria-live="assertive"></div>
                </div>
                <div class="feature-card p-6">
                    <div class="progress-container">
                        <div class="progress-bar"></div>
                    </div>
                    <form method="POST" action="" id="quizForm" data-timed="false">
                        <input type="hidden" id="timeTaken" name="timeTaken" value="600">
                        <?php foreach ($questions as $index => $question): ?>
                            <div class="question feature-card p-4 mb-6 <?php echo $index === 0 ? 'active' : ''; ?>" data-question="<?php echo $index; ?>">
                                <p class="question-number text-sm text-secondary uppercase font-semibold mb-2">Question <?php echo $index + 1; ?> of <?php echo count($questions); ?></p>
                                <p class="question-text text-lg font-semibold text-primary mb-4"><?php echo htmlspecialchars($question['question_text']); ?></p>
                                <div class="options-container space-y-3">
                                    <label for="question-<?php echo $question['id']; ?>-option-a" class="option-label">
                                        <input type="radio" id="question-<?php echo $question['id']; ?>-option-a" name="answers[<?php echo $question['id']; ?>]" value="a" class="option-input" required aria-label="Option A">
                                        <span class="option-radio"></span>
                                        <span class="option-text"><?php echo htmlspecialchars($question['option_a']); ?></span>
                                    </label>
                                    <label for="question-<?php echo $question['id']; ?>-option-b" class="option-label">
                                        <input type="radio" id="question-<?php echo $question['id']; ?>-option-b" name="answers[<?php echo $question['id']; ?>]" value="b" class="option-input" aria-label="Option B">
                                        <span class="option-radio"></span>
                                        <span class="option-text"><?php echo htmlspecialchars($question['option_b']); ?></span>
                                    </label>
                                    <?php if (!empty($question['option_c'])): ?>
                                        <label for="question-<?php echo $question['id']; ?>-option-c" class="option-label">
                                            <input type="radio" id="question-<?php echo $question['id']; ?>-option-c" name="answers[<?php echo $question['id']; ?>]" value="c" class="option-input" aria-label="Option C">
                                            <span class="option-radio"></span>
                                            <span class="option-text"><?php echo htmlspecialchars($question['option_c']); ?></span>
                                        </label>
                                    <?php endif; ?>
                                    <?php if (!empty($question['option_d'])): ?>
                                        <label for="question-<?php echo $question['id']; ?>-option-d" class="option-label">
                                            <input type="radio" id="question-<?php echo $question['id']; ?>-option-d" name="answers[<?php echo $question['id']; ?>]" value="d" class="option-input" aria-label="Option D">
                                            <span class="option-radio"></span>
                                            <span class="option-text"><?php echo htmlspecialchars($question['option_d']); ?></span>
                                        </label>
                                    <?php endif; ?>
                                </div>
                                <div class="earth-tip flex items-center mt-4">
                                    <i class="fas fa-lightbulb text-accent mr-3"></i>
                                    <p class="text-secondary"><?php
                                        $tips = [
                                            "Switching to LED bulbs can save up to 80% energy compared to traditional bulbs!",
                                            "Reducing water waste by fixing leaks can save thousands of gallons annually!",
                                            "Composting food scraps can reduce landfill waste by up to 30%!",
                                            "Using reusable bags cuts down on millions of plastic bags each year!"
                                        ];
                                        echo $tips[$index % count($tips)];
                                    ?></p>
                                </div>
                            </div>
                        <?php endforeach; ?>
                        <div class="navigation-buttons flex justify-between mt-8 flex-col sm:flex-row gap-4">
                            <button type="button" class="animated-btn btn-prev" disabled aria-label="Previous question">
                                <i class="fas fa-arrow-left mr-2"></i> Previous
                            </button>
                            <button type="button" class="animated-btn btn-next" aria-label="Next question">
                                Next <i class="fas fa-arrow-right ml-2"></i>
                            </button>
                            <button type="submit" class="animated-btn btn-submit" aria-label="Submit quiz">
                                Submit Quiz <i class="fas fa-check ml-2"></i>
                            </button>
                        </div>
                    </form>
                </div>
            </div>
        </section>
    </main>
    <script>
        // Firefly animation
        const firefliesContainer = document.getElementById('fireflies');
        for (let i = 0; i < 25; i++) {
            const firefly = document.createElement('div');
            firefly.className = 'firefly';
            firefly.style.left = `${Math.random() * 100}vw`;
            firefly.style.top = `${Math.random() * 100}vh`;
            firefly.style.animationDelay = `${Math.random() * 5}s`;
            firefly.style.animationDuration = `${6 + Math.random() * 4}s`;
            firefliesContainer.appendChild(firefly);
        }

        // Falling leaves
        for (let i = 0; i < 15; i++) {
            const leaf = document.createElement('div');
            leaf.className = 'leaf';
            leaf.style.left = `${Math.random() * 100}vw`;
            leaf.style.animationDelay = `${Math.random() * 10}s`;
            leaf.style.animationDuration = `${15 + Math.random() * 10}s`;
            firefliesContainer.appendChild(leaf);
        }

        // Water ripple effect
        const ripplesContainer = document.getElementById('ripples');
        for (let i = 0; i < 10; i++) {
            const ripple = document.createElement('div');
            ripple.className = 'ripple';
            ripple.style.left = `${Math.random() * 100}vw`;
            ripple.style.top = `${Math.random() * 100}vh`;
            ripple.style.animationDelay = `${Math.random() * 5}s`;
            ripple.style.animationDuration = `${3 + Math.random() * 2}s`;
            ripplesContainer.appendChild(ripple);
        }

        // Theme selector
        const themeSelect = document.getElementById('themeSelect');
        themeSelect.addEventListener('change', (e) => {
            document.documentElement.setAttribute('data-theme', e.target.value);
            updateTimerIcon();
        });

        // Quiz navigation and timed mode
        const questions = document.querySelectorAll('.question');
        const prevBtn = document.querySelector('.btn-prev');
        const nextBtn = document.querySelector('.btn-next');
        const submitBtn = document.querySelector('.btn-submit');
        const progressBar = document.querySelector('.progress-bar');
        const form = document.querySelector('#quizForm');
        const timedModeCheckbox = document.getElementById('timedMode');
        const timedModeLabel = document.querySelector('.timed-mode-label');
        const timerDisplay = document.getElementById('timerDisplay');
        const timeTakenInput = document.getElementById('timeTaken');
        let currentQuestion = 0;
        let timeLeft = 200;
        let timerInterval = null;
        const totalQuestions = questions.length;

        function updateTimerIcon() {
            const theme = document.documentElement.dataset.theme;
            let iconClass = 'fas fa-leaf';
            if (theme === 'ocean') iconClass = 'fas fa-water';
            else if (theme === 'desert') iconClass = 'fas fa-sun';
            timerDisplay.innerHTML = `<i class="${iconClass} text-accent mr-2"></i> Time Left: ${Math.floor(timeLeft / 60)}:${(timeLeft % 60).toString().padStart(2, '0')}`;
        }

        function startTimer() {
            if (timerInterval) {
                clearInterval(timerInterval);
            }
            timerDisplay.style.display = 'flex';
            form.dataset.timed = 'true';
            timedModeCheckbox.setAttribute('aria-checked', 'true');
            timedModeLabel.textContent = 'Timed Mode: On';
            timeLeft = 200;
            updateTimerIcon();
            timerInterval = setInterval(() => {
                timeLeft--;
                timeTakenInput.value = 600 - timeLeft;
                timerDisplay.innerHTML = `<i class="${document.documentElement.dataset.theme === 'ocean' ? 'fas fa-water' : document.documentElement.dataset.theme === 'desert' ? 'fas fa-sun' : 'fas fa-leaf'} text-accent mr-2"></i> Time Left: ${Math.floor(timeLeft / 60)}:${(timeLeft % 60).toString().padStart(2, '0')}`;
                if (timeLeft <= 30) {
                    timerDisplay.classList.add('warning');
                }
                if (timeLeft <= 0) {
                    clearInterval(timerInterval);
                    timerInterval = null;
                    form.submit();
                }
            }, 1000);
        }

        function stopTimer() {
            if (timerInterval) {
                clearInterval(timerInterval);
                timerInterval = null;
            }
            timerDisplay.style.display = 'none';
            timerDisplay.classList.remove('warning');
            form.dataset.timed = 'false';
            timedModeCheckbox.setAttribute('aria-checked', 'false');
            timedModeLabel.textContent = 'Timed Mode: Off';
            timeLeft = 200;
            timeTakenInput.value = 600;
            timerDisplay.innerHTML = '';
        }

        timedModeCheckbox.addEventListener('change', (e) => {
            timedModeLabel.textContent = `Timed Mode: ${e.target.checked ? 'On' : 'Off'}`;
            if (e.target.checked) {
                startTimer();
            } else {
                stopTimer();
            }
        });

        function updateProgress() {
            const progress = ((currentQuestion + 1) / totalQuestions) * 100;
            progressBar.style.width = `${progress}%`;
        }

        function showQuestion(index) {
            questions.forEach((q, i) => {
                q.classList.toggle('active', i === index);
            });
            prevBtn.disabled = index === 0;
            nextBtn.style.display = index === totalQuestions - 1 ? 'none' : 'inline-flex';
            submitBtn.style.display = index === totalQuestions - 1 ? 'inline-flex' : 'none';
            updateProgress();
        }

        prevBtn.addEventListener('click', () => {
            if (currentQuestion > 0) {
                currentQuestion--;
                showQuestion(currentQuestion);
            }
        });

        nextBtn.addEventListener('click', () => {
            if (currentQuestion < totalQuestions - 1) {
                const currentInputs = questions[currentQuestion].querySelectorAll('.option-input');
                let answered = false;
                currentInputs.forEach(input => {
                    if (input.checked) answered = true;
                });
                if (answered) {
                    currentQuestion++;
                    showQuestion(currentQuestion);
                } else {
                    alert('Please select an answer before proceeding.');
                }
            }
        });

        form.addEventListener('submit', (e) => {
            let allAnswered = true;
            questions.forEach((question, index) => {
                const inputs = question.querySelectorAll('.option-input');
                let answered = false;
                inputs.forEach(input => {
                    if (input.checked) answered = true;
                });
                if (!answered) allAnswered = false;
            });
            if (!allAnswered) {
                e.preventDefault();
                alert('Please answer all questions before submitting.');
            } else if (form.dataset.timed === 'true') {
                stopTimer();
            }
        });

        showQuestion(currentQuestion);
    </script>
</body>
</html>
<?php
}
?>