<?php
require_once '../../controllers/UserController.php';
require_once '../../controllers/ReferralController.php';
include 'db_connect.php';
session_start();

// Vérifier si l'utilisateur est connecté
$isLoggedIn = isset($_SESSION["user"]) && isset($_SESSION["user"]["user_id"]);

if ($isLoggedIn) {
    $user_id = $_SESSION["user"]["user_id"];
    $query = "SELECT * FROM users WHERE user_id = :user_id";
    $stmt = $pdo->prepare($query);
    $stmt->execute([':user_id' => $user_id]);
    $user = $stmt->fetch(PDO::FETCH_ASSOC);
}
// Vérifier si l'utilisateur est connecté
if (!isset($_SESSION["user"]) || !isset($_SESSION["user"]["user_id"])) {
  header('Location: ../../auth/login.php');
  exit;
}

$userController = new UserController();
$referralController = new ReferralController();
$currentUser = $userController->getCurrentUser();

if (!$currentUser) {
    header('Location: login.php');
    exit;
}

// Ensure referral code exists
$codeResult = $referralController->generateReferralCode($currentUser['id']);
$referralCode = $codeResult['success'] ? $codeResult['code'] : null;
$referralLink = $referralCode ? "http://localhost/khademni/quiz/views/frontoffice/register.php?ref=" . urlencode($referralCode) : '#';
$referralStats = $referralController->getReferralStats($currentUser['id']);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Invite Friends - Trash2Treasure</title>
    <link href="https://cdn.jsdelivr.net/npm/tailwindcss@2.0.2/dist/tailwind.min.css" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700&family=Montserrat:wght@400;600;700&display=swap" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css" rel="stylesheet">
    <style>
        :root {
            --forest-green: #1b4332;
            --leaf-green: #2d6a4f;
            --mint-green: #74c69d;
            --light-mint: #b7e4c7;
            --cream: #f8f9fa;
            --soft-white: #ffffff;
            --water-blue: #4fc3f7;
        }

        body {
            font-family: 'Poppins', sans-serif;
            background: linear-gradient(135deg, var(--cream) 0%, var(--soft-white) 100%);
            background-attachment: fixed;
            color: #2d3748;
            overflow-x: hidden;
            position: relative;
            min-height: 100vh;
        }

        .eco-bg {
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background: url("data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 1440 810'%3E%3Cpath d='M0 200C200 150 400 250 600 200C800 150 1000 300 1200 250C1400 200 1600 350 1800 300' fill='none' stroke='%2374c69d' stroke-width='3' opacity='0.15'/%3E%3Cpath d='M0 400C200 350 400 450 600 400C800 350 1000 500 1200 450C1400 400 1600 550 1800 500' fill='none' stroke='%232d6a4f' stroke-width='2' opacity='0.1'/%3E%3C/svg%3E");
            background-size: cover;
            z-index: -1;
            animation: canopy 40s infinite ease-in-out;
        }

        @keyframes canopy {
            0% { transform: translateY(0) scale(1); }
            50% { transform: translateY(-15px) scale(1.01); }
            100% { transform: translateY(0) scale(1); }
        }

        .leaf {
            position: absolute;
            width: 18px;
            height: 18px;
            background: url("data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 24 24' fill='%2374c69d'%3E%3Cpath d='M17 8C8 10 5.9 16.17 5.9 16.17c-1.5 3.83.83 5.86 2.62 6.67 2.37 1.06 5.92.24 5.92.24 3.78-.85 6.66-3.35 7.05-8.8 2.77-1 4.45-2.68 4.45-4.85C26 4.24 19 5.22 17 8zM10.45 16.89a5.2 5.2 0 01-2.91-3.4c-.13-.68.04-1.57.52-2.32a3.02 3.02 0 012.02-1.15c.39-.07.77-.05 1.15.06.76.22 1.47.7 2.09 1.42.62.72 1.07 1.61 1.21 2.63.07.51.07.99 0 1.45-.14.93-.57 1.76-1.23 2.45-.67.69-1.51 1.25-2.45 1.68a7.72 7.72 0 01-2.88.65 5.59 5.59 0 01-2.9-.55c-.76-.34-1.41-.85-1.93-1.5'/%3E%3C/svg%3E");
            background-size: cover;
            opacity: 0.5;
            animation: fall 20s infinite linear;
            pointer-events: none;
        }

        @keyframes fall {
            0% { transform: translateY(-100vh) rotate(0deg); opacity: 0.5; }
            100% { transform: translateY(100vh) rotate(360deg); opacity: 0; }
        }

        .firefly {
            position: absolute;
            width: 5px;
            height: 5px;
            background: var(--mint-green);
            border-radius: 50%;
            opacity: 0.6;
            animation: firefly 10s infinite ease-in-out;
            pointer-events: none;
            box-shadow: 0 0 5px var(--mint-green);
        }

        @keyframes firefly {
            0% { transform: translate(0, 0) scale(0.5); opacity: 0.6; }
            50% { transform: translate(40px, -40px) scale(1); opacity: 0.8; }
            100% { transform: translate(0, 0) scale(0.5); opacity: 0.6; }
        }

        .ripple {
            position: absolute;
            width: 20px;
            height: 20px;
            background: radial-gradient(circle, var(--water-blue) 10%, transparent 70%);
            border-radius: 50%;
            opacity: 0;
            animation: ripple 5s infinite ease-out;
            pointer-events: none;
        }

        @keyframes ripple {
            0% { transform: scale(0); opacity: 0.5; }
            50% { transform: scale(3); opacity: 0.3; }
            100% { transform: scale(5); opacity: 0; }
        }

        .referral-section {
            background: rgba(255, 255, 255, 0.9);
            backdrop-filter: blur(10px);
            border-radius: 1.5rem;
            border: 1px solid rgba(45, 106, 79, 0.15);
            position: relative;
            transition: transform 0.6s ease, box-shadow 0.6s ease;
            overflow: hidden;
            box-shadow: 0 10px 30px rgba(45, 106, 79, 0.1);
            z-index: 10;
        }

        .referral-section:hover {
            transform: perspective(1200px) rotateX(2deg) rotateY(2deg);
            box-shadow: 0 15px 35px rgba(45, 106, 79, 0.15);
        }

        .animated-btn {
            position: relative;
            overflow: hidden;
            background: linear-gradient(45deg, var(--forest-green), var(--leaf-green));
            padding: 0.75rem 1.5rem;
            border-radius: 1.5rem;
            color: var(--soft-white);
            font-family: 'Montserrat', sans-serif;
            font-weight: 600;
            text-transform: uppercase;
            box-shadow: 0 5px 15px rgba(45, 106, 79, 0.3);
            transition: all 0.4s ease;
            letter-spacing: 0.5px;
            font-size: 0.85rem;
            z-index: 20;
        }

        .animated-btn:hover {
            transform: translateY(-5px) scale(1.05);
            box-shadow: 0 8px 20px rgba(45, 106, 79, 0.4);
        }

        .animated-btn::before {
            content: '';
            position: absolute;
            top: 0;
            left: -100%;
            width: 100%;
            height: 100%;
            background: linear-gradient(90deg, transparent, rgba(255, 255, 255, 0.2), transparent);
            transition: 0.6s;
        }

        .animated-btn:hover::before {
            left: 100%;
        }

        .referral-btn {
            background: linear-gradient(45deg, var(--mint-green), var(--water-blue));
            color: var(--forest-green);
        }

        .logout-btn {
            background: linear-gradient(45deg, #c53030, #e53e3e);
        }

        .back-arrow {
            background: linear-gradient(45deg, var(--forest-green), var(--leaf-green));
            color: var(--soft-white);
            border-radius: 50%;
            padding: 8px;
            display: flex;
            align-items: center;
            justify-content: center;
            transition: all 0.3s ease;
            box-shadow: 0 2px 5px rgba(45, 106, 79, 0.3);
        }

        .back-arrow:hover {
            transform: translateX(-3px);
            box-shadow: 0 4px 10px rgba(45, 106, 79, 0.4);
        }

        .referral-input {
            background: rgba(255, 255, 255, 0.9);
            border: 1px solid rgba(45, 106, 79, 0.3);
            border-radius: 0.5rem;
            padding: 0.5rem;
            width: 100%;
            font-family: 'Poppins', sans-serif;
            color: var(--forest-green);
        }

        .referral-input:focus {
            outline: none;
            border-color: var(--leaf-green);
            box-shadow: 0 2px 5px rgba(45, 106, 79, 0.2);
        }

        .eco-badge {
            background: rgba(45, 106, 79, 0.1);
            color: var(--leaf-green);
            border-radius: 9999px;
            font-size: 0.75rem;
            padding: 0.25rem 0.75rem;
            display: inline-flex;
            align-items: center;
            margin-bottom: 0.75rem;
        }

        .eco-badge i {
            font-size: 0.75rem;
            margin-right: 0.25rem;
        }
                header {
    display: flex;
    justify-content: space-between;
    align-items: center;
    padding: 20px 40px;
    background-color: #f8f9fa; /* Gris clair */
    color: #333;
    box-shadow: 0 4px 10px rgba(0, 0, 0, 0.1);
    border-bottom: 1px solid #ddd; /* Ligne fine pour séparer l'en-tête */
}

header .logo {
    
        font-size: 24px;
        font-weight: 700;
        color: #5f687b;
    
}

header nav {
    display: flex;
    align-items: center;
}

header nav a {
    color: #333;
    text-decoration: none;
    margin: 0 15px;
    font-size: 16px;
    font-weight: 500;
    transition: color 0.3s ease, transform 0.2s ease;
}

header nav a.active {
    border-bottom: 2px solid #28a745; /* Indicateur actif en vert */
}

header nav a:hover {
    color: #28a745; /* Vert au survol */
    transform: scale(1.1);
}
.profile-menu {
    position: relative;
    display: inline-block;
}

/* Style pour le menu déroulant */
.dropdown-menu {
    display: none;
    position: absolute;
    top: 20px;
    right: 0;
    background-color: #fff;
    border: 1px solid #ddd;
    border-radius: 5px;
    box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
    z-index: 1000;
    width: 180px;
}

.dropdown-menu a {
    display: block;
    padding: 10px;
    padding-right:80px;
    color: #333;
    text-decoration: none;
    font-size: 14px;
    transition: background-color 0.3s ease;
}

.dropdown-menu a:hover {
    background-color: #f4f4f9; /* Gris clair */
}

/* Afficher le menu déroulant au survol */
.profile-menu:hover .dropdown-menu {
    display: block;
}
    </style>
</head>
<body>
<header>
    <div class="logo">Khademni</div>
    <nav>
        <a href="../../../index.php" class="<?php echo basename($_SERVER['PHP_SELF']) == 'index.php' ? 'active' : ''; ?>">Home</a>
        <a href="../../../offer/mvc/views/listeView.php" class="<?php echo basename($_SERVER['PHP_SELF']) == 'list_jobs.php' ? 'active' : ''; ?>">Offres d'emploi</a>
        <a href="../../../quiz/views/frontoffice/quiz_list.php" class="<?php echo basename($_SERVER['PHP_SELF']) == 'blog.php' ? 'active' : ''; ?>">Test & Quiz</a>
        <a href="../../../valid/payment-processing-app/frontend/index.php" class="<?php echo basename($_SERVER['PHP_SELF']) == 'pricing.php' ? 'active' : ''; ?>">Paiment</a>
        
        <?php if ($isLoggedIn): ?>
            <div class="profile-menu">
                <img src="../../../user/controllers/<?php echo htmlspecialchars($user['pdp'] ?? ''); ?>" alt="Profile Picture" class="profile-pic" style="width: 100px; height: auto;">
                <div class="dropdown-menu">
                    <a href="../../../user/views/layouts/main/main.php">Voir Profil</a>
                    <a href="../../../user/controllers/logout.php">Se Déconnecter</a>
                </div>
            </div>
        <?php else: ?>
            <a href="../auth/login.php" class="button">Se connecter</a>
        <?php endif; ?>
    </nav>
</header>
    <div class="eco-bg"></div>
    <div id="fireflies" class="fixed inset-0 pointer-events-none"></div>
    <div id="ripples" class="fixed inset-0 pointer-events-none"></div>
    <div class="container mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <div class="referral-section text-forest-green rounded-lg mb-8">
            <div class="p-8 md:p-12">
                <div class="flex justify-between items-center mb-8">
                    <a href="quiz_list.php" class="back-arrow" aria-label="Back to quiz list">
                        <i class="fas fa-arrow-left w-5 h-5"></i>
                    </a>
                    <div class="text-center">
                        <h1 class="text-2xl sm:text-3xl font-bold font-montserrat text-forest-green">Invite Friends</h1>
                        <p class="text-gray-700 mt-2 max-w-lg mx-auto">Share your referral code or link to earn 50 eco-points per friend who joins!</p>
                    </div>
                    <div class="flex items-center space-x-4">
                        <span class="text-forest-green font-semibold"><?php echo htmlspecialchars($currentUser['username']); ?></span>
                        <a href="logout.php" class="animated-btn logout-btn" aria-label="Log out">
                            <i class="fas fa-sign-out-alt mr-2"></i>Log Out
                        </a>
                    </div>
                </div>
                <div class="max-w-md mx-auto">
                    <?php if ($referralCode): ?>
                        <div class="mb-4">
                            <label class="block text-sm font-medium text-gray-700 mb-1">Your Referral Code</label>
                            <input type="text" value="<?php echo htmlspecialchars($referralCode); ?>" class="referral-input" readonly onclick="this.select()">
                        </div>
                        <div class="mb-4">
                            <label class="block text-sm font-medium text-gray-700 mb-1">Your Referral Link</label>
                            <input type="text" value="<?php echo htmlspecialchars($referralLink); ?>" class="referral-input" readonly onclick="this.select()">
                        </div>
                        <div class="flex space-x-4 mb-6">
                            <button onclick="copyToClipboard('<?php echo htmlspecialchars($referralCode); ?>')" class="animated-btn referral-btn">
                                <i class="fas fa-copy mr-2"></i>Copy Code
                            </button>
                            <button onclick="copyToClipboard('<?php echo htmlspecialchars($referralLink); ?>')" class="animated-btn referral-btn">
                                <i class="fas fa-link mr-2"></i>Copy Link
                            </button>
                        </div>
                        <div class="eco-badge">
                            <i class="fas fa-users"></i> Referrals: <?php echo $referralStats['referral_count']; ?>
                        </div>
                        <div class="eco-badge">
                            <i class="fas fa-leaf"></i> Referral Points: <?php echo $referralStats['referral_points'] ?? 0; ?>
                        </div>
                    <?php else: ?>
                        <p class="text-red-500 text-center">Unable to generate referral code. Please try again later.</p>
                    <?php endif; ?>
                </div>
                <div class="flex justify-center space-x-4 mt-8">
                    <a href="quiz_list.php" class="animated-btn"><i class="fas fa-question-circle mr-3"></i>Back to Quizzes</a>
                    <a href="leaderboard.php" class="animated-btn"><i class="fas fa-trophy mr-3"></i>View Leaderboard</a>
                </div>
            </div>
        </div>
    </div>

    <script>
        // Firefly animation
        const firefliesContainer = document.getElementById('fireflies');
        for (let i = 0; i < 25; i++) {
            const firefly = document.createElement('div');
            firefly.className = 'firefly';
            firefly.style.left = `${Math.random() * 100}vw`;
            firefly.style.top = `${Math.random() * 100}vh`;
            firefly.style.animationDelay = `${Math.random() * 5}s`;
            firefly.style.animationDuration = `${6 + Math.random() * 4}s`;
            firefliesContainer.appendChild(firefly);
        }

        // Falling leaves
        for (let i = 0; i < 15; i++) {
            const leaf = document.createElement('div');
            leaf.className = 'leaf';
            leaf.style.left = `${Math.random() * 100}vw`;
            leaf.style.animationDelay = `${Math.random() * 10}s`;
            leaf.style.animationDuration = `${15 + Math.random() * 10}s`;
            firefliesContainer.appendChild(leaf);
        }

        // Water ripple effect
        const ripplesContainer = document.getElementById('ripples');
        for (let i = 0; i < 10; i++) {
            const ripple = document.createElement('div');
            ripple.className = 'ripple';
            ripple.style.left = `${Math.random() * 100}vw`;
            ripple.style.top = `${Math.random() * 100}vh`;
            ripple.style.animationDelay = `${Math.random() * 5}s`;
            ripple.style.animationDuration = `${3 + Math.random() * 2}s`;
            ripplesContainer.appendChild(ripple);
        }

        // Copy to clipboard
        function copyToClipboard(text) {
            navigator.clipboard.writeText(text).then(() => {
                alert('Copied to clipboard!');
            }).catch(err => {
                console.error('Failed to copy: ', err);
                alert('Failed to copy to clipboard.');
            });
        }
    </script>
</body>
</html>