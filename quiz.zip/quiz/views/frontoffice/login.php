<?php
require_once '../../controllers/UserController.php';
$userController = new UserController();

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $username = filter_input(INPUT_POST, 'username', FILTER_SANITIZE_STRING);
    $password = $_POST['password'] ?? '';
    $result = $userController->login($username, $password);
    if ($result['success']) {
        header('Location: quiz_list.php');
        exit;
    } else {
        $error = $result['message'];
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login - Trash2Treasure</title>
    <link href="https://cdn.jsdelivr.net/npm/tailwindcss@2.0.2/dist/tailwind.min.css" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700&family=Montserrat:wght@400;600;700&display=swap" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css" rel="stylesheet">
    <style>
        :root {
            --forest-green: #1b4332;
            --leaf-green: #2d6a4f;
            --mint-green: #74c69d;
            --light-mint: #b7e4c7;
            --cream: #f8f9fa;
            --soft-white: #ffffff;
        }

        body {
            font-family: 'Poppins', sans-serif;
            background: linear-gradient(135deg, var(--cream) 0%, var(--soft-white) 100%);
            color: #2d3748;
            min-height: 100vh;
        }

        .eco-bg {
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background: url("data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 1440 810'%3E%3Cpath d='M0 200C200 150 400 250 600 200C800 150 1000 300 1200 250C1400 200 1600 350 1800 300' fill='none' stroke='%2374c69d' stroke-width='3' opacity='0.15'/%3E%3Cpath d='M0 400C200 350 400 450 600 400C800 350 1000 500 1200 450C1400 400 1600 550 1800 500' fill='none' stroke='%232d6a4f' stroke-width='2' opacity='0.1'/%3E%3C/svg%3E");
            background-size: cover;
            z-index: -1;
        }

        .login-card {
            background: rgba(255, 255, 255, 0.9);
            backdrop-filter: blur(10px);
            border-radius: 1.5rem;
            border: 1px solid rgba(45, 106, 79, 0.15);
            box-shadow: 0 10px 30px rgba(45, 106, 79, 0.1);
        }

        .animated-btn {
            background: linear-gradient(45deg, var(--forest-green), var(--leaf-green));
            color: var(--soft-white);
            font-family: 'Montserrat', sans-serif;
            font-weight: 600;
            text-transform: uppercase;
            border-radius: 1.5rem;
            padding: 0.75rem 1.5rem;
            transition: all 0.4s ease;
        }

        .animated-btn:hover {
            transform: translateY(-5px);
            box-shadow: 0 8px 20px rgba(45, 106, 79, 0.4);
        }

        .error-message {
            background: rgba(255, 75, 75, 0.1);
            color: #c53030;
            border-radius: 0.5rem;
            padding: 0.75rem;
        }
    </style>
</head>
<body>
    <div class="eco-bg"></div>
    <div class="container mx-auto px-4 py-8">
        <div class="login-card max-w-md mx-auto p-6">
            <h1 class="text-2xl font-bold font-montserrat text-forest-green text-center mb-6">Login to khadamni</h1>
            <?php if (isset($error)): ?>
                <div class="error-message mb-4"><?php echo htmlspecialchars($error); ?></div>
            <?php endif; ?>
            <form method="POST" action="login.php">
                <div class="mb-4">
                    <label for="username" class="block text-sm font-medium text-gray-700">Username</label>
                    <input type="text" id="username" name="username" class="mt-1 block w-full border-gray-300 rounded-md shadow-sm focus:ring-leaf-green focus:border-leaf-green" required>
                </div>
                <div class="mb-6">
                    <label for="password" class="block text-sm font-medium text-gray-700">Password</label>
                    <input type="password" id="password" name="password" class="mt-1 block w-full border-gray-300 rounded-md shadow-sm focus:ring-leaf-green focus:border-leaf-green" required>
                </div>
                <button type="submit" class="animated-btn w-full">Log In</button>
            </form>
            <p class="mt-4 text-center text-gray-600">Don't have an account? <a href="register.php" class="text-leaf-green hover:underline">Register</a></p>
        </div>
    </div>
</body>
</html>