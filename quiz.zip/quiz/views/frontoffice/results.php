<?php
// Start session safely
if (session_status() !== PHP_SESSION_ACTIVE) {
    session_start();
}

// Include necessary controller files
require_once '../../controllers/QuizController.php';
require_once '../../controllers/QuestionController.php';
require_once '../../controllers/LeaderboardController.php';
require_once '../../controllers/UserController.php';

// Initialize controllers
$quizController = new QuizController();
$questionController = new QuestionController();
$leaderboardController = new LeaderboardController();
$userController = new UserController();

// Check if user is logged in
$currentUser = $userController->getCurrentUser();
if (!$currentUser) {
    header('Location: login.php');
    exit;
}

// Get quiz ID from URL
$quizId = filter_input(INPUT_GET, 'id', FILTER_SANITIZE_NUMBER_INT);

if (!$quizId) {
    header('Location: error.php?message=Quiz ID not provided');
    exit;
}

// Fetch quiz details
$quiz = $quizController->showQuiz($quizId);
if (!$quiz) {
    header('Location: error.php?message=Quiz not found');
    exit;
}

// Fetch questions associated with the quiz
$questions = $questionController->listQuestionsByQuiz($quizId);
if (empty($questions)) {
    header('Location: error.php?message=No questions found');
    exit;
}

// Process submitted answers
$userAnswers = $_POST['answers'] ?? [];
$timeTaken = (int)($_POST['timeTaken'] ?? 600);
$score = 0;
$totalQuestions = count($questions);
$results = [];

foreach ($questions as $question) {
    $questionId = $question['id'];
    $correctAnswer = $question['correct_option'];
    $userAnswer = $userAnswers[$questionId] ?? null;

    $isCorrect = $userAnswer === $correctAnswer;
    if ($isCorrect) {
        $score++;
    }

    $results[] = [
        'question_text' => $question['question_text'],
        'user_answer' => $userAnswer ? $question['option_' . $userAnswer] : 'Not answered',
        'correct_answer' => $question['option_' . $correctAnswer],
        'is_correct' => $isCorrect
    ];
}

$percentage = ($totalQuestions > 0) ? ($score / $totalQuestions) * 100 : 0;

$badgeLevel = '';
$badgeIcon = '';
$badgeMessage = '';

if ($percentage >= 90) {
    $badgeLevel = 'Sustainability Champion';
    $badgeIcon = 'fas fa-award';
    $badgeMessage = 'Outstanding! Your knowledge of sustainable practices is exceptional!';
} elseif ($percentage >= 75) {
    $badgeLevel = 'Eco Warrior';
    $badgeIcon = 'fas fa-tree';
    $badgeMessage = 'Great job! You\'re well on your way to becoming a sustainability expert!';
} elseif ($percentage >= 50) {
    $badgeLevel = 'Green Explorer';
    $badgeIcon = 'fas fa-compass';
    $badgeMessage = 'Good effort! You\'re making progress on your sustainability journey!';
} else {
    $badgeLevel = 'Eco Seedling';
    $badgeIcon = 'fas fa-seedling';
    $badgeMessage = 'Keep learning! Every step toward sustainability counts!';
}

$ecoPoints = ceil($percentage / 10) * 5;
if (isset($_POST['timedMode']) && $_POST['timedMode'] === 'on') {
    $bonusPoints = floor((600 - $timeTaken) / 6);
    $ecoPoints += max(0, $bonusPoints);
}
$ecoPoints = max(0, $ecoPoints);

// Save score to leaderboard
$scoreObj = new Score(null, $currentUser['id'], $quizId, $score, $ecoPoints, null);
$leaderboardController->saveScore($scoreObj);
?>

<!DOCTYPE html>
<html lang="en" data-theme="forest">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Quiz Results - Trash2Treasure</title>
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700&family=Montserrat:wght@400;600;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="styles.css">
</head>
<body>
    <div class="eco-bg"></div>
    <div id="wildlife-container"></div>
    <div id="env-container"></div>
    <div id="fireflies"></div>
    <div id="ripples"></div>
    <div class="parallax-container">
        <div class="parallax-layer layer-1"></div>
        <div class="parallax-layer layer-2"></div>
    </div>

    <main class="max-w-4xl mx-auto px-4 py-8">
        <section class="hero-section p-6 mb-8">
            <a href="dashboard.php" class="back-arrow mb-4 inline-block">
                <i class="fas fa-arrow-left"></i>
            </a>
            <h1 class="text-2xl font-bold text-primary mb-4">Quiz Results: <?php echo htmlspecialchars($quiz['title']); ?></h1>

            <div class="score-circle-container">
                <div class="score-circle" style="background: conic-gradient(var(--accent) <?php echo $percentage; ?>%, var(--card-bg) <?php echo $percentage; ?>%)">
                    <div class="score-text"><?php echo round($percentage); ?>%</div>
                </div>
            </div>

            <div class="badge-container">
                <div class="feature-icon"><i class="<?php echo $badgeIcon; ?>"></i></div>
                <h2 class="badge-level"><?php echo $badgeLevel; ?></h2>
                <p class="badge-message"><?php echo $badgeMessage; ?></p>
            </div>

            <div class="eco-points text-center mt-4">
                <p>Eco-Points Earned: <span class="stats-value"><?php echo $ecoPoints; ?></span></p>
            </div>

            <div class="badge-summary mt-4">
                <h3 class="text-lg font-semibold text-primary">Your Achievements</h3>
                <div class="flex gap-4 mt-2">
                    <div class="badge-notification">
                        <div class="feature-icon"><i class="fas fa-star"></i></div>
                        <div class="badge-notification-title">First Step</div>
                    </div>
                    <?php if ($percentage >= 50): ?>
                        <div class="badge-notification">
                            <div class="feature-icon"><i class="fas fa-trophy"></i></div>
                            <div class="badge-notification-title">Halfway Hero</div>
                        </div>
                    <?php endif; ?>
                </div>
            </div>

            <div class="encouragement mt-4 text-center">
                <p class="text-secondary glow-text">
                    <?php
                    if ($percentage >= 90) {
                        echo "You're a sustainability superstar! Keep shining!";
                    } elseif ($percentage >= 75) {
                        echo "Fantastic effort! You're making a real difference!";
                    } else {
                        echo "Every step counts! Try again to boost your score!";
                    }
                    ?>
                </p>
            </div>

            <div class="answer-review">
                <h2 class="text-xl font-semibold text-primary mb-4">Answer Review</h2>
                <?php foreach ($results as $index => $result): ?>
                    <div class="answer-item feature-card <?php echo $result['is_correct'] ? 'correct' : 'incorrect'; ?>">
                        <p class="font-semibold"><?php echo ($index + 1) . '. ' . htmlspecialchars($result['question_text']); ?></p>
                        <ul class="leaf-bullet mt-2">
                            <li>Your Answer: <?php echo htmlspecialchars($result['user_answer']); ?></li>
                            <li>Correct Answer: <?php echo htmlspecialchars($result['correct_answer']); ?></li>
                        </ul>
                    </div>
                <?php endforeach; ?>
            </div>

            <div class="social-share flex justify-center gap-4 mt-6">
                <a href="#" class="social-icon"><i class="fab fa-twitter"></i></a>
                <a href="#" class="social-icon"><i class="fab fa-facebook"></i></a>
                <a href="#" class="social-icon"><i class="fab fa-linkedin"></i></a>
            </div>

            <div class="flex justify-center gap-4 mt-6">
                <a href="quiz.php?id=<?php echo $quizId; ?>" class="animated-btn">Retake Quiz</a>
                <a href="dashboard.php" class="animated-btn leaderboard-btn">View Leaderboard</a>
            </div>
        </section>
    </main>

    <script src="scripts.js"></script>
</body>
</html>