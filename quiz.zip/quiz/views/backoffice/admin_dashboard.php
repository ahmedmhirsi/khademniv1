<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>Admin Dashboard</title>
  <script src="https://cdn.tailwindcss.com"></script>
</head>
<body class="bg-gray-100 p-8 font-sans">
  <div class="max-w-5xl mx-auto">
    <h1 class="text-3xl font-bold mb-6 text-green-700">Admin Dashboard 🛠️</h1>
    
    <a href="add_quiz.php" class="mb-4 inline-block bg-blue-500 text-white px-4 py-2 rounded hover:bg-blue-700">➕ Add Quiz</a>

    <div class="bg-white p-6 rounded shadow">
      <?php foreach ($quizzes as $quiz): ?>
        <div class="mb-4 border-b pb-4">
          <h2 class="text-xl font-bold text-green-600"><?= htmlspecialchars($quiz['title']) ?></h2>
          <p class="mb-2"><?= htmlspecialchars($quiz['description']) ?></p>
          <a href="add_question.php?quiz_id=<?= $quiz['id'] ?>" class="text-blue-600 hover:underline">Add Question</a> |
          <a href="delete_quiz.php?id=<?= $quiz['id'] ?>" class="text-red-600 hover:underline" onclick="return confirm('Delete this quiz?')">Delete</a>
        </div>
      <?php endforeach; ?>
    </div>
  </div>
</body>
</html>
