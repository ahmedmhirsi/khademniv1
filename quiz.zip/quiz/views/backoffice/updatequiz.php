<?php
// Load required controllers with error handling
try {
    require_once '../../controllers/QuizController.php';
    require_once '../../controllers/QuestionController.php';
} catch (Exception $e) {
    die('Error loading controllers: ' . $e->getMessage());
}

// Initialize variables to avoid undefined warnings
$error = "";
$success = "";
$quiz = null;
$questions = [];

$quizController = new QuizController();
$questionController = new QuestionController();

// Sanitize and validate input data
function sanitizeInput($data) {
    return htmlspecialchars(strip_tags(trim($data)));
}

// Process form submission
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (!isset($_POST['idquiz'], $_POST['titre'])) {
        $error = "Missing required quiz information.";
    } else {
        $idquiz = sanitizeInput($_POST['idquiz']);
        $titre = sanitizeInput($_POST['titre']);
        $description = sanitizeInput($_POST['description'] ?? '');

        if (empty($idquiz) || empty($titre)) {
            $error = "Quiz ID and title are required.";
        } else {
            try {
                $errors = [];

                // Validate existing questions
                if (isset($_POST['questions']) && is_array($_POST['questions'])) {
                    foreach ($_POST['questions'] as $questionId => $questionData) {
                        $options = [
                            trim($questionData['option_a'] ?? ''),
                            trim($questionData['option_b'] ?? ''),
                            trim($questionData['option_c'] ?? ''),
                            trim($questionData['option_d'] ?? '')
                        ];
                        $options = array_filter($options); // Remove empty options

                        // Check for at least two options
                        if (count($options) < 2) {
                            $errors[] = "Question ID $questionId must have at least two options.";
                        }

                        // Check for unique options
                        if (count(array_unique($options)) !== count($options)) {
                            $errors[] = "Options for question ID $questionId must be unique.";
                        }

                        // Check if correct option is within range
                        $correctOption = (int)($questionData['correct_option'] ?? 0);
                        if ($correctOption < 1 || $correctOption > count($options)) {
                            $errors[] = "Correct option for question ID $questionId must be between 1 and " . count($options) . ".";
                        }
                    }
                }

                // Validate new questions
                if (isset($_POST['new_questions']) && is_array($_POST['new_questions'])) {
                    foreach ($_POST['new_questions'] as $index => $newQuestionData) {
                        $options = [
                            trim($newQuestionData['option_a'] ?? ''),
                            trim($newQuestionData['option_b'] ?? ''),
                            trim($newQuestionData['option_c'] ?? ''),
                            trim($newQuestionData['option_d'] ?? '')
                        ];
                        $options = array_filter($options); // Remove empty options

                        // Check for at least two options
                        if (count($options) < 2) {
                            $errors[] = "New question " . ($index + 1) . " must have at least two options.";
                        }

                        // Check for unique options
                        if (count(array_unique($options)) !== count($options)) {
                            $errors[] = "Options for new question " . ($index + 1) . " must be unique.";
                        }

                        // Check if correct option is within range
                        $correctOption = (int)($newQuestionData['correct_option'] ?? 0);
                        if ($correctOption < 1 || $correctOption > count($options)) {
                            $errors[] = "Correct option for new question " . ($index + 1) . " must be between 1 and " . count($options) . ".";
                        }
                    }
                }

                // Throw exception if there are validation errors
                if (!empty($errors)) {
                    throw new Exception(implode("<br>", $errors));
                }

                // Update quiz
                $quiz = new Quiz($idquiz, $titre, $description);
                $quizController->updateQuiz($quiz, $idquiz);

                // Handle deleted questions
                if (isset($_POST['deleted_questions']) && is_array($_POST['deleted_questions'])) {
                    foreach (array_filter($_POST['deleted_questions']) as $deletedId) {
                        if (!empty($deletedId)) {
                            $questionController->deleteQuestion(sanitizeInput($deletedId));
                        }
                    }
                }

                // Update existing questions
                if (isset($_POST['questions']) && is_array($_POST['questions'])) {
                    foreach ($_POST['questions'] as $questionId => $questionData) {
                        if (!empty($questionData['question']) && !empty($questionData['option_a']) && !empty($questionData['option_b'])) {
                            // Map integer correct option to letter
                            $correctOptionIndex = (int)$questionData['correct_option'] - 1;
                            $correctLetter = ['a', 'b', 'c', 'd'][$correctOptionIndex] ?? 'a';
                            $question = new Question(
                                $questionId,
                                $idquiz,
                                sanitizeInput($questionData['question']),
                                sanitizeInput($questionData['option_a']),
                                sanitizeInput($questionData['option_b']),
                                sanitizeInput($questionData['option_c'] ?? ''),
                                sanitizeInput($questionData['option_d'] ?? ''),
                                $correctLetter
                            );
                            $questionController->updateQuestion($question, $questionId);
                        }
                    }
                }

                // Add new questions
                if (isset($_POST['new_questions']) && is_array($_POST['new_questions'])) {
                    foreach ($_POST['new_questions'] as $newQuestionData) {
                        if (!empty($newQuestionData['question']) && !empty($newQuestionData['option_a']) && !empty($newQuestionData['option_b'])) {
                            // Map integer correct option to letter
                            $correctOptionIndex = (int)$newQuestionData['correct_option'] - 1;
                            $correctLetter = ['a', 'b', 'c', 'd'][$correctOptionIndex] ?? 'a';
                            $newQuestion = new Question(
                                null,
                                $idquiz,
                                sanitizeInput($newQuestionData['question']),
                                sanitizeInput($newQuestionData['option_a']),
                                sanitizeInput($newQuestionData['option_b']),
                                sanitizeInput($newQuestionData['option_c'] ?? ''),
                                sanitizeInput($newQuestionData['option_d'] ?? ''),
                                $correctLetter
                            );
                            $questionController->createQuestion($newQuestion);
                        }
                    }
                }

                $success = "Quiz updated successfully!";
                header('Location: quizList.php?success=true');
                exit;

            } catch (Exception $e) {
                $error = "An error occurred: " . $e->getMessage();
            }
        }
    }
}

// Retrieve quiz and questions
if (isset($_GET['id'])) {
    $id = sanitizeInput($_GET['id']);
    $quiz = $quizController->showQuiz($id);
    if (!$quiz) {
        die("<p class='text-danger'>Quiz not found.</p>");
    }
    $questions = $questionController->listQuestionsByQuiz($id);
}
?>

<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Edit Quiz | Trash2Treasure</title>
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@400;500;600;700&display=swap" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>
        :root {
            --primary: #4e9f3d;
            --primary-dark: #3a7f2d;
            --secondary: #2c3e50;
            --accent: #1e8449;
            --light: #f8f9fa;
            --dark: #343a40;
            --danger: #e74c3c;
            --warning: #f39c12;
            --success: #2ecc71;
            --border-radius: 0.75rem;
            --shadow: 0 6px 20px rgba(0, 0, 0, 0.1);
            --shadow-light: 0 2px 10px rgba(0, 0, 0, 0.05);
        }

        body {
            font-family: 'Poppins', sans-serif;
            background: linear-gradient(135deg, #e6f0ea, #f5f7fa);
            color: var(--dark);
            margin: 0;
            padding: 0;
            min-height: 100vh;
            display: flex;
            flex-direction: column;
        }

        .t2t-header {
            background: linear-gradient(135deg, var(--primary) 0%, var(--accent) 100%);
            color: white;
            padding: 1.5rem 0;
            box-shadow: var(--shadow);
            position: sticky;
            top: 0;
            z-index: 1000;
        }

        .t2t-header .container {
            display: flex;
            justify-content: space-between;
            align-items: center;
        }

        .t2t-header .logo h1 {
            font-size: 1.8rem;
            font-weight: 700;
            margin: 0;
            letter-spacing: 0.5px;
        }

        .t2t-header nav ul {
            list-style: none;
            display: flex;
            margin: 0;
            padding: 0;
            gap: 1.5rem;
        }

        .t2t-header nav ul li a {
            color: white;
            text-decoration: none;
            font-weight: 500;
            font-size: 1rem;
            transition: color 0.3s ease, transform 0.3s ease;
        }

        .t2t-header nav ul li a:hover {
            color: var(--light);
            transform: translateY(-2px);
        }

        .t2t-header .nav-active {
            border-bottom: 2px solid var(--light);
        }

        .mobile-menu {
            background: var(--secondary);
            padding: 1.5rem;
            box-shadow: var(--shadow);
        }

        .mobile-menu ul {
            list-style: none;
            padding: 0;
            margin: 0;
        }

        .mobile-menu ul li {
            margin-bottom: 1rem;
        }

        .mobile-menu ul li a {
            color: white;
            text-decoration: none;
            font-weight: 500;
            font-size: 1rem;
            display: block;
            transition: color 0.3s ease;
        }

        .mobile-menu ul li a:hover {
            color: var(--light);
        }

        .page-container {
            flex: 1;
            padding: 3rem 1rem;
            max-width: 1400px;
            margin: 0 auto;
            width: 100%;
        }

        .card {
            background: white;
            border-radius: var(--border-radius);
            box-shadow: var(--shadow);
            overflow: hidden;
            transition: transform 0.3s ease, box-shadow 0.3s ease;
            position: relative;
        }

        .card:hover {
            transform: translateY(-5px);
            box-shadow: 0 8px 25px rgba(0, 0, 0, 0.15);
        }

        .card-header {
            background: linear-gradient(45deg, var(--primary), var(--accent));
            color: white;
            padding: 1.75rem;
            font-weight: 600;
            font-size: 1.5rem;
            display: flex;
            align-items: center;
            gap: 0.75rem;
            border-bottom: none;
        }

        .card-body {
            padding: 2.5rem;
        }

        .form-control {
            border-radius: var(--border-radius);
            border: 1px solid #d4d9de;
            padding: 0.85rem 1.25rem;
            font-size: 1rem;
            background: #f9fafb;
            transition: border-color 0.3s ease, box-shadow 0.3s ease, background 0.3s ease;
        }

        .form-control:focus {
            border-color: var(--primary);
            box-shadow: 0 0 0 0.25rem rgba(78, 159, 61, 0.2);
            background: white;
        }

        .btn-primary {
            background: linear-gradient(135deg, var(--primary), var(--accent));
            border: none;
            border-radius: var(--border-radius);
            padding: 0.85rem 2rem;
            font-weight: 600;
            font-size: 1.1rem;
            color: white;
            transition: background 0.3s ease, transform 0.3s ease, box-shadow 0.3s ease;
            box-shadow: 0 4px 15px rgba(78, 159, 61, 0.3);
            display: inline-flex;
            align-items: center;
            gap: 0.5rem;
        }

        .btn-primary:hover, .btn-primary:focus {
            background: linear-gradient(135deg, var(--accent), var(--primary-dark));
            transform: translateY(-3px);
            box-shadow: 0 6px 20px rgba(78, 159, 61, 0.4);
        }

        .btn-secondary {
            background: var(--secondary);
            border: none;
            border-radius: var(--border-radius);
            padding: 0.85rem 2rem;
            font-weight: 600;
            font-size: 1.1rem;
            color: white;
            transition: background 0.3s ease, transform 0.3s ease, box-shadow 0.3s ease;
            display: inline-flex;
            align-items: center;
            gap: 0.5rem;
            box-shadow: 0 4px 15px rgba(46, 62, 80, 0.2);
        }

        .btn-secondary:hover {
            background: #1a252f;
            transform: translateY(-3px);
            box-shadow: 0 6px 20px rgba(46, 62, 80, 0.3);
        }

        .section-title {
            color: var(--secondary);
            font-weight: 700;
            font-size: 1.5rem;
            margin-bottom: 2rem;
            position: relative;
            padding-left: 1.75rem;
            display: flex;
            align-items: center;
            gap: 0.75rem;
        }

        .section-title::before {
            content: '';
            position: absolute;
            left: 0;
            top: 50%;
            transform: translateY(-50%);
            height: 2rem;
            width: 5px;
            background: var(--primary);
            border-radius: 3px;
        }

        .question-container {
            background: white;
            border-radius: var(--border-radius);
            box-shadow: var(--shadow-light);
            margin-bottom: 2rem;
            overflow: hidden;
            transition: transform 0.3s ease, box-shadow 0.3s ease;
            position: relative;
        }

        .question-container:hover {
            transform: translateY(-5px);
            box-shadow: 0 6px 20px rgba(0, 0, 0, 0.1);
        }

        .question-container::before {
            content: '';
            position: absolute;
            top: 0;
            left: 0;
            width: 100%;
            height: 4px;
            background: linear-gradient(90deg, var(--primary), var(--accent));
            opacity: 0.3;
        }

        .question-header {
            background: var(--light);
            padding: 1.25rem 1.75rem;
            border-bottom: 1px solid #e1e5e9;
            display: flex;
            align-items: center;
            gap: 1rem;
        }

        .question-number {
            background: var(--primary);
            color: white;
            width: 3rem;
            height: 3rem;
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            font-weight: 700;
            font-size: 1.3rem;
            box-shadow: 0 3px 8px rgba(0, 0, 0, 0.1);
        }

        .question-body {
            padding: 2rem;
        }

        .option-row {
            display: flex;
            align-items: center;
            margin-bottom: 1.25rem;
            gap: 1.25rem;
        }

        .option-badge {
            width: 2.5rem;
            height: 2.5rem;
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            font-weight: 700;
            font-size: 1.1rem;
            flex-shrink: 0;
            box-shadow: 0 2px 6px rgba(0, 0, 0, 0.1);
            transition: transform 0.3s ease;
        }

        .option-badge:hover {
            transform: scale(1.1);
        }

        .option-badge-1 { background: #3498db; color: white; }
        .option-badge-2 { background: #2ecc71; color: white; }
        .option-badge-3 { background: #f39c12; color: white; }
        .option-badge-4 { background: #9b59b6; color: white; }

        .option-input {
            flex: 1;
        }

        .option-input .form-control {
            background: #f9fafb;
        }

        .remove-button {
            background: var(--danger);
            color: white;
            border: none;
            border-radius: var(--border-radius);
            padding: 0.75rem 1.5rem;
            font-weight: 600;
            font-size: 1rem;
            display: flex;
            align-items: center;
            gap: 0.5rem;
            width: 100%;
            justify-content: center;
            transition: background 0.3s ease, transform 0.3s ease, box-shadow 0.3s ease;
            box-shadow: 0 4px 12px rgba(231, 76, 60, 0.2);
        }

        .remove-button:hover {
            background: #c0392b;
            transform: translateY(-3px);
            box-shadow: 0 6px 18px rgba(231, 76, 60, 0.3);
        }

        .form-group {
            margin-bottom: 1.5rem;
        }

        .form-group label {
            font-weight: 600;
            color: var(--secondary);
            margin-bottom: 0.75rem;
            display: flex;
            align-items: center;
            gap: 0.5rem;
            font-size: 1.1rem;
        }

        .alert {
            border-radius: var(--border-radius);
            padding: 1.25rem 1.75rem;
            margin-bottom: 2rem;
            border-left: 5px solid;
            box-shadow: var(--shadow-light);
            display: flex;
            align-items: center;
            gap: 1rem;
            font-size: 1rem;
        }

        .alert-success {
            background: #e8f5e9;
            color: #1b5e20;
            border-left-color: var(--success);
        }

        .alert-danger {
            background: #ffebee;
            color: #b71c1c;
            border-left-color: var(--danger);
        }

        .form-actions {
            display: flex;
            justify-content: flex-start;
            gap: 1rem;
            margin-top: 2.5rem;
            flex-wrap: wrap;
        }

        .counter-input {
            max-width: 250px;
            background: #f9fafb;
        }

        .correct-answer-select {
            background: #f9fafb;
            border: 1px solid #d4d9de;
            border-radius: var(--border-radius);
            padding: 0.85rem 1.25rem;
            font-size: 1rem;
            transition: border-color 0.3s ease, box-shadow 0.3s ease;
            width: 100%;
        }

        .correct-answer-select:focus {
            border-color: var(--primary);
            box-shadow: 0 0 0 0.25rem rgba(78, 159, 61, 0.2);
        }

        .correct-answer-select option:disabled {
            color: #b0b0b0;
        }

        @media (max-width: 768px) {
            .t2t-header .logo h1 { font-size: 1.4rem; }
            .t2t-header nav ul { gap: 1rem; }
            .t2t-header nav ul li a { font-size: 0.9rem; }
            .page-container { padding: 1.5rem 0.5rem; }
            .card-header { padding: 1.25rem; font-size: 1.2rem; }
            .card-body { padding: 1.5rem; }
            .form-control, .correct-answer-select { font-size: 0.95rem; padding: 0.75rem 1rem; }
            .btn-primary, .btn-secondary, .remove-button { font-size: 0.95rem; padding: 0.75rem 1.5rem; }
            .section-title { font-size: 1.2rem; padding-left: 1.25rem; }
            .question-header { padding: 1rem 1.25rem; }
            .question-number { width: 2.5rem; height: 2.5rem; font-size: 1rem; }
            .option-badge { width: 2rem; height: 2rem; font-size: 0.9rem; }
            .form-actions { flex-direction: column; }
            .form-actions .btn { width: 100%; margin-bottom: 0.75rem; }
            .option-row { flex-direction: column; align-items: flex-start; gap: 0.75rem; }
            .option-badge { margin-bottom: 0.5rem; }
            .alert { font-size: 0.9rem; padding: 1rem 1.25rem; }
        }

        .is-invalid {
            border-color: var(--danger) !important;
            background: #fff5f5 !important;
        }
    </style>
</head>
<body>
    <!-- T2T Header -->
    <header class="t2t-header">
        <div class="container">
            <div>
                <div class="logo">
                    <h1>Trash2Treasure</h1>
                </div>
           
                <button class="d-md-none btn btn-outline-light" id="mobileMenuToggle">
                    <i class="fas fa-bars"></i>
                </button>
            </div>
        </div>
    </header>

    <!-- Mobile Menu -->
    <div class="mobile-menu d-md-none" id="mobileMenu" style="display: none;">
        <div class="container">
            <ul>
                <li><a href="index.php">Home</a></li>
                <li><a href="courses.php">Courses</a></li>
                <li><a href="quizList.php" class="nav-active">Quizzes</a></li>
                <li><a href="profile.php">Profile</a></li>
            </ul>
        </div>
    </div>

    <div class="page-container">
        <div class="container">
            <div class="card">
                <div class="card-header">
                    <i class="fas fa-edit"></i> Edit Quiz
                </div>
                <div class="card-body">
                    <?php if ($error): ?>
                        <div class="alert alert-danger">
                            <i class="fas fa-exclamation-circle"></i> <?php echo $error; ?>
                        </div>
                    <?php endif; ?>

                    <?php if ($success): ?>
                        <div class="alert alert-success">
                            <i class="fas fa-check-circle"></i> <?php echo $success; ?>
                        </div>
                    <?php endif; ?>

                    <?php if ($quiz): ?>
                        <form method="POST" action="" id="quizForm">
                            <input type="hidden" name="idquiz" value="<?php echo htmlspecialchars($quiz['id']); ?>">

                            <div class="card mb-5">
                                <div class="card-body">
                                    <h3 class="section-title"><i class="fas fa-info-circle"></i> Quiz Information</h3>
                                    <div class="form-group">
                                        <label><i class="fas fa-heading"></i> Title *</label>
                                        <input type="text" name="titre" id="titre" class="form-control" value="<?php echo htmlspecialchars($quiz['title']); ?>" placeholder="Enter quiz title" required>
                                    </div>
                                    <div class="form-group">
                                        <label><i class="fas fa-align-left"></i> Description</label>
                                        <input type="text" name="description" id="description" class="form-control" value="<?php echo htmlspecialchars($quiz['description']); ?>" placeholder="Enter quiz description">
                                    </div>
                                </div>
                            </div>

                            <h3 class="section-title"><i class="fas fa-list-ol"></i> Existing Questions</h3>
                            <div id="questions-container" class="row row-cols-1 g-4">
                                <?php $questionCount = 0; ?>
                                <?php foreach ($questions as $question): ?>
                                    <?php
                                        $questionCount++;
                                        $correctOptionMap = ['a' => 1, 'b' => 2, 'c' => 3, 'd' => 4];
                                        $correctOption = $correctOptionMap[strtolower($question['correct_option'])] ?? 1;
                                    ?>
                                    <div class="col">
                                        <div class="question-container" data-question-id="<?php echo $question['id']; ?>">
                                            <div class="question-header">
                                                <div class="question-number"><?php echo $questionCount; ?></div>
                                                <h4 class="mb-0">Question</h4>
                                            </div>
                                            <div class="question-body">
                                                <input type="hidden" name="questions[<?php echo $question['id']; ?>][id]" value="<?php echo $question['id']; ?>">
                                                <div class="form-group">
                                                    <label><i class="fas fa-question-circle"></i> Question Text *</label>
                                                    <input type="text" name="questions[<?php echo $question['id']; ?>][question]" class="form-control" value="<?php echo htmlspecialchars($question['question_text']); ?>" placeholder="Enter your question" required>
                                                </div>
                                                <div class="form-group">
                                                    <label><i class="fas fa-list"></i> Answer Options</label>
                                                    <div class="option-row">
                                                        <span class="option-badge option-badge-1">A</span>
                                                        <div class="option-input">
                                                            <input type="text" name="questions[<?php echo $question['id']; ?>][option_a]" class="form-control" value="<?php echo htmlspecialchars($question['option_a']); ?>" placeholder="Option 1" required>
                                                        </div>
                                                    </div>
                                                    <div class="option-row">
                                                        <span class="option-badge option-badge-2">B</span>
                                                        <div class="option-input">
                                                            <input type="text" name="questions[<?php echo $question['id']; ?>][option_b]" class="form-control" value="<?php echo htmlspecialchars($question['option_b']); ?>" placeholder="Option 2" required>
                                                        </div>
                                                    </div>
                                                    <div class="option-row">
                                                        <span class="option-badge option-badge-3">C</span>
                                                        <div class="option-input">
                                                            <input type="text" name="questions[<?php echo $question['id']; ?>][option_c]" class="form-control" value="<?php echo htmlspecialchars($question['option_c'] ?? ''); ?>" placeholder="Option 3 (optional)">
                                                        </div>
                                                    </div>
                                                    <div class="option-row">
                                                        <span class="option-badge option-badge-4">D</span>
                                                        <div class="option-input">
                                                            <input type="text" name="questions[<?php echo $question['id']; ?>][option_d]" class="form-control" value="<?php echo htmlspecialchars($question['option_d'] ?? ''); ?>" placeholder="Option 4 (optional)">
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class="form-group">
                                                    <label><i class="fas fa-check-circle"></i> Correct Answer *</label>
                                                    <select name="questions[<?php echo $question['id']; ?>][correct_option]" class="correct-answer-select" required>
                                                        <option value="1" <?php echo $correctOption == 1 ? 'selected' : ''; ?>>Option A</option>
                                                        <option value="2" <?php echo $correctOption == 2 ? 'selected' : ''; ?>>Option B</option>
                                                        <option value="3" <?php echo $correctOption == 3 && !empty($question['option_c']) ? 'selected' : ''; ?> <?php echo empty($question['option_c']) ? 'disabled' : ''; ?>>Option C</option>
                                                        <option value="4" <?php echo $correctOption == 4 && !empty($question['option_d']) ? 'selected' : ''; ?> <?php echo empty($question['option_d']) ? 'disabled' : ''; ?>>Option D</option>
                                                    </select>
                                                </div>
                                                <button type="button" class="remove-button" onclick="removeQuestion(this, '<?php echo $question['id']; ?>')">
                                                    <i class="fas fa-trash-alt"></i> Remove Question
                                                </button>
                                            </div>
                                        </div>
                                    </div>
                                <?php endforeach; ?>
                            </div>

                            <h3 class="section-title"><i class="fas fa-plus-circle"></i> Add New Questions</h3>
                            <div class="card mb-5">
                                <div class="card-body">
                                    <div class="form-group">
                                        <label><i class="fas fa-calculator"></i> Number of New Questions to Add</label>
                                        <input type="number" id="nb_questions" class="form-control counter-input" min="1" max="20" value="1">
                                    </div>
                                </div>
                            </div>

                            <div id="new-questions-container" class="row row-cols-1 g-4"></div>

                            <div id="deleted-questions-inputs" style="display: none;"></div>

                            <div class="form-actions">
                                <button type="submit" class="btn btn-primary">
                                    <i class="fas fa-save"></i> Update Quiz
                                </button>
                                <a href="quizList.php" class="btn btn-secondary">
                                    <i class="fas fa-times-circle"></i> Cancel
                                </a>
                            </div>
                        </form>
                    <?php else: ?>
                        <div class="alert alert-danger">
                            <i class="fas fa-exclamation-circle"></i> No quiz found or invalid quiz ID.
                        </div>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
<script>
    // Mobile menu toggle
    document.getElementById('mobileMenuToggle')?.addEventListener('click', function() {
        const mobileMenu = document.getElementById('mobileMenu');
        mobileMenu.style.display = mobileMenu.style.display === 'block' ? 'none' : 'block';
    });

    function removeQuestion(button, questionId) {
        const container = button.closest('.question-container');
        container.style.opacity = '0';
        container.style.transform = 'translateY(20px)';
        setTimeout(() => {
            container.remove();
            updateQuestionNumbers();
            if (questionId) {
                const deletedInputs = document.getElementById('deleted-questions-inputs');
                const input = document.createElement('input');
                input.type = 'hidden';
                input.name = 'deleted_questions[]';
                input.value = questionId;
                deletedInputs.appendChild(input);
            }
        }, 300);
    }

    function updateQuestionNumbers() {
        const questionContainers = document.querySelectorAll('.question-container');
        questionContainers.forEach((container, index) => {
            const numberBadge = container.querySelector('.question-number');
            if (numberBadge) {
                numberBadge.textContent = index + 1;
            }
        });
    }

    function updateCorrectOptionDropdown(questionContainer) {
        const optionInputs = [
            questionContainer.querySelector('input[name$="[option_a]"]'),
            questionContainer.querySelector('input[name$="[option_b]"]'),
            questionContainer.querySelector('input[name$="[option_c]"]'),
            questionContainer.querySelector('input[name$="[option_d]"]')
        ];
        
        const correctSelect = questionContainer.querySelector('select[name$="[correct_option]"]');
        
        if (!correctSelect) return;
        
        const options = correctSelect.querySelectorAll('option');
        options.forEach((option, index) => {
            if (index < optionInputs.length && index > 1) {
                option.disabled = !optionInputs[index]?.value.trim();
            }
        });
    }

    document.getElementById('nb_questions').addEventListener('input', function() {
        const nb = parseInt(this.value);
        const container = document.getElementById('new-questions-container');
        container.innerHTML = '';

        if (isNaN(nb) || nb <= 0) return;

        const existingQuestions = document.querySelectorAll('#questions-container .question-container').length;

        for (let i = 0; i < nb; i++) {
            const questionNumber = existingQuestions + i + 1;
            const questionHtml = `
                <div class="col">
                    <div class="question-container">
                        <div class="question-header">
                            <div class="question-number">${questionNumber}</div>
                            <h4 class="mb-0">New Question</h4>
                        </div>
                        <div class="question-body">
                            <div class="form-group">
                                <label><i class="fas fa-question-circle"></i> Question Text *</label>
                                <input type="text" name="new_questions[${i}][question]" class="form-control" placeholder="Enter your question" required>
                            </div>
                            <div class="form-group">
                                <label><i class="fas fa-list"></i> Answer Options</label>
                                <div class="option-row">
                                    <span class="option-badge option-badge-1">A</span>
                                    <div class="option-input">
                                        <input type="text" name="new_questions[${i}][option_a]" class="form-control option-input-field" placeholder="Option 1" required>
                                    </div>
                                </div>
                                <div class="option-row">
                                    <span class="option-badge option-badge-2">B</span>
                                    <div class="option-input">
                                        <input type="text" name="new_questions[${i}][option_b]" class="form-control option-input-field" placeholder="Option 2" required>
                                    </div>
                                </div>
                                <div class="option-row">
                                    <span class="option-badge option-badge-3">C</span>
                                    <div class="option-input">
                                        <input type="text" name="new_questions[${i}][option_c]" class="form-control option-input-field" placeholder="Option 3 (optional)">
                                    </div>
                                </div>
                                <div class="option-row">
                                    <span class="option-badge option-badge-4">D</span>
                                    <div class="option-input">
                                        <input type="text" name="new_questions[${i}][option_d]" class="form-control option-input-field" placeholder="Option 4 (optional)">
                                    </div>
                                </div>
                            </div>
                            <div class="form-group">
                                <label><i class="fas fa-check-circle"></i> Correct Answer *</label>
                                <select name="new_questions[${i}][correct_option]" class="correct-answer-select" required>
                                    <option value="1">Option A</option>
                                    <option value="2">Option B</option>
                                    <option value="3" disabled>Option C</option>
                                    <option value="4" disabled>Option D</option>
                                </select>
                            </div>
                            <button type="button" class="remove-button" onclick="removeQuestion(this)">
                                <i class="fas fa-trash-alt"></i> Remove Question
                            </button>
                        </div>
                    </div>
                </div>
            `;
            container.insertAdjacentHTML('beforeend', questionHtml);
        }

        document.querySelectorAll('#new-questions-container .option-input-field').forEach(input => {
            input.addEventListener('input', function() {
                const questionContainer = this.closest('.question-container');
                updateCorrectOptionDropdown(questionContainer);
            });
        });
    });

    document.querySelectorAll('#questions-container input[name$="[option_c]"], #questions-container input[name$="[option_d]"]').forEach(input => {
        input.addEventListener('input', function() {
            const questionContainer = this.closest('.question-container');
            updateCorrectOptionDropdown(questionContainer);
        });
    });

    document.getElementById('quizForm')?.addEventListener('submit', function(e) {
        let hasErrors = false;
        let errorMessages = [];
        
        const requiredInputs = this.querySelectorAll('input[required], select[required]');
        requiredInputs.forEach(input => {
            if (!input.value.trim()) {
                hasErrors = true;
                input.classList.add('is-invalid');
                
                const label = input.closest('.form-group')?.querySelector('label')?.textContent || 'Field';
                errorMessages.push(`${label.replace('*', '').trim()} is required.`);
            } else {
                input.classList.remove('is-invalid');
            }
        });
        
        const questionContainers = document.querySelectorAll('.question-container');
        questionContainers.forEach((container, index) => {
            let filledOptions = 0;
            const optionInputs = container.querySelectorAll('input[name$="[option_a]"], input[name$="[option_b]"], input[name$="[option_c]"], input[name$="[option_d]"]');
            optionInputs.forEach(input => {
                if (input.value.trim()) filledOptions++;
            });
            
            if (filledOptions < 2) {
                hasErrors = true;
                errorMessages.push(`Question ${index + 1} must have at least 2 options.`);
                optionInputs.forEach(input => input.classList.add('is-invalid'));
            }
        });

        if (hasErrors) {
            e.preventDefault();
            const existingAlert = document.querySelector('.alert-danger');
            if (existingAlert) existingAlert.remove();
            
            const errorAlert = document.createElement('div');
            errorAlert.className = 'alert alert-danger';
            errorAlert.innerHTML = `<i class="fas fa-exclamation-circle"></i> Please fix the following errors:<br>` + 
                errorMessages.map(msg => `- ${msg}`).join('<br>');
            
            document.querySelector('.card-body').insertBefore(errorAlert, document.querySelector('.card-body').firstChild);
            window.scrollTo({ top: 0, behavior: 'smooth' });
        }
    });

    document.querySelectorAll('#questions-container .question-container').forEach(container => {
        updateCorrectOptionDropdown(container);
    });
</script>
</body>
</html>