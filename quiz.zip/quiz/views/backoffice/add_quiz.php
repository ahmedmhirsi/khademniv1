<?php
// Include the required controller files (adjust the path if needed)
include '../../controllers/QuizController.php';
include '../../controllers/QuestionController.php';
include 'db_connect.php';
session_start();

// Vérifier si l'utilisateur est connecté
$isLoggedIn = isset($_SESSION["user"]) && isset($_SESSION["user"]["user_id"]);

if ($isLoggedIn) {
    $user_id = $_SESSION["user"]["user_id"];
    $query = "SELECT * FROM users WHERE user_id = :user_id";
    $stmt = $pdo->prepare($query);
    $stmt->execute([':user_id' => $user_id]);
    $user = $stmt->fetch(PDO::FETCH_ASSOC);
}
// Vérifier si l'utilisateur est connecté
if (!isset($_SESSION["user"]) || !isset($_SESSION["user"]["user_id"])) {
  header('Location: ../../auth/login.php');
  exit;
}

// Create controller instances
$quizController = new QuizController();
$questionController = new QuestionController();

$error = "";

// Process form submission
if ($_SERVER["REQUEST_METHOD"] === "POST") {
    try {
        // Trim and validate quiz title, description, and number of questions
        $titre = trim($_POST["titre"] ?? '');
        $description = trim($_POST["description"] ?? '');
        $nbQuestions = intval($_POST["nb_questions"] ?? 0);

        // Server-side validation replacing HTML5 required
        if (empty($titre)) {
            throw new Exception("Quiz title is required.");
        }
        if (empty($description)) {
            throw new Exception("Quiz description is required.");
        }
        if ($nbQuestions <= 0) {
            throw new Exception("Number of questions must be a positive number.");
        }

        // Check if a quiz with the provided title already exists
        $existingQuiz = $quizController->showQuizByTitle($titre);
        if ($existingQuiz) {
            throw new Exception("A quiz with the title '$titre' already exists. Please choose a different title.");
        }

        // Step 1: Validate all questions and their options
        for ($i = 1; $i <= $nbQuestions; $i++) {
            // Validate question text
            $questionText = trim($_POST["question_$i"] ?? '');
            if (empty($questionText)) {
                throw new Exception("Question $i text is required. Please fill in all question fields.");
            }

            // Validate number of options
            $numOptions = intval($_POST["num_options_$i"] ?? 0);
            if ($numOptions === 0) {
                throw new Exception("Number of options for question $i is required. Please select the number of options.");
            }
            if ($numOptions < 2 || $numOptions > 4) {
                throw new Exception("Question $i must have between 2 and 4 options.");
            }

            // Collect and validate options
            $options = [];
            $option_letters = ['A', 'B', 'C', 'D'];
            for ($j = 0; $j < $numOptions; $j++) {
                $optionLetter = $option_letters[$j];
                $option_name = "option_{$optionLetter}_{$i}";
                $optionValue = trim($_POST[$option_name] ?? '');
                if (empty($optionValue)) {
                    throw new Exception("Option $optionLetter for question $i is required. Please fill in all option fields.");
                }
                $options[] = $optionValue;
            }

            // Check for unique options (no duplicates)
            if (count(array_unique($options)) !== count($options)) {
                throw new Exception("Options for question $i must be unique.");
            }

            // Validate correct option
            $correctOption = intval($_POST["correct_option_$i"] ?? 0);
            if ($correctOption === 0) {
                throw new Exception("Correct option for question $i is required. Please select the correct option.");
            }
            if ($correctOption < 1 || $correctOption > $numOptions) {
                throw new Exception("Correct option for question $i must be between 1 and $numOptions.");
            }
        }

        // Step 2: Create the quiz
        $quiz = new Quiz(null, $titre, $description);
        $quizController->createQuiz($quiz);

        // Retrieve the quiz by title to obtain its ID
        $quiz = $quizController->showQuizByTitle($titre);
        if (!$quiz) {
            throw new Exception("Failed to retrieve quiz after creation.");
        }

        // Step 3: Create the questions
        for ($i = 1; $i <= $nbQuestions; $i++) {
            $questionText = trim($_POST["question_$i"]);
            $numOptions = intval($_POST["num_options_$i"]);
            $options = [];
            $option_letters = ['A', 'B', 'C', 'D'];
            for ($j = 0; $j < $numOptions; $j++) {
                $optionLetter = $option_letters[$j];
                $option_name = "option_{$optionLetter}_{$i}";
                $options[] = trim($_POST[$option_name]);
            }
            $correctOption = intval($_POST["correct_option_$i"]);
            $correctLetter = ['a', 'b', 'c', 'd'][$correctOption - 1];

            // Create the question object
            $question = new Question(
                null,              // Auto-incremented ID
                $quiz['id'],       // Quiz ID
                $questionText,     // Question text
                $options[0] ?? null, // Option A
                $options[1] ?? null, // Option B
                $options[2] ?? null, // Option C (optional)
                $options[3] ?? null, // Option D (optional)
                $correctLetter     // Correct option letter
            );

            // Save the question
            $questionController->createQuestion($question);
        }

        // Redirect to the quiz list page after successful insertion
        header('Location: quizlist.php');
        exit();
    } catch (Exception $e) {
        $error = "Error: " . $e->getMessage();
    }
}

// Retrieve submitted values for repopulating the form
$titre = $_POST['titre'] ?? '';
$description = $_POST['description'] ?? '';
$nbQuestions = $_POST['nb_questions'] ?? '1'; // Default to 1
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Create Quiz | Trash2Treasure</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css" rel="stylesheet">
    <style>
        @import url('https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700&display=swap');
        body {
            font-family: 'Poppins', sans-serif;
        }
        .hero-pattern {
            background-color: #f9fafb;
            background-image: url("data:image/svg+xml,%3Csvg width='60' height='60' viewBox='0 0 60 60' xmlns='http://www.w3.org/2000/svg'%3E%3Cg fill='none' fill-rule='evenodd'%3E%3Cg fill='%23d1fae5' fill-opacity='0.4'%3E%3Cpath d='M36 34v-4h-2v4h-4v2h4v4h2v-4h4v-2h-4zm0-30V0h-2v4h-4v2h4v4h2V6h4V4h-4zM6 34v-4H4v4H0v2h4v4h2v-4h4v-2H6zM6 4V0H4v4H0v2h4v4h2V6h4V4H6z'/%3E%3C/g%3E%3C/g%3E%3C/svg%3E");
        }
        .btn-hover {
            transition: all 0.3s ease;
        }
        .btn-hover:hover {
            transform: translateY(-3px);
            box-shadow: 0 10px 15px -3px rgba(0, 0, 0, 0.1), 0 4px 6px -2px rgba(0, 0, 0, 0.05);
        }
        .question-container {
            transition: all 0.3s ease;
        }
        input:focus, select:focus {
            outline: none;
            border-color: #10b981;
            box-shadow: 0 0 0 3px rgba(16, 185, 129, 0.2);
        }
        .disabled-btn {
            background: gray !important;
            cursor: not-allowed;
        }
header {
    display: flex;
    justify-content: space-between;
    align-items: center;
    padding: 20px 40px;
    background-color: #f8f9fa; /* Gris clair */
    color: #333;
    box-shadow: 0 4px 10px rgba(0, 0, 0, 0.1);
    border-bottom: 1px solid #ddd; /* Ligne fine pour séparer l'en-tête */
}

header .logo {
    
        font-size: 24px;
        font-weight: 700;
        color: #5f687b;
    
}

header nav {
    display: flex;
    align-items: center;
}

header nav a {
    color: #333;
    text-decoration: none;
    margin: 0 15px;
    font-size: 16px;
    font-weight: 500;
    transition: color 0.3s ease, transform 0.2s ease;
}

header nav a.active {
    border-bottom: 2px solid #28a745; /* Indicateur actif en vert */
}

header nav a:hover {
    color: #28a745; /* Vert au survol */
    transform: scale(1.1);
}
.profile-menu {
    position: relative;
    display: inline-block;
}

/* Style pour le menu déroulant */
.dropdown-menu {
    display: none;
    position: absolute;
    top: 20px;
    right: 0;
    background-color: #fff;
    border: 1px solid #ddd;
    border-radius: 5px;
    box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
    z-index: 1000;
    width: 180px;
}

.dropdown-menu a {
    display: block;
    padding: 10px;
    padding-right:80px;
    color: #333;
    text-decoration: none;
    font-size: 14px;
    transition: background-color 0.3s ease;
}

.dropdown-menu a:hover {
    background-color: #f4f4f9; /* Gris clair */
}

/* Afficher le menu déroulant au survol */
.profile-menu:hover .dropdown-menu {
    display: block;
}

    </style>
</head>

<body >
<header>
    <div class="logo">Khademni</div>
    <nav>
        <a href="../../../index.php" class="<?php echo basename($_SERVER['PHP_SELF']) == 'index.php' ? 'active' : ''; ?>">Home</a>
        <a href="../../../offer/mvc/views/listeView.php" class="<?php echo basename($_SERVER['PHP_SELF']) == 'list_jobs.php' ? 'active' : ''; ?>">Offres d'emploi</a>
        <a href="../../../quiz/views/frontoffice/quiz_list.php" class="<?php echo basename($_SERVER['PHP_SELF']) == 'blog.php' ? 'active' : ''; ?>">Test & Quiz</a>
        <a href="../../../valid/payment-processing-app/frontend/index.php" class="<?php echo basename($_SERVER['PHP_SELF']) == 'pricing.php' ? 'active' : ''; ?>">Paiment</a>
        
        <?php if ($isLoggedIn): ?>
            <div class="profile-menu">
                <img src="../../../user/controllers/<?php echo htmlspecialchars($user['pdp'] ?? ''); ?>" alt="Profile Picture" class="profile-pic" style="width: 100px; height: auto;">
                <div class="dropdown-menu">
                    <a href="../../../user/views/layouts/main/main.php">Voir Profil</a>
                    <a href="../../../user/controllers/logout.php">Se Déconnecter</a>
                </div>
            </div>
        <?php else: ?>
            <a href="../auth/login.php" class="button">Se connecter</a>
        <?php endif; ?>
    </nav>
</header>
    
    <!-- Main Content -->
    <main class="flex-grow hero-pattern">
        <div class="container mx-auto px-4 py-12">
            <div class="max-w-4xl mx-auto bg-white rounded-xl shadow-md overflow-hidden">
                <div class="p-8">
                    <div class="flex items-center mb-6">
                        <i class="fas fa-plus-circle text-green-600 text-2xl mr-3"></i>
                        <h2 class="text-3xl font-bold text-gray-800">Create New Quiz</h2>
                    </div>
                    
                    <?php if (!empty($error)): ?>
                        <div class="bg-red-50 border-l-4 border-red-500 p-4 mb-6 rounded">
                            <div class="flex">
                                <div class="flex-shrink-0">
                                    <i class="fas fa-exclamation-circle text-red-500"></i>
                                </div>
                                <div class="ml-3">
                                    <p class="text-red-700"><?php echo htmlspecialchars($error); ?></p>
                                </div>
                            </div>
                        </div>
                    <?php endif; ?>

                    <!-- Instruction for users -->
                    <div class="bg-blue-50 p-4 mb-6 rounded">
                        <p class="text-blue-700">
                            1. Enter the quiz title, description, and number of questions.<br>
                            2. For each question, type the question text and select the number of options (2-4).<br>
                            3. Fill in the option fields and choose the correct option.<br>
                            4. Click "Create Quiz" to save.
                        </p>
                    </div>

                    <!-- Start of Form -->
                    <form method="POST" action="" class="space-y-6" id="quizForm">
                        <!-- Quiz Info Section -->
                        <div class="bg-green-50 p-6 rounded-lg">
                            <h3 class="text-xl font-semibold text-green-800 mb-4">Quiz Information</h3>
                            
                            <div class="grid grid-cols-1 md:grid-cols-2 gap-6">
                                <!-- Quiz Title -->
                                <div>
                                    <label for="titre" class="block text-sm font-medium text-gray-700 mb-1">Quiz Title</label>
                                    <div class="relative">
                                        <div class="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                                            <i class="fas fa-heading text-gray-400"></i>
                                        </div>
                                        <input type="text" id="titre" name="titre" value="<?php echo htmlspecialchars($titre); ?>" 
                                               class="block w-full pl-10 pr-3 py-2 border border-gray-300 rounded-md shadow-sm focus:ring-green-500 focus:border-green-500" 
                                               placeholder="Enter quiz title">
                                    </div>
                                </div>

                                <!-- Number of Questions -->
                                <div>
                                    <label for="nb_questions" class="block text-sm font-medium text-gray-700 mb-1">Number of Questions</label>
                                    <div class="relative">
                                        <div class="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                                            <i class="fas fa-list-ol text-gray-400"></i>
                                        </div>
                                        <input type="number" id="nb_questions" name="nb_questions" min="1" max="20" value="<?php echo htmlspecialchars($nbQuestions); ?>" 
                                               class="block w-full pl-10 pr-3 py-2 border border-gray-300 rounded-md shadow-sm focus:ring-green-500 focus:border-green-500" 
                                               placeholder="How many questions?">
                                    </div>
                                </div>
                            </div>

                            <!-- Quiz Description -->
                            <div class="mt-4">
                                <label for="description" class="block text-sm font-medium text-gray-700 mb-1">Quiz Description</label>
                                <div class="relative">
                                    <div class="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                                        <i class="fas fa-info-circle text-gray-400"></i>
                                    </div>
                                    <textarea id="description" name="description" rows="3"
                                              class="block w-full pl-10 pr-3 py-2 border border-gray-300 rounded-md shadow-sm focus:ring-green-500 focus:border-green-500" 
                                              placeholder="Describe your quiz"><?php echo htmlspecialchars($description); ?></textarea>
                                </div>
                            </div>
                        </div>

                        <!-- Container to hold dynamically created questions -->
                        <div id="questionsContainer" class="space-y-6"></div>

                        <!-- Submit Button -->
                        <div class="flex justify-end">
                            <button type="submit" id="submitButton" 
                                    class="bg-gradient-to-r from-green-500 to-green-600 text-white px-6 py-3 rounded-lg text-lg font-semibold hover:from-green-600 hover:to-green-700 transition flex items-center justify-center btn-hover disabled-btn" disabled>
                                <i class="fas fa-save mr-2"></i> Create Quiz
                            </button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </main>

    <script>
        // Function to initialize or update question fields
        function initializeQuestions(numQuestions, existingData = {}) {
            console.log(`Initializing ${numQuestions} questions`);
            const container = document.getElementById('questionsContainer');
            const currentQuestionDivs = container.querySelectorAll('.question-container');
            const currentNumQuestions = currentQuestionDivs.length;

            if (isNaN(numQuestions) || numQuestions <= 0) {
                console.log('Invalid number of questions, clearing container');
                container.innerHTML = '';
                updateSubmitButton();
                return;
            }

            // If reducing the number of questions, remove excess question divs
            if (numQuestions < currentNumQuestions) {
                for (let i = currentNumQuestions; i > numQuestions; i--) {
                    const questionDiv = container.querySelector(`.question-container:nth-child(${i})`);
                    if (questionDiv) {
                        questionDiv.remove();
                    }
                }
            }

            // Create or update question divs
            for (let i = 1; i <= numQuestions; i++) {
                const questionData = existingData[i] || {
                    text: '',
                    numOptions: '',
                    options: {},
                    correctOption: ''
                };

                let questionDiv = container.querySelector(`.question-container:nth-child(${i})`);
                if (!questionDiv) {
                    questionDiv = document.createElement('div');
                    questionDiv.classList.add('question-container', 'bg-white', 'border', 'border-gray-200', 'rounded-lg', 'shadow-sm', 'overflow-hidden');
                    container.appendChild(questionDiv);
                }

                questionDiv.innerHTML = `
                    <div class="bg-gray-50 px-6 py-4 border-b border-gray-200 flex items-center">
                        <div class="w-8 h-8 rounded-full bg-green-100 flex items-center justify-center text-green-800 font-bold mr-3">
                            ${i}
                        </div>
                        <h3 class="text-lg font-medium text-gray-900">Question ${i}</h3>
                    </div>
                    
                    <div class="p-6 space-y-4">
                        <!-- Question Text -->
                        <div>
                            <label for="question_${i}" class="block text-sm font-medium text-gray-700 mb-1">Question Text</label>
                            <input type="text" id="question_${i}" name="question_${i}" 
                                value="${questionData.text.replace(/"/g, '"')}" 
                                class="block w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:ring-green-500 focus:border-green-500" 
                                placeholder="Enter your question" oninput="updateSubmitButton()">
                        </div>
                        
                        <!-- Number of Options -->
                        <div>
                            <label for="num_options_${i}" class="block text-sm font-medium text-gray-700 mb-1">Number of Options</label>
                            <select id="num_options_${i}" name="num_options_${i}" 
                                class="block w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:ring-green-500 focus:border-green-500">
                                <option value="">Select number of options</option>
                                <option value="2" ${questionData.numOptions === '2' ? 'selected' : ''}>2 Options</option>
                                <option value="3" ${questionData.numOptions === '3' ? 'selected' : ''}>3 Options</option>
                                <option value="4" ${questionData.numOptions === '4' ? 'selected' : ''}>4 Options</option>
                            </select>
                        </div>
                        
                        <!-- Options Container -->
                        <div id="options_${i}" class="space-y-3 pt-2"></div>
                        
                        <!-- Correct Option -->
                        <div>
                            <label for="correct_option_${i}" class="block text-sm font-medium text-gray-700 mb-1">Correct Option</label>
                            <select id="correct_option_${i}" name="correct_option_${i}" 
                                class="block w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:ring-green-500 focus:border-green-500" 
                                onchange="updateSubmitButton()">
                                <option value="">Select correct option</option>
                            </select>
                        </div>
                    </div>
                `;

                // Initialize options for this question
                updateOptions(i, parseInt(questionData.numOptions) || 0, questionData.options, questionData.correctOption);

                // Add event listener for number of options change
                const numOptionsSelect = document.getElementById(`num_options_${i}`);
                numOptionsSelect.addEventListener('change', function() {
                    console.log(`Number of options changed for question ${i}: ${this.value}`);
                    const numOptions = parseInt(this.value);
                    updateOptions(i, numOptions, existingData[i]?.options || {}, existingData[i]?.correctOption || '');
                    updateSubmitButton();
                });
            }
            updateSubmitButton();
        }

        // Function to update options for a specific question
        function updateOptions(questionIndex, numOptions, existingOptions = {}, existingCorrectOption = '') {
            console.log(`Updating options for question ${questionIndex}: ${numOptions} options`);
            const optionsContainer = document.getElementById(`options_${questionIndex}`);
            const correctOptionSelect = document.getElementById(`correct_option_${questionIndex}`);
            
            optionsContainer.innerHTML = '';
            correctOptionSelect.innerHTML = '<option value="">Select correct option</option>';

            if (isNaN(numOptions) || numOptions < 2 || numOptions > 4) {
                console.log(`Invalid number of options for question ${questionIndex}`);
                return;
            }

            const optionLetters = ['A', 'B', 'C', 'D'];
            for (let j = 0; j < numOptions; j++) {
                const optionLetter = optionLetters[j];
                const optionValue = existingOptions[optionLetter] || '';

                const optionField = document.createElement('div');
                optionField.classList.add('relative');
                optionField.innerHTML = `
                    <div class="absolute inset-y-0 left-0 flex items-center pl-3">
                        <span class="w-6 h-6 rounded-full bg-${j === 0 ? 'green' : j === 1 ? 'blue' : j === 2 ? 'yellow' : 'red'}-100 flex items-center justify-center text-${j === 0 ? 'green' : j === 1 ? 'blue' : j === 2 ? 'yellow' : 'red'}-800 font-medium text-sm">
                            ${optionLetter}
                        </span>
                    </div>
                    <input type="text" id="option_${optionLetter}_${questionIndex}" name="option_${optionLetter}_${questionIndex}" 
                        value="${optionValue.replace(/"/g, '"')}" 
                        class="block w-full pl-12 pr-3 py-2 border border-gray-300 rounded-md shadow-sm focus:ring-green-500 focus:border-green-500" 
                        placeholder="Enter Option ${optionLetter}" oninput="updateSubmitButton()">
                `;
                optionsContainer.appendChild(optionField);

                const correctOption = document.createElement('option');
                correctOption.value = j + 1;
                correctOption.textContent = `Option ${optionLetter}`;
                if (existingCorrectOption === String(j + 1)) {
                    correctOption.selected = true;
                }
                correctOptionSelect.appendChild(correctOption);
            }
            updateSubmitButton();
        }

        // Function to collect current form data
        function getFormData() {
            const formData = {};
            const numQuestionsInput = document.getElementById('nb_questions').value;
            const numQuestions = parseInt(numQuestionsInput) || 0;

            for (let i = 1; i <= numQuestions; i++) {
                const questionText = document.getElementById(`question_${i}`)?.value || '';
                const numOptions = document.getElementById(`num_options_${i}`)?.value || '';
                const correctOption = document.getElementById(`correct_option_${i}`)?.value || '';
                const options = {};

                ['A', 'B', 'C', 'D'].forEach(letter => {
                    const optionInput = document.getElementById(`option_${letter}_${i}`);
                    if (optionInput) {
                        options[letter] = optionInput.value;
                    }
                });

                formData[i] = {
                    text: questionText,
                    numOptions: numOptions,
                    options: options,
                    correctOption: correctOption
                };
            }
            return formData;
        }

        // Function to check if form is valid to enable submit button
        function updateSubmitButton() {
            const submitButton = document.getElementById('submitButton');
            const numQuestions = parseInt(document.getElementById('nb_questions').value) || 0;
            let isValid = true;

            if (numQuestions <= 0) {
                isValid = false;
            } else {
                for (let i = 1; i <= numQuestions; i++) {
                    const questionText = document.getElementById(`question_${i}`)?.value.trim() || '';
                    const numOptions = parseInt(document.getElementById(`num_options_${i}`)?.value) || 0;
                    const correctOption = document.getElementById(`correct_option_${i}`)?.value || '';

                    if (!questionText || numOptions < 2 || !correctOption) {
                        isValid = false;
                        break;
                    }

                    const optionLetters = ['A', 'B', 'C', 'D'].slice(0, numOptions);
                    for (let letter of optionLetters) {
                        const optionValue = document.getElementById(`option_${letter}_${i}`)?.value.trim() || '';
                        if (!optionValue) {
                            isValid = false;
                            break;
                        }
                    }
                }
            }

            if (isValid) {
                submitButton.removeAttribute('disabled');
                submitButton.classList.remove('disabled-btn');
            } else {
                submitButton.setAttribute('disabled', 'true');
                submitButton.classList.add('disabled-btn');
            }
        }

        // Initialize questions on page load
        document.addEventListener('DOMContentLoaded', function() {
            const numQuestionsInput = document.getElementById('nb_questions');
            // Default to 1 question if no value is set
            const initialNumQuestions = parseInt(numQuestionsInput.value) || 1;

            // Initialize with existing POST data if available
            const initialData = <?php
                $initialData = [];
                if ($_SERVER['REQUEST_METHOD'] === 'POST') {
                    $nbQuestions = intval($_POST['nb_questions'] ?? 0);
                    for ($i = 1; $i <= $nbQuestions; $i++) {
                        $questionData = [
                            'text' => $_POST["question_$i"] ?? '',
                            'numOptions' => $_POST["num_options_$i"] ?? '',
                            'correctOption' => $_POST["correct_option_$i"] ?? '',
                            'options' => []
                        ];
                        foreach (['A', 'B', 'C', 'D'] as $letter) {
                            $optionName = "option_{$letter}_{$i}";
                            if (isset($_POST[$optionName])) {
                                $questionData['options'][$letter] = $_POST[$optionName];
                            }
                        }
                        $initialData[$i] = $questionData;
                    }
                }
                echo json_encode($initialData);
            ?>;

            // Initialize with at least one question
            initializeQuestions(initialNumQuestions, initialData);

            // Listen for changes in number of questions
            numQuestionsInput.addEventListener('input', function() {
                console.log(`Number of questions changed: ${this.value}`);
                const numQuestions = parseInt(this.value) || 1;
                initializeQuestions(numQuestions, getFormData());
            });

            // Also listen for change event to handle select dropdowns or manual input confirmation
            numQuestionsInput.addEventListener('change', function() {
                console.log(`Number of questions confirmed: ${this.value}`);
                const numQuestions = parseInt(this.value) || 1;
                initializeQuestions(numQuestions, getFormData());
            });

            // Update submit button on any input change
            document.getElementById('quizForm').addEventListener('input', updateSubmitButton);
        });

        // Mobile menu toggle (if applicable)
        document.querySelector('.fa-bars')?.addEventListener('click', function() {
            document.querySelector('nav').classList.toggle('hidden');
        });
    </script>

</body>
</html>