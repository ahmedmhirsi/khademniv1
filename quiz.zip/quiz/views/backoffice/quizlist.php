<?php
include '../../controllers/QuizController.php';
include '../../controllers/QuestionController.php';
include 'db_connect.php';
session_start();

// Vérifier si l'utilisateur est connecté
$isLoggedIn = isset($_SESSION["user"]) && isset($_SESSION["user"]["user_id"]);

if ($isLoggedIn) {
    $user_id = $_SESSION["user"]["user_id"];
    $query = "SELECT * FROM users WHERE user_id = :user_id";
    $stmt = $pdo->prepare($query);
    $stmt->execute([':user_id' => $user_id]);
    $user = $stmt->fetch(PDO::FETCH_ASSOC);
}
// Vérifier si l'utilisateur est connecté
if (!isset($_SESSION["user"]) || !isset($_SESSION["user"]["user_id"])) {
  header('Location: ../../auth/login.php');
  exit;
}


$quizController = new QuizController();
$questionController = new QuestionController();

// Retrieve all quizzes and questions from the database.
$quizzes = $quizController->listQuizzes() ?: [];
$questions = $questionController->listQuestions() ?: [];

if (empty($quizzes) || empty($questions)) {
    error_log("Warning: No quizzes or questions retrieved on " . date('Y-m-d H:i:s'));
}
?>
<!DOCTYPE html>
<html lang="en" data-theme="forest">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Khademni - Quiz challenge</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700&family=Montserrat:wght@400;600;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="quiz_styles.css">
    <style>
        /* En-tête */
header {
    display: flex;
    justify-content: space-between;
    align-items: center;
    padding: 20px 40px;
    background-color: #f8f9fa; /* Gris clair */
    color: #333;
    box-shadow: 0 4px 10px rgba(0, 0, 0, 0.1);
    border-bottom: 1px solid #ddd; /* Ligne fine pour séparer l'en-tête */
}

header .logo {
    
        font-size: 24px;
        font-weight: 700;
        color: #5f687b;
    
}

header nav {
    display: flex;
    align-items: center;
}

header nav a {
    color: #333;
    text-decoration: none;
    margin: 0 15px;
    font-size: 16px;
    font-weight: 500;
    transition: color 0.3s ease, transform 0.2s ease;
}

header nav a.active {
    border-bottom: 2px solid #28a745; /* Indicateur actif en vert */
}

header nav a:hover {
    color: #28a745; /* Vert au survol */
    transform: scale(1.1);
}
.profile-menu {
    position: relative;
    display: inline-block;
}

/* Style pour le menu déroulant */
.dropdown-menu {
    display: none;
    position: absolute;
    top: 20px;
    right: 0;
    background-color: #fff;
    border: 1px solid #ddd;
    border-radius: 5px;
    box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
    z-index: 1000;
    width: 180px;
}

.dropdown-menu a {
    display: block;
    padding: 10px;
    padding-right:80px;
    color: #333;
    text-decoration: none;
    font-size: 14px;
    transition: background-color 0.3s ease;
}

.dropdown-menu a:hover {
    background-color: #f4f4f9; /* Gris clair */
}

/* Afficher le menu déroulant au survol */
.profile-menu:hover .dropdown-menu {
    display: block;
}

    </style>
</head>
<body>
<header>
    <div class="logo">Khademni</div>
    <nav>
        <a href="../../../index.php" class="<?php echo basename($_SERVER['PHP_SELF']) == 'index.php' ? 'active' : ''; ?>">Home</a>
        <a href="../../../offer/mvc/views/listeView.php" class="<?php echo basename($_SERVER['PHP_SELF']) == 'list_jobs.php' ? 'active' : ''; ?>">Offres d'emploi</a>
        <a href="../../../quiz/views/frontoffice/quiz_list.php" class="<?php echo basename($_SERVER['PHP_SELF']) == 'blog.php' ? 'active' : ''; ?>">Test & Quiz</a>
        <a href="../../../valid/payment-processing-app/frontend/index.php" class="<?php echo basename($_SERVER['PHP_SELF']) == 'pricing.php' ? 'active' : ''; ?>">Paiment</a>
        
        <?php if ($isLoggedIn): ?>
            <div class="profile-menu">
                <img src="../../../user/controllers/<?php echo htmlspecialchars($user['pdp'] ?? ''); ?>" alt="Profile Picture" class="profile-pic" style="width: 100px; height: auto;">
                <div class="dropdown-menu">
                    <a href="../../../user/views/layouts/main/main.php">Voir Profil</a>
                    <a href="../../../user/controllers/logout.php">Se Déconnecter</a>
                </div>
            </div>
        <?php else: ?>
            <a href="../auth/login.php" class="button">Se connecter</a>
        <?php endif; ?>
    </nav>
</header>
    <div class="eco-bg"></div>
    <div id="fireflies" class="fixed inset-0 pointer-events-none"></div>
    <div id="ripples" class="fixed inset-0 pointer-events-none"></div>
    <main class="container mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <section class="hero-section text-primary rounded-lg mb-8">
            <div class="p-8 md:p-12">
                <div class="flex justify-between items-center mb-8">
                    <a href="index.php" class="back-arrow" aria-label="Back to home">
                        <i class="fas fa-arrow-left w-5 h-5"></i>
                    </a>
                    <div class="text-center">
                        <h1 class="text-2xl sm:text-3xl font-bold font-montserrat glow-text">
                         Khademni Quiz Dashboard
                        </h1>
                        <p class="text-secondary mt-2 max-w-lg mx-auto">Manage your quizzes</p>
                    </div>
                    <div class="badge bg-[var(--accent)] text-white px-3 py-1 rounded-full text-sm font-semibold">
                        <i class="fas fa-seedling mr-1"></i> Admin View
                    </div>
                </div>
                <div class="stats-container flex flex-col sm:flex-row gap-4 mb-6">
                    <div class="feature-card p-4 flex-1 text-center">
                        <h3 class="text-sm uppercase font-semibold text-secondary mb-2">Total Quizzes</h3>
                        <p class="text-2xl font-bold text-primary stats-value"><?php echo count($quizzes); ?></p>
                    </div>
                    <div class="feature-card p-4 flex-1 text-center">
                        <h3 class="text-sm uppercase font-semibold text-secondary mb-2">Total Questions</h3>
                        <p class="text-2xl font-bold text-primary stats-value"><?php echo count($questions); ?></p>
                    </div>
                </div>

                <a href="add_quiz.php" class="animated-btn mb-6 inline-flex items-center" aria-label="Add new EcoChallenge quiz">
                    <i class="fas fa-plus-circle mr-2"></i> Add New Quiz
                </a>
                <div class="quiz-list">
                    <?php if (empty($quizzes)): ?>
                        <div class="feature-card p-6 text-center">
                            <i class="fas fa-info-circle text-accent text-2xl mb-2"></i>
                            <p class="text-secondary">No quizzes have been created yet. Click "Add New Quiz" to get started!</p>
                        </div>
                    <?php else: ?>
                        <?php foreach ($quizzes as $index => $quiz): ?>
                            <div class="feature-card p-6 mb-4 quiz-card" data-quiz-id="<?php echo htmlspecialchars($quiz['id']); ?>">
                                <div class="flex justify-between items-center">
                                    <h2 class="text-lg font-semibold text-primary">
                                        <i class="fas fa-book-open mr-2"></i> <?php echo htmlspecialchars($quiz['title'] ?? 'No Title'); ?>
                                    </h2>
                                    <button class="toggle-questions animated-btn" aria-expanded="false" aria-controls="questions-<?php echo $index; ?>">
                                        <i class="fas fa-chevron-down"></i> Show Questions
                                    </button>
                                </div>
                                <div id="questions-<?php echo $index; ?>" class="questions-container hidden mt-4">
                                    <?php
                                    $quizQuestions = array_filter($questions, function($question) use ($quiz) {
                                        return isset($question['quiz_id']) && $question['quiz_id'] == $quiz['id'];
                                    });
                                    if (empty($quizQuestions)):
                                    ?>
                                        <p class="text-secondary">No questions added yet.</p>
                                    <?php else: ?>
                                        <?php foreach ($quizQuestions as $question): ?>
                                            <div class="question p-4 mb-2 rounded-lg bg-[rgba(255,255,255,0.85)] border border-[rgba(0,0,0,0.05)]">
                                                <p class="text-primary font-semibold mb-2">
                                                    <i class="fas fa-question-circle mr-2"></i> <?php echo htmlspecialchars($question['question_text'] ?? 'No Question'); ?>
                                                </p>
                                                <?php
                                                $options = [
                                                    'a' => $question['option_a'] ?? '',
                                                    'b' => $question['option_b'] ?? '',
                                                    'c' => $question['option_c'] ?? '',
                                                    'd' => $question['option_d'] ?? ''
                                                ];
                                                foreach ($options as $key => $value):
                                                    if (!empty($value)):
                                                        $isCorrect = strtolower($question['correct_option']) === $key;
                                                ?>
                                                        <div class="option-label mb-2 <?php echo $isCorrect ? 'correct' : ''; ?>">
                                                            <span class="option-radio <?php echo $isCorrect ? 'border-[var(--accent)]' : ''; ?>"></span>
                                                            <span class="option-text"><?php echo strtoupper($key) . ': ' . htmlspecialchars($value); ?></span>
                                                        </div>
                                                <?php
                                                    endif;
                                                endforeach;
                                                ?>
                                                <p class="correct-answer text-sm mt-2">
                                                    <i class="fas fa-check-circle text-accent mr-1"></i> Correct Answer: <?php echo strtoupper($question['correct_option']); ?>
                                                </p>
                                            </div>
                                        <?php endforeach; ?>
                                    <?php endif; ?>
                                </div>
                                <div class="action-buttons flex gap-4 mt-4">
                                    <a href="updateQuiz.php?id=<?php echo htmlspecialchars($quiz['id'] ?? ''); ?>" class="animated-btn btn-secondary" aria-label="Edit quiz">
                                        <i class="fas fa-edit mr-2"></i> Edit
                                    </a>
                                    <a href="deleteQuiz.php?id=<?php echo htmlspecialchars($quiz['id'] ?? ''); ?>" class="animated-btn btn-danger" onclick="return confirm('Are you sure you want to delete this eco-quiz?');" aria-label="Delete quiz">
                                        <i class="fas fa-trash-alt mr-2"></i> Delete
                                    </a>
                                </div>
                            </div>
                        <?php endforeach; ?>
                    <?php endif; ?>
                </div>
            </div>
        </section>
    </main>
    <script>
        // Theme selector
        const themeSelect = document.getElementById('themeSelect');
        themeSelect.addEventListener('change', (e) => {
            document.documentElement.setAttribute('data-theme', e.target.value);
        });

        // Toggle questions
        document.querySelectorAll('.toggle-questions').forEach(button => {
            button.addEventListener('click', () => {
                const quizCard = button.closest('.quiz-card');
                const questionsContainer = quizCard.querySelector('.questions-container');
                const isExpanded = button.getAttribute('aria-expanded') === 'true';
                questionsContainer.classList.toggle('hidden');
                button.setAttribute('aria-expanded', !isExpanded);
                button.innerHTML = `<i class="fas fa-chevron-${isExpanded ? 'down' : 'up'}"></i> ${isExpanded ? 'Show' : 'Hide'} Questions`;
            });
        });

        // Firefly animation
        const firefliesContainer = document.getElementById('fireflies');
        for (let i = 0; i < 25; i++) {
            const firefly = document.createElement('div');
            firefly.className = 'firefly';
            firefly.style.left = `${Math.random() * 100}vw`;
            firefly.style.top = `${Math.random() * 100}vh`;
            firefly.style.animationDelay = `${Math.random() * 5}s`;
            firefly.style.animationDuration = `${6 + Math.random() * 4}s`;
            firefliesContainer.appendChild(firefly);
        }

        // Falling leaves
        for (let i = 0; i < 15; i++) {
            const leaf = document.createElement('div');
            leaf.className = 'leaf';
            leaf.style.left = `${Math.random() * 100}vw`;
            leaf.style.animationDelay = `${Math.random() * 10}s`;
            leaf.style.animationDuration = `${15 + Math.random() * 10}s`;
            firefliesContainer.appendChild(leaf);
        }

        // Water ripple effect
        const ripplesContainer = document.getElementById('ripples');
        for (let i = 0; i < 10; i++) {
            const ripple = document.createElement('div');
            ripple.className = 'ripple';
            ripple.style.left = `${Math.random() * 100}vw`;
            ripple.style.top = `${Math.random() * 100}vh`;
            ripple.style.animationDelay = `${Math.random() * 5}s`;
            ripple.style.animationDuration = `${3 + Math.random() * 2}s`;
            ripplesContainer.appendChild(ripple);
        };
    </script>
</body>
</html>