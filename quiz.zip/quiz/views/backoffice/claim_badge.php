<?php
require_once '../controllers/BadgeController.php';
header('Content-Type: application/json');
session_start();

if (!isset($_SESSION['user_id'])) {
    echo json_encode(['success' => false, 'message' => 'Please log in to claim badges.']);
    exit;
}

$input = json_decode(file_get_contents('php://input'), true);
$badgeId = $input['badge_id'] ?? null;
$userId = $_SESSION['user_id'];

if (!$badgeId) {
    echo json_encode(['success' => false, 'message' => 'Invalid badge ID.']);
    exit;
}

$badgeController = new BadgeController();
$result = $badgeController->assignBadge($userId, $badgeId);

echo json_encode($result);
?>