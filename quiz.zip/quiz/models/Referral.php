<?php

class Referral {
    private ?int $id;
    private ?int $referrer_user_id;
    private ?int $referred_user_id;
    private ?int $referral_code_id;
    private ?string $created_at;

    public function __construct(?int $id, ?int $referrer_user_id, ?int $referred_user_id, ?int $referral_code_id, ?string $created_at) {
        $this->id = $id;
        $this->referrer_user_id = $referrer_user_id;
        $this->referred_user_id = $referred_user_id;
        $this->referral_code_id = $referral_code_id;
        $this->created_at = $created_at;
    }

    public function getId(): ?int {
        return $this->id;
    }

    public function setId(?int $id): void {
        $this->id = $id;
    }

    public function getReferrerUserId(): ?int {
        return $this->referrer_user_id;
    }

    public function setReferrerUserId(?int $referrer_user_id): void {
        $this->referrer_user_id = $referrer_user_id;
    }

    public function getReferredUserId(): ?int {
        return $this->referred_user_id;
    }

    public function setReferredUserId(?int $referred_user_id): void {
        $this->referred_user_id = $referred_user_id;
    }

    public function getReferralCodeId(): ?int {
        return $this->referral_code_id;
    }

    public function setReferralCodeId(?int $referral_code_id): void {
        $this->referral_code_id = $referral_code_id;
    }

    public function getCreatedAt(): ?string {
        return $this->created_at;
    }

    public function setCreatedAt(?string $created_at): void {
        $this->created_at = $created_at;
    }
}
?>