<?php
class User {
    private ?int $id;
    private ?string $username;
    private ?string $email;
    private ?string $password_hash;
    private ?string $created_at;

    public function __construct(?int $id, ?string $username, ?string $email, ?string $password_hash, ?string $created_at) {
        $this->id = $id;
        $this->username = $username;
        $this->email = $email;
        $this->password_hash = $password_hash;
        $this->created_at = $created_at;
    }

    public function getId(): ?int {
        return $this->id;
    }

    public function setId(?int $id): void {
        $this->id = $id;
    }

    public function getUsername(): ?string {
        return $this->username;
    }

    public function setUsername(?string $username): void {
        $this->username = $username;
    }

    public function getEmail(): ?string {
        return $this->email;
    }

    public function setEmail(?string $email): void {
        $this->email = $email;
    }

    public function getPasswordHash(): ?string {
        return $this->password_hash;
    }

    public function setPasswordHash(?string $password_hash): void {
        $this->password_hash = $password_hash;
    }

    public function getCreatedAt(): ?string {
        return $this->created_at;
    }

    public function setCreatedAt(?string $created_at): void {
        $this->created_at = $created_at;
    }
}
?>