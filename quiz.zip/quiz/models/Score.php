<?php

class Score {
    private ?int $id;
    private ?int $user_id;
    private ?int $quiz_id;
    private ?int $score;
    private ?int $eco_points;
    private ?string $created_at;
    private ?string $type;

    public function __construct(?int $id, ?int $user_id, ?int $quiz_id, ?int $score, ?int $eco_points, ?string $created_at, ?string $type = 'quiz') {
        $this->id = $id;
        $this->user_id = $user_id;
        $this->quiz_id = $quiz_id;
        $this->score = $score;
        $this->eco_points = $eco_points;
        $this->created_at = $created_at;
        $this->type = $type;
    }

    public function getId(): ?int {
        return $this->id;
    }

    public function setId(?int $id): void {
        $this->id = $id;
    }

    public function getUserId(): ?int {
        return $this->user_id;
    }

    public function setUserId(?int $user_id): void {
        $this->user_id = $user_id;
    }

    public function getQuizId(): ?int {
        return $this->quiz_id;
    }

    public function setQuizId(?int $quiz_id): void {
        $this->quiz_id = $quiz_id;
    }

    public function getScore(): ?int {
        return $this->score;
    }

    public function setScore(?int $score): void {
        $this->score = $score;
    }

    public function getEcoPoints(): ?int {
        return $this->eco_points;
    }

    public function setEcoPoints(?int $eco_points): void {
        $this->eco_points = $eco_points;
    }

    public function getCreatedAt(): ?string {
        return $this->created_at;
    }

    public function setCreatedAt(?string $created_at): void {
        $this->created_at = $created_at;
    }

    public function getType(): ?string {
        return $this->type;
    }

    public function setType(?string $type): void {
        $this->type = $type;
    }
}
?>