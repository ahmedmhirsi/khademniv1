<?php

class Question {
    private ?int $id;
    private ?int $quiz_id;
    private ?string $question_text;
    private ?string $option_a;
    private ?string $option_b;
    private ?string $option_c;
    private ?string $option_d;
    private ?string $correct_option;

    public function __construct(
        ?int $id, 
        ?int $quiz_id, 
        ?string $question_text, 
        ?string $option_a, 
        ?string $option_b, 
        ?string $option_c, 
        ?string $option_d, 
        ?string $correct_option
    ) {
        $this->id = $id;
        $this->quiz_id = $quiz_id;
        $this->question_text = $question_text;
        $this->option_a = $option_a;
        $this->option_b = $option_b;
        $this->option_c = $option_c;
        $this->option_d = $option_d;
        $this->correct_option = $correct_option;
    }

    public function getId(): ?int {
        return $this->id;
    }

    public function setId(?int $id): void {
        $this->id = $id;
    }

    public function getQuizId(): ?int {
        return $this->quiz_id;
    }

    public function setQuizId(?int $quiz_id): void {
        $this->quiz_id = $quiz_id;
    }

    public function getQuestionText(): ?string {
        return $this->question_text;
    }

    public function setQuestionText(?string $question_text): void {
        $this->question_text = $question_text;
    }

    public function getOptionA(): ?string {
        return $this->option_a;
    }

    public function setOptionA(?string $option_a): void {
        $this->option_a = $option_a;
    }

    public function getOptionB(): ?string {
        return $this->option_b;
    }

    public function setOptionB(?string $option_b): void {
        $this->option_b = $option_b;
    }

    public function getOptionC(): ?string {
        return $this->option_c;
    }

    public function setOptionC(?string $option_c): void {
        $this->option_c = $option_c;
    }

    public function getOptionD(): ?string {
        return $this->option_d;
    }

    public function setOptionD(?string $option_d): void {
        $this->option_d = $option_d;
    }

    public function getCorrectOption(): ?string {
        return $this->correct_option;
    }

    public function setCorrectOption(?string $correct_option): void {
        $this->correct_option = $correct_option;
    }
}
?>
