<?php
require_once __DIR__ . '/../config.php';
require_once __DIR__ . '/../models/User.php';
require_once __DIR__ . '/ReferralController.php';

class UserController {
    private $pdo;

    public function __construct() {
        $this->pdo = config::getConnexion();
    }

    public function register($username, $email, $password, $referralCode = null) {
        if (empty($username) || empty($email) || empty($password)) {
            return ['success' => false, 'message' => 'All fields are required.'];
        }

        if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
            return ['success' => false, 'message' => 'Invalid email format.'];
        }

        if (strlen($password) < 6) {
            return ['success' => false, 'message' => 'Password must be at least 6 characters.'];
        }

        $password_hash = password_hash($password, PASSWORD_DEFAULT);

        try {
            $sql = "INSERT INTO users (username, email, password_hash) VALUES (:username, :email, :password_hash)";
            $stmt = $this->pdo->prepare($sql);
            $stmt->execute([
                ':username' => $username,
                ':email' => $email,
                ':password_hash' => $password_hash
            ]);

            $userId = $this->pdo->lastInsertId();

            // Process referral if provided
            if (!empty($referralCode)) {
                $referralController = new ReferralController();
                $referralResult = $referralController->processReferral($referralCode, $userId);
                if (!$referralResult['success']) {
                    // Log the error but don't fail registration
                    error_log("Referral processing failed: " . $referralResult['message']);
                }
            }

            // Generate a referral code for the new user
            $referralController = new ReferralController();
            $codeResult = $referralController->generateReferralCode($userId);
            if (!$codeResult['success']) {
                error_log("Failed to generate referral code for user $userId: " . $codeResult['message']);
            }

            return ['success' => true, 'message' => 'Registration successful. Please log in.'];
        } catch (PDOException $e) {
            if ($e->getCode() == 23000) {
                return ['success' => false, 'message' => 'Username or email already exists.'];
            }
            return ['success' => false, 'message' => 'Registration failed: ' . $e->getMessage()];
        }
    }

    public function login($username, $password) {
        if (empty($username) || empty($password)) {
            return ['success' => false, 'message' => 'Username and password are required.'];
        }

        try {
            $sql = "SELECT * FROM users WHERE username = :username";
            $stmt = $this->pdo->prepare($sql);
            $stmt->execute([':username' => $username]);
            $user = $stmt->fetch(PDO::FETCH_ASSOC);

            if ($user && password_verify($password, $user['password_hash'])) {
                if (session_status() === PHP_SESSION_NONE) {
                    session_start();
                }
                $_SESSION['user_id'] = $user['id'];
                $_SESSION['username'] = $user['username'];
                return ['success' => true, 'message' => 'Login successful.'];
            } else {
                return ['success' => false, 'message' => 'Invalid username or password.'];
            }
        } catch (PDOException $e) {
            return ['success' => false, 'message' => 'Login failed: ' . $e->getMessage()];
        }
    }

    public function logout() {
        if (session_status() === PHP_SESSION_NONE) {
            session_start();
        }
        session_unset();
        session_destroy();
        return ['success' => true, 'message' => 'Logged out successfully.'];
    }

    public function getCurrentUser() {
        if (session_status() === PHP_SESSION_NONE) {
            session_start();
        }
        if (isset($_SESSION['user_id'])) {
            return ['id' => $_SESSION['user_id'], 'username' => $_SESSION['username']];
        }
        return null;
    }
}
?>