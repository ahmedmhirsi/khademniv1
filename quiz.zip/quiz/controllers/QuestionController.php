<?php
include_once __DIR__ . '/../config.php';
include_once __DIR__ . '/../models/Question.php';

class QuestionController {
    // Define a private PDO property.
    private $pdo;

    // Initialize the PDO connection in the constructor.
    public function __construct() {
        $this->pdo = config::getConnexion();
    }

    public function listQuestions() {
        $sql = "SELECT * FROM questions";
        try {
            $stmt = $this->pdo->query($sql);
            return $stmt->fetchAll(PDO::FETCH_ASSOC);
        } catch (Exception $e) {
            die('Error: ' . $e->getMessage());
        }
    }

    // Function to delete a question by its ID.
    public function deleteQuestion($id) {
        $sql = "DELETE FROM questions WHERE id = :id";
        try {
            $stmt = $this->pdo->prepare($sql);
            $stmt->bindValue(':id', $id);
            $stmt->execute();
        } catch (Exception $e) {
            die('Error: ' . $e->getMessage());
        }
    }

    public function createQuestion(Question $question) {
        $sql = "INSERT INTO questions (quiz_id, question_text, option_a, option_b, option_c, option_d, correct_option)
                VALUES (:quiz_id, :question_text, :option_a, :option_b, :option_c, :option_d, :correct_option)";
        try {
            $stmt = $this->pdo->prepare($sql);
            $stmt->execute([
                ':quiz_id'        => $question->getQuizId(),
                ':question_text'  => $question->getQuestionText(),
                ':option_a'       => $question->getOptionA(),
                ':option_b'       => $question->getOptionB(),
                ':option_c'       => $question->getOptionC(),
                ':option_d'       => $question->getOptionD(),  // Passes null if not provided
                ':correct_option' => $question->getCorrectOption()
            ]);
        } catch (PDOException $e) {
            throw new Exception("Failed to insert question: " . $e->getMessage());
        }
    }

    // Function to update an existing question.
    // (Make sure your Question model has appropriate getters for these values.)
    public function updateQuestion(Question $question, $id) {
        $sql = "UPDATE questions SET 
                    question_text = :question_text,
                    option_a = :option_a,
                    option_b = :option_b,
                    option_c = :option_c,
                    option_d = :option_d,
                    correct_option = :correct_option
                WHERE id = :id";
        try {
            $stmt = $this->pdo->prepare($sql);
            $stmt->execute([
                ':id'              => $id,
                ':question_text'   => $question->getQuestionText(),
                ':option_a'        => $question->getOptionA(),
                ':option_b'        => $question->getOptionB(),
                ':option_c'        => $question->getOptionC(),
                ':option_d'        => $question->getOptionD(),
                ':correct_option'  => $question->getCorrectOption()
            ]);
            echo $stmt->rowCount() . " records UPDATED successfully <br>";
        } catch (PDOException $e) {
            echo "Error: " . $e->getMessage();
        }
    }

    // Function to show a specific question by its ID.
    public function showQuestion($id) {
        $sql = "SELECT * FROM questions WHERE id = :id";
        try {
            $stmt = $this->pdo->prepare($sql);
            $stmt->execute([':id' => $id]);
            return $stmt->fetch(PDO::FETCH_ASSOC);
        } catch (Exception $e) {
            die('Error: ' . $e->getMessage());
        }
    }

    // Function to list all questions by a specific quiz ID.
    public function listQuestionsByQuiz($quiz_id) {
        $sql = "SELECT * FROM questions WHERE quiz_id = :quiz_id";
        try {
            $stmt = $this->pdo->prepare($sql);
            $stmt->execute([':quiz_id' => $quiz_id]);
            return $stmt->fetchAll(PDO::FETCH_ASSOC);
        } catch (Exception $e) {
            die('Error: ' . $e->getMessage());
        }
    }
}
?>
