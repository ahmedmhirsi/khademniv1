<?php

include_once(__DIR__ . '/../config.php');
include_once(__DIR__ . '/../models/Quiz.php');

class QuizController
{
    public function listQuizzes()
    {
        $sql = "SELECT * FROM quizzes";
        $db = config::getConnexion();
        try {
            $list = $db->query($sql);
            $quizzes = $list->fetchAll(PDO::FETCH_ASSOC);
            return $quizzes;
        } catch (Exception $e) {
            die('Error: ' . $e->getMessage());
        }
    }

    function deleteQuiz($id)
    {
        $sql = "DELETE FROM quizzes WHERE id = :id";
        $db = config::getConnexion();
        $req = $db->prepare($sql);
        $req->bindValue(':id', $id);

        try {
            $req->execute();
        } catch (Exception $e) {
            die('Error: ' . $e->getMessage());
        }
    }

    function createQuiz($quiz)
    {
        $sql = "INSERT INTO quizzes (title, description) VALUES (:title, :description)";
        $db = config::getConnexion();
        try {
            $query = $db->prepare($sql);
            $query->execute([
                'title' => $quiz->getTitle(),
                'description' => $quiz->getDescription()
            ]);
        } catch (Exception $e) {
            echo 'Error: ' . $e->getMessage();
        }
    }

    function updateQuiz($quiz, $id)
    {
        try {
            $db = config::getConnexion();

            $query = $db->prepare(
                'UPDATE quizzes SET 
                    title = :title, 
                    description = :description 
                WHERE id = :id'
            );

            $query->execute([
                'id' => $id,
                'title' => $quiz->getTitle(),
                'description' => $quiz->getDescription()
            ]);

            echo $query->rowCount() . " records UPDATED successfully <br>";
        } catch (PDOException $e) {
            echo "Error: " . $e->getMessage();
        }
    }

    function showQuiz($id)
    {
        $sql = "SELECT * FROM quizzes WHERE id = :id";
        $db = config::getConnexion();
        try {
            $query = $db->prepare($sql);
            $query->execute(['id' => $id]);

            $quiz = $query->fetch();
            return $quiz;
        } catch (Exception $e) {
            die('Error: ' . $e->getMessage());
        }
    }
    function showQuizByTitle($title)
    {
        $sql = "SELECT * FROM quizzes WHERE title = :title";
        $db = config::getConnexion();
        try {
            $query = $db->prepare($sql);
            $query->execute(['title' => $title]);
            return $query->fetch(PDO::FETCH_ASSOC);
        } catch (Exception $e) {
            die('Error: ' . $e->getMessage());
        }
    }
    

}
?>
