<?php
require_once __DIR__ . '/../config.php';
require_once __DIR__ . '/../models/Score.php';
require_once __DIR__ . '/../models/Referral.php';

class ReferralController {
    private $pdo;
    private const REFERRAL_POINTS = 50; // Points awarded per successful referral
    private const CODE_LENGTH = 8; // Length of referral code

    public function __construct() {
        $this->pdo = config::getConnexion();
    }

    // Generate a unique referral code for a user
    public function generateReferralCode(int $userId): array {
        // Check if user already has a code
        $sql = "SELECT id, code FROM referral_codes WHERE user_id = :user_id AND (expires_at IS NULL OR expires_at > NOW())";
        $stmt = $this->pdo->prepare($sql);
        $stmt->execute([':user_id' => $userId]);
        $existingCode = $stmt->fetch(PDO::FETCH_ASSOC);

        if ($existingCode) {
            return ['success' => true, 'code' => $existingCode['code']];
        }

        // Generate unique code
        do {
            $code = $this->generateRandomCode(self::CODE_LENGTH);
            $sql = "SELECT id FROM referral_codes WHERE code = :code";
            $stmt = $this->pdo->prepare($sql);
            $stmt->execute([':code' => $code]);
        } while ($stmt->fetch());

        // Insert new code
        try {
            $sql = "INSERT INTO referral_codes (user_id, code) VALUES (:user_id, :code)";
            $stmt = $this->pdo->prepare($sql);
            $stmt->execute([':user_id' => $userId, ':code' => $code]);
            return ['success' => true, 'code' => $code];
        } catch (PDOException $e) {
            error_log("Failed to generate referral code for user $userId: " . $e->getMessage());
            return ['success' => false, 'message' => 'Failed to generate referral code.'];
        }
    }

    // Validate and process a referral code during registration
    public function processReferral(string $code, int $referredUserId): array {
        // Find the referral code
        $sql = "SELECT id, user_id FROM referral_codes WHERE code = :code AND (expires_at IS NULL OR expires_at > NOW())";
        $stmt = $this->pdo->prepare($sql);
        $stmt->execute([':code' => $code]);
        $referralCode = $stmt->fetch(PDO::FETCH_ASSOC);

        if (!$referralCode) {
            return ['success' => false, 'message' => 'Invalid or expired referral code.'];
        }

        $referrerUserId = $referralCode['user_id'];
        $referralCodeId = $referralCode['id'];

        // Prevent self-referral
        if ($referrerUserId === $referredUserId) {
            return ['success' => false, 'message' => 'You cannot refer yourself.'];
        }

        // Check if user was already referred
        $sql = "SELECT id FROM referrals WHERE referred_user_id = :referred_user_id";
        $stmt = $this->pdo->prepare($sql);
        $stmt->execute([':referred_user_id' => $referredUserId]);
        if ($stmt->fetch()) {
            return ['success' => false, 'message' => 'This user has already been referred.'];
        }

        // Record the referral
        try {
            $sql = "INSERT INTO referrals (referrer_user_id, referred_user_id, referral_code_id) VALUES (:referrer_user_id, :referred_user_id, :referral_code_id)";
            $stmt = $this->pdo->prepare($sql);
            $stmt->execute([
                ':referrer_user_id' => $referrerUserId,
                ':referred_user_id' => $referredUserId,
                ':referral_code_id' => $referralCodeId
            ]);

            // Award points to referrer
            $score = new Score(null, $referrerUserId, null, null, self::REFERRAL_POINTS, null, 'referral');
            $this->saveReferralPoints($score);

            return ['success' => true, 'message' => 'Referral processed successfully.'];
        } catch (PDOException $e) {
            error_log("Failed to process referral for code $code, referred_user_id $referredUserId: " . $e->getMessage());
            return ['success' => false, 'message' => 'Failed to process referral.'];
        } catch (Exception $e) {
            error_log("Error processing referral for code $code, referred_user_id $referredUserId: " . $e->getMessage());
            return ['success' => false, 'message' => 'Failed to process referral.'];
        }
    }

    // Save referral points
    private function saveReferralPoints(Score $score): void {
        $sql = "INSERT INTO scores (user_id, quiz_id, score, eco_points, type) VALUES (:user_id, :quiz_id, :score, :eco_points, :type)";
        try {
            $stmt = $this->pdo->prepare($sql);
            $stmt->execute([
                ':user_id' => $score->getUserId(),
                ':quiz_id' => $score->getQuizId(),
                ':score' => $score->getScore(),
                ':eco_points' => $score->getEcoPoints(),
                ':type' => $score->getType()
            ]);
        } catch (PDOException $e) {
            error_log("Failed to save referral points for user {$score->getUserId()}: " . $e->getMessage());
            throw new Exception("Failed to save referral points: " . $e->getMessage());
        }
    }

    // Generate a random referral code
    private function generateRandomCode(int $length): string {
        $characters = '0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZ';
        $code = '';
        for ($i = 0; $i < $length; $i++) {
            $code .= $characters[rand(0, strlen($characters) - 1)];
        }
        return $code;
    }

    // Get referral statistics for a user
    public function getReferralStats(int $userId): array {
        $sql = "SELECT 
                    (SELECT COUNT(*) FROM referrals WHERE referrer_user_id = :user_id) as referral_count,
                    (SELECT COALESCE(SUM(eco_points), 0) FROM scores WHERE user_id = :user_id AND type = 'referral') as referral_points";
        try {
            $stmt = $this->pdo->prepare($sql);
            $stmt->execute([':user_id' => $userId]);
            $result = $stmt->fetch(PDO::FETCH_ASSOC);
            return [
                'referral_count' => (int) $result['referral_count'],
                'referral_points' => (int) $result['referral_points']
            ];
        } catch (PDOException $e) {
            error_log("Failed to fetch referral stats for user $userId: " . $e->getMessage());
            return ['referral_count' => 0, 'referral_points' => 0];
        }
    }
}
?>