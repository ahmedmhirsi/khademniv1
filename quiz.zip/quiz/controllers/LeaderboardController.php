<?php
include_once __DIR__ . '/../config.php';
include_once __DIR__ . '/../models/Score.php';

class LeaderboardController {
    private $pdo;

    public function __construct() {
        $this->pdo = config::getConnexion();
    }

    public function getLeaderboard($limit = 10) {
        $sql = "
            SELECT s.user_id, u.username, SUM(s.eco_points) as total_eco_points, COUNT(s.quiz_id) as quizzes_taken
            FROM scores s
            JOIN users u ON s.user_id = u.id
            GROUP BY s.user_id, u.username
            ORDER BY total_eco_points DESC
            LIMIT :limit
        ";
        try {
            $stmt = $this->pdo->prepare($sql);
            $stmt->bindValue(':limit', $limit, PDO::PARAM_INT);
            $stmt->execute();
            return $stmt->fetchAll(PDO::FETCH_ASSOC);
        } catch (Exception $e) {
            die('Error: ' . $e->getMessage());
        }
    }

    public function saveScore(Score $score) {
        $sql = "
            INSERT INTO scores (user_id, quiz_id, score, eco_points)
            VALUES (:user_id, :quiz_id, :score, :eco_points)
        ";
        try {
            $stmt = $this->pdo->prepare($sql);
            $stmt->execute([
                ':user_id' => $score->getUserId(),
                ':quiz_id' => $score->getQuizId(),
                ':score' => $score->getScore(),
                ':eco_points' => $score->getEcoPoints()
            ]);
        } catch (PDOException $e) {
            throw new Exception("Failed to save score: " . $e->getMessage());
        }
    }
}
?>