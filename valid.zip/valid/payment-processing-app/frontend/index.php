<?php
include '../db_connect.php';
session_start();

// Vérifier si l'utilisateur est connecté
$isLoggedIn = isset($_SESSION["user"]) && isset($_SESSION["user"]["user_id"]);

if ($isLoggedIn) {
    $user_id = $_SESSION["user"]["user_id"];
    $query = "SELECT * FROM users WHERE user_id = :user_id";
    $stmt = $pdo->prepare($query);
    $stmt->execute([':user_id' => $user_id]);
    $user = $stmt->fetch(PDO::FETCH_ASSOC);
}

?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Payment Processing App</title>
    <link rel="stylesheet" href="css/styles.css">
    <script src="https://cdnjs.cloudflare.com/ajax/libs/xlsx/0.18.5/xlsx.full.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jspdf/2.4.0/jspdf.umd.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
</head>
<body>
<header>
    <div class="logo">Khademni</div>
    <nav>
        <a href="../../../index.php" class="<?php echo basename($_SERVER['PHP_SELF']) == 'index.php' ? 'active' : ''; ?>">Home</a>
        <a href="../../../offer/mvc/views/listeView.php" class="<?php echo basename($_SERVER['PHP_SELF']) == 'list_jobs.php' ? 'active' : ''; ?>">Offres d'emploi</a>
        <a href="../../../quiz/views/frontoffice/quiz_list.php" class="<?php echo basename($_SERVER['PHP_SELF']) == 'blog.php' ? 'active' : ''; ?>">Test & Quiz</a>
        <a href="../../../valid/payment-processing-app/frontend/index.php" class="<?php echo basename($_SERVER['PHP_SELF']) == 'pricing.php' ? 'active' : ''; ?>">Paiment</a>
        
        <?php if ($isLoggedIn): ?>
            <div class="profile-menu">
                <img src="../../../user/controllers/<?php echo htmlspecialchars($user['pdp'] ?? ''); ?>" alt="Profile Picture" class="profile-pic" style="width: 100px; height: auto;">
                <div class="dropdown-menu">
                    <a href="../../../user/views/layouts/main/main.php">Voir Profil</a>
                    <a href="../../../user/controllers/logout.php">Se Déconnecter</a>
                </div>
            </div>
        <?php else: ?>
            <a href="../auth/login.php" class="button">Se connecter</a>
        <?php endif; ?>
    </nav>
</header>
      <ul>
                    <li><a href="views/create-payment.html">Create Payment</a></li>
                    <li><a href="../backend/list-payments.php">List Payments</a></li>
                    <li><a href="views/edit-payment.html">Edit Payment</a></li>
                    <li><a href="views/delete-payment.html">Delete Payment</a></li>
                </ul>
    <main class="main">
        <div class="container">
            <h2>Manage Your Payments</h2>
            <p>Welcome to the Payment Processing App. Use the navigation menu above to manage your payments.</p>
            <button class="btn btn-primary btn-large" onclick="window.location.href='views/create-payment.html'">Get Started</button>
    <div class="search-container">
        <input type="text" id="searchInput" class="form-control" placeholder="Entrez l'ID du paiement">
        <button type="button" id="searchButton" class="btn btn-primary">Rechercher</button>
    </div>
</div>
            <section class="metiers">
                <h3>Our Services</h3>
                <div class="metier-list">
                    <div class="metier-card">
                        <h4>Payment Processing</h4>
                        <p>Secure and fast payment processing for your business needs.</p>
                    </div>
                    <div class="metier-card">
                        <h4>Transaction Management</h4>
                        <p>Track and manage all your transactions in one place.</p>
                    </div>
                    <div class="metier-card">
                        <h4>Financial Insights</h4>
                        <p>Get detailed insights into your financial performance.</p>
                    </div>
                    <div class="metier-card">
                        <h4>Search in Payments</h4>
                        <p>Easily search through your payment history to find specific transactions.</p>
                    </div>
                    <div class="metier-card">
                        <h4>Filter by Date or Amount</h4>
                        <p>Filter your transactions by date or amount to quickly find what you need.</p>
                    </div>
                    <div class="metier-card">
                        <h4>Export Data</h4>
                        <p>Export your payment data in various formats for reporting and analysis.</p>
                    </div>
                    <div class="metier-card">
                        <h4>Automated Billing</h4>
                        <p>Streamline your billing process with automated invoicing and payment reminders.</p>
                    </div>
                    <div class="metier-card">
                        <h4>Fraud Detection</h4>
                        <p>Protect your transactions with advanced fraud detection and prevention tools.</p>
                    </div>
                </div>
            </section>

            <section class="analytics">
                <h3>Analyse des Transactions</h3>
                <div class="analytics-container">
                    <canvas id="transactionsChart" width="400" height="200"></canvas>
                </div>
            </section>
            <section class="refunds">
                <h3>Gestion des Remboursements</h3>
                <form id="refundForm">
                    <div class="form-group">
                        <label for="paymentId">ID du Paiement</label>
                        <input type="text" id="paymentId" name="paymentId" class="form-control" placeholder="Entrez l'ID du paiement" required>
                    </div>
                    <div class="form-group">
                        <label for="reason">Raison du Remboursement</label>
                        <textarea id="reason" name="reason" class="form-control" placeholder="Expliquez la raison du remboursement" required></textarea>
                    </div>
                    <button type="submit" class="btn btn-primary">Demander un Remboursement</button>
                </form>
                <div id="refundResult" style="margin-top: 1rem;"></div>

                <h4>Suivi des Remboursements</h4>
                <table class="table">
                    <thead>
                        <tr>
                            <th>ID Paiement</th>
                            <th>Montant</th>
                            <th>Statut</th>
                            <th>Date</th>
                            <th>Raison</th>
                        </tr>
                    </thead>
                    <tbody id="refundsTable">
                        <!-- Les remboursements seront affichés ici -->
                    </tbody>
                </table>
            </section>



            <section class="export-data">
                <h3>Exportation des Données</h3>
                <form id="exportForm">
                    <div class="form-group">
                        <label for="exportFormat">Choisissez le format d'exportation :</label>
                        <select id="exportFormat" name="exportFormat" class="form-control" required>
                            <option value="csv">CSV</option>
                            <option value="excel">Excel</option>
                            <option value="pdf">PDF</option>
                        </select>
                    </div>
                    <button type="button" id="exportButton" class="btn btn-primary">Exporter</button>
                </form>
            </section>

            <section class="chatbot">
                <h3>Chatbot</h3>
                <div class="chat-container">
                    <div id="chatMessages" class="chat-messages">
                        <!-- Les messages du chatbot et de l'utilisateur apparaîtront ici -->
                    </div>
                    <div class="chat-input">
                        <input type="text" id="chatInput" class="form-control" placeholder="Posez une question...">
                        <button id="sendChat" class="btn btn-primary">Envoyer</button>
                    </div>
                </div>
            </section>
            <section class="payment-history">
    <h3>Historique des Paiements</h3>
    <table class="table">
        <thead>
            <tr>
                <th>ID</th>
                <th>Type</th>
                <th>Détails</th>
                <th>Montant (DT)</th>
                <th>Date</th>
            </tr>
        </thead>
        <tbody id="paymentHistoryTable">
            <!-- Les paiements seront affichés ici -->
        </tbody>
    </table>
</section>
    </main>
    <footer class="footer">
    <div class="container footer-content">
        <div class="footer-logo">
            <h3>Payment Processing App</h3>
            <p>&copy; 2023 Payment Processing App. All rights reserved.</p>
        </div>
        <div class="social-links">
            <a href="https://www.youtube.com" target="_blank" class="social-link" aria-label="YouTube">
                <img src="images/youtube-icon.svg" alt="YouTube">
            </a>
            <a href="https://www.facebook.com" target="_blank" class="social-link" aria-label="Facebook">
                <img src="images/facebook-icon.svg" alt="Facebook">
            </a>
            <a href="https://www.instagram.com" target="_blank" class="social-link" aria-label="Instagram">
                <img src="images/instagram-icon.svg" alt="Instagram">
            </a>
        </div>
    </div>
</footer>
    <script>
        async function exportToPDF() {
            const { jsPDF } = window.jspdf;
            const doc = new jsPDF();

            try {
                // Récupérer les données depuis l'API
                const response = await fetch('../backend/get-payments.php');
                const payments = await response.json();

                // Vérifier si une erreur est retournée par l'API
                if (payments.error) {
                    console.error("Erreur API :", payments.error);
                    alert("Erreur lors de la récupération des données : " + payments.error);
                    return;
                }

                // Ajouter un titre au PDF
                doc.setFontSize(18);
                doc.text("Liste des Paiements", 10, 10);

                // Ajouter les colonnes
                const headers = ["ID", "Type", "Détails", "Montant (DT)", "Date"];
                let y = 20; // Position verticale initiale
                doc.setFontSize(12);
                doc.text(headers.join(" | "), 10, y);
                y += 10;

                // Ajouter les lignes des paiements
                payments.forEach(payment => {
                    const row = `${payment.id} | ${payment.type} | ${payment.details} | ${payment.montant} DT | ${payment.date_paiement}`;
                    doc.text(row, 10, y);
                    y += 10;

                    // Si la page est pleine, ajouter une nouvelle page
                    if (y > 280) {
                        doc.addPage();
                        y = 10;
                    }
                });

                // Télécharger le fichier PDF
                doc.save("payments.pdf");
            } catch (error) {
                console.error("Erreur lors de l'exportation en PDF :", error);
                alert("Une erreur est survenue lors de l'exportation en PDF.");
            }
        }

        // Example data for testing
        const examplePayments = [
            {
                "id": 1,
                "type": "Carte Bancaire",
                "details": "Card: **** **** **** 1234, Name: John Doe, Exp: 12/25",
                "montant": 100,
                "date_paiement": "2023-04-01"
            },
            {
                "id": 2,
                "type": "Virement",
                "details": "Bank: BIAT, IBAN: TN5914207207100707123456, Holder: Jane Doe",
                "montant": 200,
                "date_paiement": "2023-04-05"
            }
        ];
    </script>
    <script>
        async function loadTransactionAnalytics() {
            try {
                // Récupérer les données depuis l'API
                const response = await fetch('../backend/get-payments.php');
                const payments = await response.json();

                if (payments.error) {
                    console.error("Erreur API :", payments.error);
                    alert("Erreur lors de la récupération des données : " + payments.error);
                    return;
                }

                // Préparer les données pour le graphique
                const labels = payments.map(payment => payment.date_paiement);
                const data = payments.map(payment => payment.montant);

                // Créer le graphique
                const ctx = document.getElementById('transactionsChart').getContext('2d');
                new Chart(ctx, {
                    type: 'line', // Type de graphique (ligne)
                    data: {
                        labels: labels, // Dates des paiements
                        datasets: [{
                            label: 'Montant des Transactions (DT)',
                            data: data, // Montants des paiements
                            borderColor: 'rgba(34, 197, 94, 1)', // Couleur verte
                            backgroundColor: 'rgba(34, 197, 94, 0.2)', // Couleur verte transparente
                            borderWidth: 2,
                            tension: 0.4 // Lissage des lignes
                        }]
                    },
                    options: {
                        responsive: true,
                        plugins: {
                            legend: {
                                display: true,
                                position: 'top'
                            }
                        },
                        scales: {
                            x: {
                                title: {
                                    display: true,
                                    text: 'Date'
                                }
                            },
                            y: {
                                title: {
                                    display: true,
                                    text: 'Montant (DT)'
                                },
                                beginAtZero: true
                            }
                        }
                    }
                });
            } catch (error) {
                console.error("Erreur lors du chargement des données d'analyse :", error);
                alert("Une erreur est survenue lors du chargement des données d'analyse.");
            }
        }

        // Charger l'analyse des transactions au chargement de la page
        document.addEventListener('DOMContentLoaded', loadTransactionAnalytics);
    </script>
    <script>
        document.getElementById('notificationForm').addEventListener('submit', async function (e) {
            e.preventDefault();

            const email = document.getElementById('email').value;
            const message = document.getElementById('message').value;

            try {
                const response = await fetch('../backend/send-notification.php', {
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/x-www-form-urlencoded',
                    },
                    body: `email=${encodeURIComponent(email)}&message=${encodeURIComponent(message)}`,
                });

                const result = await response.json();
                const resultDiv = document.getElementById('notificationResult');

                if (result.success) {
                    resultDiv.innerHTML = `<p style="color: green;">${result.success}</p>`;
                } else {
                    resultDiv.innerHTML = `<p style="color: red;">${result.error}</p>`;
                }
            } catch (error) {
                console.error('Erreur lors de l\'envoi de la notification :', error);
                document.getElementById('notificationResult').innerHTML = `<p style="color: red;">Une erreur est survenue.</p>`;
            }
        });
    </script>
    <script>
        document.getElementById('refundForm').addEventListener('submit', async function (e) {
            e.preventDefault();

            const paymentId = document.getElementById('paymentId').value;
            const reason = document.getElementById('reason').value;

            try {
                const response = await fetch('../backend/process-refund.php', {
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/x-www-form-urlencoded',
                    },
                    body: `paymentId=${encodeURIComponent(paymentId)}&reason=${encodeURIComponent(reason)}`,
                });

                const result = await response.json();
                const resultDiv = document.getElementById('refundResult');

                if (result.success) {
                    resultDiv.innerHTML = `<p style="color: green;">${result.success}</p>`;
                    addRefundToTable(result.refund);
                } else {
                    resultDiv.innerHTML = `<p style="color: red;">${result.error}</p>`;
                }
            } catch (error) {
                console.error('Erreur lors de la demande de remboursement :', error);
                document.getElementById('refundResult').innerHTML = `<p style="color: red;">Une erreur est survenue.</p>`;
            }
        });

        function addRefundToTable(refund) {
            const tableBody = document.getElementById('refundsTable');
            const row = `
                <tr>
                    <td>${refund.paymentId}</td>
                    <td>${refund.amount} DT</td>
                    <td>${refund.status}</td>
                    <td>${refund.date}</td>
                    <td>${refund.reason}</td>
                </tr>
            `;
            tableBody.innerHTML += row;
        }

        async function loadRefunds() {
            try {
                const response = await fetch('../backend/get-refunds.php');
                const refunds = await response.json();

                if (refunds.error) {
                    console.error("Erreur API :", refunds.error);
                    alert("Erreur lors de la récupération des remboursements : " + refunds.error);
                    return;
                }

                const tableBody = document.getElementById('refundsTable');
                tableBody.innerHTML = ""; // Vider le tableau avant d'ajouter les données

                refunds.forEach(refund => {
                    const row = `
                        <tr>
                            <td>${refund.payment_id}</td>
                            <td>${refund.montant} DT</td>
                            <td>${refund.statut}</td>
                            <td>${refund.date_remboursement}</td>
                            <td>${refund.raison}</td>
                        </tr>
                    `;
                    tableBody.innerHTML += row;
                });
            } catch (error) {
                console.error("Erreur lors du chargement des remboursements :", error);
                alert("Une erreur est survenue lors du chargement des remboursements.");
            }
        }

        // Charger les remboursements au chargement de la page
        document.addEventListener('DOMContentLoaded', loadRefunds);
    </script>
    <script>
        document.getElementById('generate2FA').addEventListener('click', async function () {
            try {
                const response = await fetch('../backend/generate-2fa.php');
                const data = await response.json();

                if (data.qrCodeUrl) {
                    document.getElementById('qrCodeContainer').innerHTML = `
                        <p>Scannez ce QR Code avec Google Authenticator :</p>
                        <img src="${data.qrCodeUrl}" alt="QR Code">
                        <p>Secret : ${data.secret}</p>
                    `;
                } else {
                    alert('Erreur lors de la génération du QR Code.');
                }
            } catch (error) {
                console.error('Erreur lors de la génération du QR Code :', error);
            }
        });
    </script>
    <script>
        document.getElementById('verify2FAForm').addEventListener('submit', async function (e) {
            e.preventDefault();

            const code = document.getElementById('code').value;
            const secret = 'VOTRE_SECRET'; // Remplacez par le secret généré ou stocké

            try {
                const response = await fetch('../backend/verify-2fa.php', {
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/x-www-form-urlencoded',
                    },
                    body: `secret=${encodeURIComponent(secret)}&code=${encodeURIComponent(code)}`,
                });

                const result = await response.json();
                const resultDiv = document.getElementById('verifyResult');

                if (result.success) {
                    resultDiv.innerHTML = `<p style="color: green;">${result.success}</p>`;
                } else {
                    resultDiv.innerHTML = `<p style="color: red;">${result.error}</p>`;
                }
            } catch (error) {
                console.error('Erreur lors de la vérification du code 2FA :', error);
                document.getElementById('verifyResult').innerHTML = `<p style="color: red;">Une erreur est survenue.</p>`;
            }
        });
    </script>
    <script>
        document.getElementById('exportButton').addEventListener('click', async function () {
            const format = document.getElementById('exportFormat').value;

            try {
                // Récupérer les données depuis le backend
                const response = await fetch('../backend/get-data.php'); // Remplacez par votre API
                const data = await response.json();

                if (format === 'csv') {
                    exportToCSV(data);
                } else if (format === 'excel') {
                    exportToExcel(data);
                } else if (format === 'pdf') {
                    exportToPDF(data);
                }
            } catch (error) {
                console.error('Erreur lors de l\'exportation des données :', error);
            }
        });

        function exportToCSV(data) {
            let csvContent = "data:text/csv;charset=utf-8,";
            csvContent += Object.keys(data[0]).join(",") + "\n"; // En-têtes
            data.forEach(row => {
                csvContent += Object.values(row).join(",") + "\n";
            });

            const encodedUri = encodeURI(csvContent);
            const link = document.createElement("a");
            link.setAttribute("href", encodedUri);
            link.setAttribute("download", "data.csv");
            document.body.appendChild(link);
            link.click();
            document.body.removeChild(link);
        }

        function exportToExcel(data) {
            const worksheet = XLSX.utils.json_to_sheet(data);
            const workbook = XLSX.utils.book_new();
            XLSX.utils.book_append_sheet(workbook, worksheet, "Données");
            XLSX.writeFile(workbook, "data.xlsx");
        }

        function exportToPDF(data) {
            const { jsPDF } = window.jspdf;
            const doc = new jsPDF();

            // Ajouter les en-têtes
            const headers = Object.keys(data[0]);
            doc.text(headers.join(" | "), 10, 10);

            // Ajouter les lignes
            let y = 20;
            data.forEach(row => {
                const values = Object.values(row).join(" | ");
                doc.text(values, 10, y);
                y += 10;
            });

            doc.save("data.pdf");
        }
    </script>
    <script>
        document.getElementById('searchButton').addEventListener('click', async function () {
            const paymentId = document.getElementById('searchInput').value.trim();

            if (!paymentId) {
                alert('Veuillez entrer un ID de paiement.');
                return;
            }

            try {
                const response = await fetch(`../backend/search-payments.php?id=${encodeURIComponent(paymentId)}`);
                const payment = await response.json();

                if (payment.error) {
                    alert(payment.error);
                } else {
                    alert(`Paiement trouvé :\nSource: ${payment.source}\nID: ${payment.id}\nMontant: ${payment.montant}\nDate: ${payment.date_paiement}\nDétails: ${payment.details}`);
                }
            } catch (error) {
                console.error('Erreur lors de la recherche du paiement :', error);
                alert('Une erreur est survenue lors de la recherche.');
            }
        });
    </script>
    <script>
        document.getElementById('sendChat').addEventListener('click', async function () {
            const chatInput = document.getElementById('chatInput').value.trim();

            if (!chatInput) {
                alert('Veuillez entrer une question.');
                return;
            }

            try {
                const response = await fetch('../backend/chatbot.php', {
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/x-www-form-urlencoded',
                    },
                    body: `question=${encodeURIComponent(chatInput)}`,
                });

                const result = await response.json();
                const chatMessages = document.getElementById('chatMessages');

                if (result.answer) {
                    chatMessages.innerHTML += `<div class="user-message">${chatInput}</div>`;
                    chatMessages.innerHTML += `<div class="bot-message">${result.answer}</div>`;
                } else {
                    chatMessages.innerHTML += `<div class="user-message">${chatInput}</div>`;
                    chatMessages.innerHTML += `<div class="bot-message">Désolé, je n'ai pas compris votre question.</div>`;
                }

                document.getElementById('chatInput').value = '';
            } catch (error) {
                console.error('Erreur lors de l\'envoi de la question au chatbot :', error);
                alert('Une erreur est survenue lors de l\'envoi de la question.');
            }
        });
    </script>
    <script>
    const chatMessages = document.getElementById('chatMessages');
    const chatInput = document.getElementById('chatInput');
    const sendChat = document.getElementById('sendChat');

    // Fonction pour ajouter un message au chat
    function addMessage(sender, message) {
        const chatMessages = document.getElementById('chatMessages');

        // Créer un nouvel élément pour le message
        const messageElement = document.createElement('div');
        messageElement.classList.add(sender === 'user' ? 'user-message' : 'bot-message');
        messageElement.textContent = message;

        // Ajouter le message au conteneur
        chatMessages.appendChild(messageElement);

        // Faire défiler vers le bas
        chatMessages.scrollTop = chatMessages.scrollHeight;
    }

    // Gérer l'envoi des messages
    sendChat.addEventListener('click', async () => {
        const userMessage = chatInput.value.trim();
        if (userMessage) {
            addMessage('user', userMessage); // Ajouter le message de l'utilisateur
            chatInput.value = '';

            try {
                // Envoyer la question au backend
                const response = await fetch('../backend/chatbot.php', {
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/x-www-form-urlencoded',
                    },
                    body: `question=${encodeURIComponent(userMessage)}`,
                });

                const result = await response.json();
                addMessage('bot', result.answer); // Ajouter la réponse du chatbot
            } catch (error) {
                console.error('Erreur lors de l\'envoi de la question au chatbot :', error);
                addMessage('bot', "Une erreur est survenue. Veuillez réessayer.");
            }
        }
    });

    // Permettre d'envoyer un message avec la touche "Entrée"
    chatInput.addEventListener('keypress', (e) => {
        if (e.key === 'Enter') {
            sendChat.click();
        }
    });
</script>
<script>
    async function loadPaymentHistory() {
        try {
            // Récupérer les paiements depuis le backend
            const response = await fetch('../backend/get-payments.php');
            const payments = await response.json();

            if (payments.error) {
                console.error("Erreur API :", payments.error);
                alert("Erreur lors de la récupération des paiements : " + payments.error);
                return;
            }

            // Afficher les paiements dans le tableau
            const tableBody = document.getElementById('paymentHistoryTable');
            tableBody.innerHTML = ""; // Vider le tableau avant d'ajouter les données

            payments.forEach(payment => {
                const row = `
                    <tr>
                        <td>${payment.id}</td>
                        <td>${payment.type}</td>
                        <td>${payment.details}</td>
                        <td>${payment.montant} DT</td>
                        <td>${payment.date_paiement}</td>
                    </tr>
                `;
                tableBody.innerHTML += row;
            });
        } catch (error) {
            console.error("Erreur lors du chargement de l'historique des paiements :", error);
            alert("Une erreur est survenue lors du chargement de l'historique des paiements.");
        }
    }

    // Charger l'historique des paiements au chargement de la page
    document.addEventListener('DOMContentLoaded', loadPaymentHistory);
</script>
</body>
</html>