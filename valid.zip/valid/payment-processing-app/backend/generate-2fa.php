<?php
// filepath: c:\xampp\htdocs\valid\payment-processing-app\backend\get-refunds.php

header('Content-Type: application/json');

try {
    // Connexion à la base de données
    $pdo = new PDO('mysql:host=localhost;dbname=khademni', 'root', '');
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

    // Requête pour récupérer les remboursements
    $query = "SELECT payment_id, montant, statut, date_remboursement, raison FROM remboursements ORDER BY date_remboursement DESC";
    $stmt = $pdo->query($query);

    // Renvoyer les données sous forme de JSON
    $refunds = $stmt->fetchAll(PDO::FETCH_ASSOC);
    echo json_encode($refunds);
} catch (PDOException $e) {
    echo json_encode(['error' => $e->getMessage()]);
}
```

require 'vendor/autoload.php'; // Assurez-vous que la bibliothèque PHPGangsta/GoogleAuthenticator est installée

use PHPGangsta_GoogleAuthenticator;

header('Content-Type: application/json');

file_put_contents('log.txt', "Génération du QR Code demandée\n", FILE_APPEND);

try {
    // Initialiser Google Authenticator
    $gAuth = new PHPGangsta_GoogleAuthenticator();

    // Générer un secret unique pour l'utilisateur
    $secret = $gAuth->createSecret();

    // Générer l'URL du QR Code pour Google Authenticator
    $qrCodeUrl = $gAuth->getQRCodeGoogleUrl('PaymentProcessingApp', $secret);

    file_put_contents('log.txt', "QR Code généré : $qrCodeUrl\n", FILE_APPEND);

    // Retourner le secret et l'URL du QR Code sous forme de JSON
    echo json_encode([
        'secret' => $secret,
        'qrCodeUrl' => $qrCodeUrl
    ]);
} catch (Exception $e) {
    // Gérer les erreurs
    file_put_contents('log.txt', "Erreur : " . $e->getMessage() . "\n", FILE_APPEND);
    echo json_encode(['error' => $e->getMessage()]);
}
```

