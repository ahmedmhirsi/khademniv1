<?php
// filepath: c:\xampp\htdocs\valid\payment-processing-app\backend\save-payment.php

function encryptData($data, $key) {
    $iv = openssl_random_pseudo_bytes(openssl_cipher_iv_length('aes-256-cbc'));
    $encrypted = openssl_encrypt($data, 'aes-256-cbc', $key, 0, $iv);
    return base64_encode($encrypted . '::' . $iv);
}

function decryptData($data, $key) {
    list($encryptedData, $iv) = explode('::', base64_decode($data), 2);
    return openssl_decrypt($encryptedData, 'aes-256-cbc', $key, 0, $iv);
}

// Exemple d'utilisation
$key = 'votre_cle_secrete';
$numeroCarte = '1234567812345678';

$chiffre = encryptData($numeroCarte, $key);
// Enregistrez $chiffre dans la base de données

$dechiffre = decryptData($chiffre, $key);
// Utilisez $dechiffre pour afficher ou traiter les données