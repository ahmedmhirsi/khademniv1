<?php
// filepath: c:\xampp\htdocs\valid\payment-processing-app\backend\save_paiement.php

// Database connection
try {
    $pdo = new PDO('mysql:host=localhost;dbname=khademni', 'root', '');
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION); // Fixed: Added missing closing parenthesis
} catch (PDOException $e) {
    die("Database connection failed: " . $e->getMessage());
}

// Get form data
$type = $_POST['type'] ?? '';
$user_id = $_POST['user_id'] ?? '';
$montant = $_POST['montant'] ?? '';

if ($type === 'carte') {
    // Card payment fields
    $nom_sur_carte = $_POST['nom_sur_carte'] ?? '';
    $numero_masque = $_POST['numero_masque'] ?? '';
    $type_carte = $_POST['type_carte'] ?? '';
    $date_expiration = $_POST['date_expiration'] ?? '';

    // Insert into `paiement_bancaire`
    $stmt = $pdo->prepare("INSERT INTO paiement_bancaire (
        type, type_carte, numero_masque, nom_sur_carte, date_expiration, montant, user_id, date_paiement
    ) VALUES (
        'carte', :type_carte, :numero_masque, :nom_sur_carte, :date_expiration, :montant, :user_id, NOW()
    )");

    $stmt->execute([
        ':type_carte' => $type_carte,
        ':numero_masque' => $numero_masque,
        ':nom_sur_carte' => $nom_sur_carte,
        ':date_expiration' => $date_expiration,
        ':montant' => $montant,
        ':user_id' => $user_id
    ]);
} elseif ($type === 'virement') {
    // Bank transfer fields
    $nom_banque = $_POST['nom_banque'] ?? '';
    $iban = $_POST['iban'] ?? '';
    $nom_titulaire = $_POST['nom_titulaire'] ?? '';
    $preuve_virement = $_POST['preuve_virement'] ?? '';

    // Insert into `paiement_virement`
    $stmt = $pdo->prepare("INSERT INTO paiement_virement (
        type, nom_banque, iban, nom_titulaire, montant, user_id, date_paiement
    ) VALUES (
        'virement', :nom_banque, :iban, :nom_titulaire, :montant, :user_id, NOW()
    )");

    $stmt->execute([
        ':nom_banque' => $nom_banque,
        ':iban' => $iban,
        ':nom_titulaire' => $nom_titulaire,
        ':montant' => $montant,
        ':user_id' => $user_id
    ]);
}
header("Location: list-payments.php?notif=ajout");
exit();

// Redirect or display success message
header("Location: /backend/models/list-payments.php");
exit;
?>
