<?php
// filepath: c:\xampp\htdocs\valid\payment-processing-app\backend\send-notification.php

header('Content-Type: application/json');

// Vérifier si les données nécessaires sont envoyées
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $email = $_POST['email'] ?? null;
    $message = $_POST['message'] ?? null;

    if (!$email || !$message) {
        echo json_encode(['error' => 'Email et message sont requis.']);
        exit;
    }

    // Simuler l'envoi d'un email (vous pouvez utiliser une vraie bibliothèque comme PHPMailer)
    $subject = "Notification de Paiement";
    $headers = "From: no-reply@payment-app.com";

    file_put_contents('log.txt', json_encode($_POST) . PHP_EOL, FILE_APPEND);

    if (mail($email, $subject, $message, $headers)) {
        echo json_encode(['success' => 'Notification envoyée avec succès.']);
    } else {
        file_put_contents('log.txt', 'Erreur lors de l\'envoi de l\'email' . PHP_EOL, FILE_APPEND);
        echo json_encode(['error' => 'Échec de l\'envoi de la notification.']);
    }
} else {
    echo json_encode(['error' => 'Méthode non autorisée.']);
}