<?php
// filepath: c:\xampp\htdocs\valid\payment-processing-app\backend\chatbot.php

header('Content-Type: application/json');
require_once 'functions.php'; // Inclure les fonctions communes

try {
    // Connexion à la base de données
    $pdo = new PDO('mysql:host=localhost;dbname=khademni', 'root', '');
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

    // Récupérer la question de l'utilisateur
    $question = strtolower(trim($_POST['question'] ?? ''));

    // Vérifier si la commande est une demande d'ajout de paiement par carte
    if (strpos($question, 'ajouter paiement carte') !== false) {
        preg_match('/ajouter paiement carte montant (\d+\.?\d*) type_carte (.+) numero (.+) nom (.+) expiration (.+) user (\d+)/', $question, $matches);

        if (count($matches) === 7) {
            $montant = $matches[1];
            $type_carte = $matches[2];
            $numero_masque = $matches[3];
            $nom_sur_carte = $matches[4];
            $date_expiration = $matches[5];
            $user_id = $matches[6];

            // Appeler la fonction pour ajouter le paiement par carte
            $result = addPayment($pdo, $montant, $type_carte, $numero_masque, $nom_sur_carte, $date_expiration, $user_id);
            echo json_encode(["answer" => $result]);
        } else {
            echo json_encode(["answer" => "Format incorrect. Utilisez : 'ajouter paiement carte montant [montant] type_carte [type_carte] numero [numero] nom [nom] expiration [expiration] user [user_id]'."]);
        }
        exit;
    }

    // Vérifier si la commande est une demande d'ajout de paiement par virement
    if (strpos($question, 'ajouter paiement virement') !== false) {
        preg_match('/ajouter paiement virement banque (.+) iban (.+) titulaire (.+) montant (\d+\.?\d*) user (\d+)/', $question, $matches);

        if (count($matches) === 6) {
            $nom_banque = $matches[1];
            $iban = $matches[2];
            $nom_titulaire = $matches[3];
            $montant = $matches[4];
            $user_id = $matches[5];

            // Appeler la fonction pour ajouter le paiement par virement
            $result = addVirement($pdo, $nom_banque, $iban, $nom_titulaire, $montant, $user_id);
            echo json_encode(["answer" => $result]);
        } else {
            echo json_encode(["answer" => "Format incorrect. Utilisez : 'ajouter paiement virement banque [banque] iban [iban] titulaire [titulaire] montant [montant] user [user_id]'."]);
        }
        exit;
    }

    // Rechercher la réponse dans la base de données
    $stmt = $pdo->prepare("SELECT response FROM chatbot_responses WHERE question = :question LIMIT 1");
    $stmt->execute(['question' => $question]);
    $response = $stmt->fetchColumn();

    if ($response) {
        // Retourner la réponse trouvée
        echo json_encode(["answer" => $response]);
    } else {
        // Réponse par défaut si aucune correspondance n'est trouvée
        echo json_encode(["answer" => "Je suis désolé, je ne comprends pas votre question. Pouvez-vous reformuler ?"]);
    }
    exit;
} catch (PDOException $e) {
    echo json_encode(["error" => "Erreur de connexion à la base de données : " . $e->getMessage()]);
}