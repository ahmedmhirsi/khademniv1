<!-- filepath: c:\xampp\htdocs\valid\payment-processing-app\frontend\views\list-payments.php -->
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>List Payments</title>
    <style>
        /* Styles généraux */
        body {
            font-family: 'Arial', sans-serif;
            background-color: #ffffff; /* Blanc */
            margin: 0;
            padding: 0;
            color: #333;
        }

        .container {
            max-width: 1200px;
            margin: 2rem auto;
            padding: 1.5rem;
            background-color: #ffffff; /* Blanc */
            border-radius: 10px;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
            border: 2px solid #28a745; /* Vert */
        }

        h1 {
            text-align: center;
            color: #28a745; /* Vert */
            margin-bottom: 1.5rem;
        }

        /* Table Styles */
        table {
            width: 100%;
            border-collapse: collapse;
            margin-bottom: 1.5rem;
        }

        table th,
        table td {
            border: 1px solid #28a745; /* Vert */
            padding: 0.8rem;
            text-align: left;
        }

        table th {
            background-color: #28a745; /* Vert */
            color: #ffffff; /* Blanc */
            font-weight: bold;
        }

        table tr:nth-child(even) {
            background-color: #f9f9f9; /* Blanc cassé */
        }

        table tr:hover {
            background-color: #e8f5e9; /* Vert clair */
        }

        table td a {
            color: #28a745; /* Vert */
            text-decoration: none;
            font-weight: bold;
        }

        table td a:hover {
            text-decoration: underline;
        }

        /* Button Styles */
        button {
            padding: 0.8rem 1.5rem;
            font-size: 1rem;
            font-weight: bold;
            color: #ffffff; /* Blanc */
            background-color: #28a745; /* Vert */
            border: none;
            border-radius: 5px;
            cursor: pointer;
            transition: background-color 0.3s;
        }

        button:hover {
            background-color: #218838; /* Vert foncé */
        }

        button#createPaymentBtn {
            display: block;
            margin: 0 auto;
        }
    </style>
</head>
<body>
    <div class="container">
        <h1>Payments List</h1>
        <table id="paymentsTable">
            <thead>
                <tr>
                    <th>ID</th>
                    <th>Type</th>
                    <th>Details</th>
                    <th>Amount</th>
                    <th>Date of Payment</th>
                    <th>Actions</th>
                </tr>
            </thead>
            <tbody>
                <?php
                // Database connection
                try {
                    $pdo = new PDO('mysql:host=localhost;dbname=khademni', 'root', '');
                    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
                } catch (PDOException $e) {
                    die("Database connection failed: " . $e->getMessage());
                }

                // Fetch payments from both tables
                $query = "
                    SELECT id, 'Carte Bancaire' AS type, CONCAT('Card: ', numero_masque, ', Name: ', nom_sur_carte, ', Exp: ', date_expiration) AS details, montant, date_paiement
                    FROM paiement_bancaire
                    UNION ALL
                    SELECT id, 'Virement' AS type, CONCAT('Bank: ', nom_banque, ', IBAN: ', iban, ', Holder: ', nom_titulaire) AS details, montant, date_paiement
                    FROM paiement_virement
                    ORDER BY date_paiement DESC
                ";
                $stmt = $pdo->query($query);

                // Display payments
                while ($row = $stmt->fetch(PDO::FETCH_ASSOC)) {
                    echo "<tr>";
                    echo "<td>{$row['id']}</td>";
                    echo "<td>{$row['type']}</td>";
                    echo "<td>{$row['details']}</td>";
                    echo "<td>{$row['montant']} DT</td>";
                    echo "<td>{$row['date_paiement']}</td>";
                    echo "<td>
                            <a href='../frontend/views/edit-payment.html?id={$row['id']}&type={$row['type']}'>Edit</a> |
                            <a href='../frontend/views/delete-payment.html?id={$row['id']}&type={$row['type']}' onclick='return confirm(\"Are you sure you want to delete this payment?\")'>Delete</a>
                          </td>";
                    echo "</tr>";
                }
                ?>
            </tbody>
        </table>
        <button id="createPaymentBtn" onclick="window.location.href='../frontend/views/create-payment.html'">Create New Payment</button>
    </div>
    <script>
    document.addEventListener('DOMContentLoaded', function () {
        const table = document.getElementById('paymentsTable');
        const headers = table.querySelectorAll('th');
        let sortDirection = true;

        headers.forEach((header, index) => {
            header.style.cursor = 'pointer';
            header.addEventListener('click', () => {
                sortTableByColumn(table, index, sortDirection);
                sortDirection = !sortDirection;
            });
        });

        function sortTableByColumn(table, column, asc = true) {
            const dirModifier = asc ? 1 : -1;
            const tBody = table.tBodies[0];
            const rows = Array.from(tBody.querySelectorAll('tr'));

            const sortedRows = rows.sort((a, b) => {
                const aText = a.children[column].textContent.trim();
                const bText = b.children[column].textContent.trim();

                const aNum = parseFloat(aText.replace(/[^0-9.-]+/g,""));
                const bNum = parseFloat(bText.replace(/[^0-9.-]+/g,""));
                
                // If both values are numeric, sort as numbers
                if (!isNaN(aNum) && !isNaN(bNum)) {
                    return (aNum - bNum) * dirModifier;
                }

                return aText.localeCompare(bText) * dirModifier;
            });

            // Remove all existing rows from the table
            while (tBody.firstChild) {
                tBody.removeChild(tBody.firstChild);
            }

            // Re-add the newly sorted rows
            tBody.append(...sortedRows);
        }
    });
</script>

</body>
</html>