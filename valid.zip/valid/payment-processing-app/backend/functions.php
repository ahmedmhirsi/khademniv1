<?php
// filepath: c:\xampp\htdocs\valid\payment-processing-app\backend\functions.php

function addPayment($pdo, $montant, $type_carte, $numero_masque, $nom_sur_carte, $date_expiration, $user_id) {
    try {
        // Insérer le paiement dans la table paiement_bancaire
        $stmt = $pdo->prepare("
            INSERT INTO paiement_bancaire (type, type_carte, numero_masque, nom_sur_carte, date_expiration, montant, user_id, date_paiement) 
            VALUES ('carte', :type_carte, :numero_masque, :nom_sur_carte, :date_expiration, :montant, :user_id, NOW())
        ");
        $stmt->execute([
            'type_carte' => $type_carte,
            'numero_masque' => $numero_masque,
            'nom_sur_carte' => $nom_sur_carte,
            'date_expiration' => $date_expiration,
            'montant' => $montant,
            'user_id' => $user_id,
        ]);
        return "Paiement par carte ajouté avec succès !";
    } catch (PDOException $e) {
        return "Erreur lors de l'ajout du paiement : " . $e->getMessage();
    }
}

function addVirement($pdo, $nom_banque, $iban, $nom_titulaire, $montant, $user_id) {
    try {
        // Insérer le paiement dans la table paiement_virement
        $stmt = $pdo->prepare("
            INSERT INTO paiement_virement (type, nom_banque, iban, nom_titulaire, montant, user_id, date_paiement) 
            VALUES ('virement', :nom_banque, :iban, :nom_titulaire, :montant, :user_id, NOW())
        ");
        $stmt->execute([
            'nom_banque' => $nom_banque,
            'iban' => $iban,
            'nom_titulaire' => $nom_titulaire,
            'montant' => $montant,
            'user_id' => $user_id,
        ]);
        return "Paiement par virement ajouté avec succès !";
    } catch (PDOException $e) {
        return "Erreur lors de l'ajout du virement : " . $e->getMessage();
    }
}