<?php
// filepath: c:\xampp\htdocs\valid\payment-processing-app\backend\process-refund.php

header('Content-Type: application/json');

try {
    // Connexion à la base de données
    $pdo = new PDO('mysql:host=localhost;dbname=khademni', 'root', '');
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

    if ($_SERVER['REQUEST_METHOD'] === 'POST') {
        $paymentId = $_POST['paymentId'] ?? null;
        $reason = $_POST['reason'] ?? null;

        if (!$paymentId || !$reason) {
            echo json_encode(['error' => 'ID du paiement et raison sont requis.']);
            exit;
        }

        // Insérer la demande de remboursement dans la base de données
        $stmt = $pdo->prepare("INSERT INTO remboursements (payment_id, montant, statut, date_remboursement, raison) VALUES (?, ?, ?, ?, ?)");
        $montant = 100.00; // Exemple de montant fictif
        $statut = 'En cours';
        $date = date('Y-m-d H:i:s');
        $stmt->execute([$paymentId, $montant, $statut, $date, $reason]);

        echo json_encode([
            'success' => 'Remboursement demandé avec succès.',
            'refund' => [
                'paymentId' => $paymentId,
                'amount' => $montant,
                'status' => $statut,
                'date' => $date,
                'reason' => $reason
            ]
        ]);
    } else {
        echo json_encode(['error' => 'Méthode non autorisée.']);
    }
} catch (PDOException $e) {
    echo json_encode(['error' => $e->getMessage()]);
}