<?php
// filepath: c:\xampp\htdocs\valid\payment-processing-app\backend\verify-2fa.php

require 'vendor/autoload.php';

use PHPGangsta_GoogleAuthenticator;

header('Content-Type: application/json');

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $secret = $_POST['secret'] ?? null;
    $code = $_POST['code'] ?? null;

    if (!$secret || !$code) {
        echo json_encode(['error' => 'Le secret et le code sont requis.']);
        exit;
    }

    $gAuth = new PHPGangsta_GoogleAuthenticator();
    $checkResult = $gAuth->verifyCode($secret, $code, 2); // 2 = tolérance de 2 minutes

    if ($checkResult) {
        echo json_encode(['success' => 'Code valide.']);
    } else {
        echo json_encode(['error' => 'Code invalide.']);
    }
} else {
    echo json_encode(['error' => 'Méthode non autorisée.']);
}