<?php
// filepath: c:\xampp\htdocs\valid\payment-processing-app\backend\get-refunds.php

header('Content-Type: application/json');

try {
    // Connexion à la base de données
    $pdo = new PDO('mysql:host=localhost;dbname=khademni', 'root', '');
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

    // Requête pour récupérer les remboursements
    $query = "SELECT payment_id, montant, statut, date_remboursement, raison FROM remboursements ORDER BY date_remboursement DESC";
    $stmt = $pdo->query($query);

    // Renvoyer les données sous forme de JSON
    $refunds = $stmt->fetchAll(PDO::FETCH_ASSOC);
    echo json_encode($refunds);
} catch (PDOException $e) {
    echo json_encode(['error' => $e->getMessage()]);
}