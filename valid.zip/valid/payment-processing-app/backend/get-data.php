<?php
// filepath: c:\xampp\htdocs\valid\payment-processing-app\backend\get-data.php

header('Content-Type: application/json');

try {
    // Connexion à la base de données
    $pdo = new PDO('mysql:host=localhost;dbname=khademni', 'root', '');
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

    // Requête pour récupérer les données
    $query = "SELECT * FROM remboursements"; // Remplacez par votre table
    $stmt = $pdo->query($query);

    // Renvoyer les données sous forme de JSON
    $data = $stmt->fetchAll(PDO::FETCH_ASSOC);
    echo json_encode($data);
} catch (PDOException $e) {
    echo json_encode(['error' => $e->getMessage()]);
}