<?php
// filepath: c:\xampp\htdocs\valid\payment-processing-app\backend\search-payments.php

header('Content-Type: application/json');

try {
    // Connexion à la base de données
    $pdo = new PDO('mysql:host=localhost;dbname=khademni', 'root', '');
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

    // Récupérer l'ID du paiement
    $paymentId = $_GET['id'] ?? null;

    if (!$paymentId) {
        echo json_encode(['error' => 'L\'ID du paiement est requis.']);
        exit;
    }

    // Rechercher dans la table paiement_bancaire
    $stmt = $pdo->prepare("
        SELECT id, montant, CONCAT('Carte: ', type_carte, ', Numéro: ', numero_masque) AS details 
        FROM paiement_bancaire 
        WHERE id = :id
    ");
    $stmt->execute(['id' => $paymentId]);
    $result = $stmt->fetch(PDO::FETCH_ASSOC);

    // Si aucun résultat, rechercher dans la table paiement_virement
    if (!$result) {
        $stmt = $pdo->prepare("SELECT 'paiement_virement' AS source, id, montant, date_paiement, commentaire AS details FROM paiement_virement WHERE id = :id");
        $stmt->execute(['id' => $paymentId]);
        $result = $stmt->fetch(PDO::FETCH_ASSOC);
    }

    // Si aucun résultat trouvé
    if ($result) {
        echo json_encode($result);
    } else {
        echo json_encode(['error' => 'Aucun paiement trouvé avec cet ID.']);
    }
} catch (PDOException $e) {
    echo json_encode(['error' => $e->getMessage()]);
}