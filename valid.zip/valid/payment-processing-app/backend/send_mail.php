<?php
// Inclusion manuelle
require '../frontend/views/src/Exception.php';
require '../frontend/views/src/PHPMailer.php';
require '../frontend/views/src/SMTP.php';

use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;

// Initialiser PHPMailer
$mail = new PHPMailer(true);

try {
    // Config SMTP
    $mail->isSMTP();
    $mail->Host       = 'smtp.gmail.com';
    $mail->SMTPAuth   = true;
    $mail->Username   = 'lappestoryaziz@gmail.com';
    $mail->Password   = 'njwdxmclixcylofc';
    $mail->SMTPSecure = PHPMailer::ENCRYPTION_STARTTLS;
    $mail->Port       = 587;

    // Email info
    $mail->setFrom('lappestoryaziz@gmail.com', 'Ahmed');
    $mail->addAddress('ahmedmhirsi955@gmail.com', 'Destinataire');

    $mail->isHTML(true);
    $mail->Subject = 'Sujet Test';
    $mail->Body    = 'paiment avec succes !';

    $mail->send();
    echo 'Message envoyé avec succès.';
} catch (Exception $e) {
    echo "Erreur : {$mail->ErrorInfo}";
}
?>
