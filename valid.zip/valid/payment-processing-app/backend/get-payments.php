<?php
// filepath: c:\xampp\htdocs\valid\payment-processing-app\backend\get-payments.php

header('Content-Type: application/json');

try {
    // Connexion à la base de données
    $pdo = new PDO('mysql:host=localhost;dbname=khademni', 'root', '');
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

    // Récupérer les paiements
    $stmt = $pdo->query("
        SELECT id, 'Carte Bancaire' AS type, CONCAT('Carte: ', type_carte, ', Numéro: ', numero_masque) AS details, montant, date_paiement
        FROM paiement_bancaire
        UNION
        SELECT id, 'Virement' AS type, CONCAT('Banque: ', nom_banque, ', IBAN: ', iban) AS details, montant, date_paiement
        FROM paiement_virement
        ORDER BY date_paiement DESC
    ");

    $payments = $stmt->fetchAll(PDO::FETCH_ASSOC);

    echo json_encode($payments);
} catch (PDOException $e) {
    echo json_encode(['error' => 'Erreur de connexion à la base de données : ' . $e->getMessage()]);
}