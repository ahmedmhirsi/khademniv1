<?php include '../../controllers/offre_emploi/add_job_controller.php'; ?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="../../assets/css/forms.css">
                <link href="../../../iconn.png" rel="icon">

    <title>Ajouter une offre d'emploi</title>
</head>
<body>
<header>
            <div class="logo">Khademni</div>
            <nav>
                <a href="../../../index.php" class="<?php echo basename($_SERVER['PHP_SELF']) == 'index.php' ? 'active' : ''; ?>">Home</a>
            <a href="../../../offer/mvc/views/listeView.php" class="<?php echo basename($_SERVER['PHP_SELF']) == 'list_jobs.php' ? 'active' : ''; ?>">Offres d'emploi</a>
                <a href="../../../quiz/views/frontoffice/quiz_list.php" class="<?php echo basename($_SERVER['PHP_SELF']) == 'blog.php' ? 'active' : ''; ?>">Test & Quiz</a>
                <a href="../../../valid/payment-processing-app/frontend/index.php" class="<?php echo basename($_SERVER['PHP_SELF']) == 'pricing.php' ? 'active' : ''; ?>">Paiment</a>
        
                <?php if (isset($user['nom_utilisateur'])): ?>
                    <div class="profile-menu">
                    <img src="../../../user/controllers/<?php echo htmlspecialchars($user['pdp'] ?? ''); ?>" alt="Profile Picture" class="profile-pic" style="width: 100px; height: auto;">
                <div class="dropdown-menu">
                    <a href="../index.php">Voir Profil</a>
                    <a href="../logout.php">Se Déconnecter</a>
                </div>
            </div>
                <?php else: ?>
                    <a href="login.php" class="button">Se connecter</a>
                <?php endif; ?>
            </nav>
        </header>

    <main>
        <h2>Ajouter une offre d'emploi</h2>
        <form action="add_job_view.php" method="post" id="jobForm">
            <fieldset>
                <legend>Informations sur l’offre d’emploi</legend>
                <label for="titre">Titre de l'offre :</label>
                <input type="text" id="titre" name="titre" required><br>
                <label for="description">Description :</label>
                <textarea id="description" name="description" required></textarea><br>
                <label for="competences">Compétences requises :</label>
                <input type="text" id="competences" name="competences" required><br>
                <label for="experience">Niveau d’expérience :</label>
                <select id="experience" name="experience" required>
                    <option value="Débutant">Débutant</option>
                    <option value="Junior">Junior</option>
                    <option value="Senior">Senior</option>
                </select><br>
                <label for="contrat">Type de contrat :</label>
                <select id="contrat" name="contrat" required>
                    <option value="CDI">CDI</option>
                    <option value="CDD">CDD</option>
                    <option value="Stage">Stage</option>
                    <option value="Freelance">Freelance</option>
                </select><br>
                <label for="salaire">Salaire proposé (optionnel) :</label>
                <input type="text" id="salaire" name="salaire"><br>
                <label for="date_limite">Date limite de candidature :</label>
                <input type="date" id="date_limite" name="date_limite" required><br>
                <center><button type="button" onclick="nextFieldset()">Suivant</button></center>
            </fieldset>

            <fieldset style="display:none;">
                <legend>Informations sur l’entreprise</legend>
                <label for="entreprise">Entreprise :</label>
                <input type="text" id="entreprise" name="nom_entreprise" required><br>
                <label for="secteur">Secteur d’activité :</label>
                <input type="text" id="secteur" name="secteur" required><br>
                <label for="adresse">Adresse de l’entreprise :</label>
                <input type="text" id="adresse" name="adresse" required><br>
                <label for="email_contact">Email de contact :</label>
                <input type="email" id="email_contact" name="email_contact" required><br>
                <label for="telephone">Numéro de téléphone :</label>
                <input type="tel" id="telephone" name="telephone" required><br>
                <label for="site_web">Site web de l’entreprise (optionnel) :</label>
                <input type="url" id="site_web" name="site_web"><br>
                <button type="button" onclick="prevFieldset()">Précédent</button>
                <center><button type="button" onclick="nextFieldset()">Suivant</button></center>
            </fieldset>

            <fieldset style="display:none;">
                <legend>Informations supplémentaires</legend>
                <label for="lieu_travail">Lieu de travail :</label>
                <select id="lieu_travail" name="lieu_travail" required>
                    <option value="Télétravail">Télétravail</option>
                    <option value="Présentiel">Présentiel</option>
                    <option value="Hybride">Hybride</option>
                </select><br>
                <label for="horaires">Horaires de travail :</label>
                <select id="horaires" name="horaires" required>
                    <option value="Temps plein">Temps plein</option>
                    <option value="Temps partiel">Temps partiel</option>
                </select><br>
                <label for="nombre_postes">Nombre de postes disponibles :</label>
                <input type="number" id="nombre_postes" name="nombre_postes" required><br>
                <label for="documents">Documents à fournir :</label><br>
                <div class="checkbox-group">
                    <div class="checkbox-item">
                        <label for="cv">CV (Curriculum Vitae)</label>
                        <input type="checkbox" id="cv" name="documents[]" value="CV"><br>
                    </div>
                    <div class="checkbox-item">
                        <label for="lettre_motivation">Lettre de motivation</label>
                        <input type="checkbox" id="lettre_motivation" name="documents[]" value="Lettre de motivation"><br>
                    </div>
                    <div class="checkbox-item">
                        <label for="portfolio">Portfolio</label>
                        <input type="checkbox" id="portfolio" name="documents[]" value="Portfolio"><br>
                    </div>
                    <div class="checkbox-item">
                        <label for="certificats">Certificats ou diplômes</label>
                        <input type="checkbox" id="certificats" name="documents[]" value="Certificats ou diplômes"><br>
                    </div>
                    <div class="checkbox-item">
                        <label for="identite">Carte d’identité ou passeport</label>
                        <input type="checkbox" id="identite" name="documents[]" value="Carte d’identité ou passeport"><br>
                    </div>
                    <div class="checkbox-item">
                        <label for="autres">Autres justificatifs</label>
                        <input type="checkbox" id="autres" name="documents[]" value="Autres justificatifs"><br>
                    </div>
                </div>
                <button type="button" onclick="prevFieldset()">Précédent</button>
                <center><button type="submit" class="center-button">Publier</button></center>
            </fieldset>
        </form>
    </main>

    <footer>
        <p>Contactez-nous : contact@jobfinder.com</p>
        <p><a href="about.html">À propos</a> | <a href="privacy.html">Politique de confidentialité</a></p>
    </footer>

    <script src="../../assets/js/form.js"></script>
    </body>
    </html>