<?php include '../../controllers/offre_emploi/list_jobs_controller.php'; ?>


<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="../../assets/css/styles.css">
    <link href="../../../iconn.png" rel="icon">
    <title>Liste des offres d'emploi</title>
</head>
<body>
<header>
            <div class="logo">Khademni</div>
            <nav>
            <a href="../../../index.php" class="<?php echo basename($_SERVER['PHP_SELF']) == 'index.php' ? 'active' : ''; ?>">Home</a>
            <a href="../../../offer/mvc/views/listeView.php" class="<?php echo basename($_SERVER['PHP_SELF']) == 'list_jobs.php' ? 'active' : ''; ?>">Offres d'emploi</a>
                <a href="../../../quiz/views/frontoffice/quiz_list.php" class="<?php echo basename($_SERVER['PHP_SELF']) == 'blog.php' ? 'active' : ''; ?>">Test & Quiz</a>
                <a href="../../../valid/payment-processing-app/frontend/index.php" class="<?php echo basename($_SERVER['PHP_SELF']) == 'pricing.php' ? 'active' : ''; ?>">Paiment</a>
        
                <?php if (isset($user['nom_utilisateur'])): ?>
                    <div class="profile-menu">
                    <img src="../../../user/controllers/<?php echo htmlspecialchars($user['pdp'] ?? ''); ?>" alt="Profile Picture" class="profile-pic" style="width: 100px; height: auto;">
                    <div class="dropdown-menu">
                    <a href="../index.php">Voir Profil</a>
                    <a href="../logout.php">Se Déconnecter</a>
                </div>
            </div>
                <?php else: ?>
                    <a href="login.php" class="button">Se connecter</a>
                <?php endif; ?>
            </nav>
        </header>
    <main>

        <h2>Liste des offres d'emploi</h2>
        <button class="filter-toggle" onclick="toggleFilterForm()">Filtrer par</button>
        <form method="GET" action="list_jobs.php" class="filter-form">
            <div class="filter-group">
                <label for="titre">Titre :</label>
                <input type="text" id="titre" name="titre" value="<?php echo htmlspecialchars($titre); ?>">
            </div><br>
            <div class="filter-group">
                <label for="lieu">Lieu :</label>
                <input type="text" id="lieu" name="lieu" value="<?php echo htmlspecialchars($lieu); ?>">
            </div><br>
            <div class="filter-group">
                <label for="salaire">Salaire minimum :</label>
                <input type="number" id="salaire" name="salaire" value="<?php echo htmlspecialchars($salaire); ?>">
            </div><br>
            <div class="filter-group">
                <label for="contrat">Type de contrat :</label>
                <select id="contrat" name="contrat">
                    <option value="">Tous</option>
                    <option value="CDI" <?php if ($contrat == 'CDI') echo 'selected'; ?>>CDI</option>
                    <option value="CDD" <?php if ($contrat == 'CDD') echo 'selected'; ?>>CDD</option>
                    <option value="Stage" <?php if ($contrat == 'Stage') echo 'selected'; ?>>Stage</option>
                    <option value="Freelance" <?php if ($contrat == 'Freelance') echo 'selected'; ?>>Freelance</option>
                </select>
            </div><br>
            <button type="submit" class="button">Filtrer</button>
        </form>
<div id="job"> </div>
        <div class="job-list" id="job-list">
            <?php foreach ($offres as $offre): ?>
                <div class="job-card">
                    <h3 class="job-title"><?php echo htmlspecialchars($offre['titre']); ?></h3>
                    <p class="job-details">
                    <strong>Entreprise:</strong> <?php echo htmlspecialchars($user['nom_utilisateur']); ?><br>
                    <strong>Description:</strong> <?php echo htmlspecialchars($offre['description'] ?? ''); ?><br>
                    <strong>Lieu:</strong> <?php echo htmlspecialchars($offre['adresse'] ?? 'Non spécifié'); ?><br>
                    <a href="../../../offer/job_details.php?id=<?php echo $offre['id']; ?>">Voir les détails</a></p>
                    <div class="actions">
                        <a href="edit_job_view.php?id=<?php echo $offre['id']; ?>">Modifier</a>
                        <a href="../../models/offre_emploi/delete_job.php?id=<?php echo $offre['id']; ?>" class="delete" onclick="return confirm('Êtes-vous sûr de vouloir supprimer cette offre ?');">Supprimer</a>
                        <a href="../../models/offre_emploi/mark_as_completed.php?id=<?php echo $offre['id']; ?>" class="complete" onclick="return confirm('Êtes-vous sûr de vouloir marquer cette offre comme terminée ?');">Offre terminée</a>
                    </div>
                </div>
            <?php endforeach; ?>
        </div>

        <div class="pagination">
            <?php for ($i = 1; $i <= $totalPages; $i++): ?>
                <a href="?page=<?php echo $i; ?>" class="<?php if ($i == $page) echo 'active'; ?>"><?php echo $i; ?></a>
            <?php endfor; ?>
        </div>

        <h2>Historique des offres terminées</h2>
        <div class="job-list" id="job-list">
            <?php
            $query = "SELECT * FROM offres_emploi WHERE user_id = :user_id AND statut = 'terminee'";
            $stmt = $pdo->prepare($query);
            $stmt->execute([':user_id' => $user_id]);
            $offresTerminees = $stmt->fetchAll(PDO::FETCH_ASSOC);

            foreach ($offresTerminees as $offre): ?>
                <div class="job-card">
                    <h3 class="job-title"><?php echo htmlspecialchars($offre['titre']); ?></h3>
                    <p class="job-details">
                        <strong>Description:</strong> <?php echo htmlspecialchars($offre['description'] ?? ''); ?><br>
                        <strong>Lieu:</strong> <?php echo htmlspecialchars($offre['adresse'] ?? 'Non spécifié'); ?><br>
                    </p>
                    <div class="actions">
                    <a href="../../models/offre_emploi/delete_job.php?id=<?php echo $offre['id']; ?>" class="delete" onclick="return confirm('Êtes-vous sûr de vouloir supprimer cette offre ?');">Supprimer</a>

                        <a href="../../models/offre_emploi/reactivate_job.php?id=<?php echo $offre['id']; ?>" class="reactivate" onclick="return confirm('Êtes-vous sûr de vouloir réactiver cette offre ?');">Réactiver</a>
                    </div>
                </div>
            <?php endforeach; ?>
        </div>
    </main>

    <footer>
        <p>Contactez-nous : contact@jobfinder.com</p>
        <p><a href="about.html">À propos</a> | <a href="privacy.html">Politique de confidentialité</a></p>
    </footer>

    <script>
        function toggleFilterForm() {
            const filterForm = document.querySelector('.filter-form');
            filterForm.style.display = filterForm.style.display === 'none' || filterForm.style.display === '' ? 'flex' : 'none';
        }
    </script>
</body>
</html>