<?php
include '../../config/db_connect.php';

function getUserById($pdo, $user_id) {
    $query = "SELECT * FROM users WHERE user_id = :user_id";
    $stmt = $pdo->prepare($query);
    $stmt->execute([':user_id' => $user_id]);
    return $stmt->fetch(PDO::FETCH_ASSOC);
}

function getActiveJobs($pdo, $user_id, $filters, $limit, $offset) {
    $query = "SELECT * FROM offres_emploi WHERE user_id = :user_id AND statut = 'active'";
    $params = [':user_id' => $user_id];

    if (!empty($filters['titre'])) {
        $query .= " AND titre LIKE :titre";
        $params[':titre'] = '%' . $filters['titre'] . '%';
    }
    if (!empty($filters['lieu'])) {
        $query .= " AND lieu_travail LIKE :lieu";
        $params[':lieu'] = '%' . $filters['lieu'] . '%';
    }
    if (!empty($filters['salaire'])) {
        $query .= " AND salaire >= :salaire";
        $params[':salaire'] = (int)$filters['salaire'];
    }
    if (!empty($filters['contrat'])) {
        $query .= " AND contrat = :contrat";
        $params[':contrat'] = $filters['contrat'];
    }

    $query .= " LIMIT $limit OFFSET $offset";
    $stmt = $pdo->prepare($query);
    $stmt->execute($params);
    return $stmt->fetchAll(PDO::FETCH_ASSOC);
}

function getTotalActiveJobs($pdo, $user_id, $filters) {
    $query = "SELECT COUNT(*) FROM offres_emploi WHERE user_id = :user_id AND statut = 'active'";
    $params = [':user_id' => $user_id];

    if (!empty($filters['titre'])) {
        $query .= " AND titre LIKE :titre";
        $params[':titre'] = '%' . $filters['titre'] . '%';
    }
    if (!empty($filters['lieu'])) {
        $query .= " AND lieu_travail LIKE :lieu";
        $params[':lieu'] = '%' . $filters['lieu'] . '%';
    }
    if (!empty($filters['salaire'])) {
        $query .= " AND salaire >= :salaire";
        $params[':salaire'] = (int)$filters['salaire'];
    }
    if (!empty($filters['contrat'])) {
        $query .= " AND contrat = :contrat";
        $params[':contrat'] = $filters['contrat'];
    }

    $stmt = $pdo->prepare($query);
    $stmt->execute($params);
    return $stmt->fetchColumn();
}

function getCompletedJobs($pdo, $user_id) {
    $query = "SELECT * FROM offres_emploi WHERE user_id = :user_id AND statut = 'terminee'";
    $stmt = $pdo->prepare($query);
    $stmt->execute([':user_id' => $user_id]);
    return $stmt->fetchAll(PDO::FETCH_ASSOC);
}