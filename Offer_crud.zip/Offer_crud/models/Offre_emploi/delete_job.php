<!-- filepath: c:\xampp\htdocs\khademni\Offer\delete_job.php -->
<?php
include '../../config/db_connect.php';

$id = $_GET['id'] ?? null;

if ($id) {
    $query = "DELETE FROM offres_emploi WHERE id = :id";
    $stmt = $pdo->prepare($query);
    $stmt->execute([':id' => $id]);
}

header('Location: ../../views/offre_emploi/list_jobs_view.php');
exit;
?>