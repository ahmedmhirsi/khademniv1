<?php
include '../../config/db_connect.php';
session_start();

// Vérifier si l'utilisateur est connecté
$isLoggedIn = isset($_SESSION["user"]) && isset($_SESSION["user"]["user_id"]);

if ($isLoggedIn) {
    $user_id = $_SESSION["user"]["user_id"];
    $query = "SELECT * FROM users WHERE user_id = :user_id";
    $stmt = $pdo->prepare($query);
    $stmt->execute([':user_id' => $user_id]);
    $user = $stmt->fetch(PDO::FETCH_ASSOC);

    $offre_id = $_GET['id'] ?? null;
    if (!$offre_id) {
        die("Erreur : ID de l'offre non transmis.");
    }
}
if ($offre_id) {
    // Mettre à jour le statut de l'offre pour la réactiver
    $query = "UPDATE offres_emploi SET statut = 'active' WHERE id = :id AND user_id = :user_id";
    $stmt = $pdo->prepare($query);
    $stmt->execute([':id' => $offre_id, ':user_id' => $user_id]);

    // Rediriger vers la liste des offres
    header('Location: ../../views/offre_emploi/list_jobs_view.php');
    exit;
} else {
    echo "ID de l'offre manquant.";
}