<?php
include '../../config/db_connect.php';

function getUserById($pdo, $user_id) {
    $query = "SELECT * FROM users WHERE user_id = :user_id";
    $stmt = $pdo->prepare($query);
    $stmt->execute([':user_id' => $user_id]);
    return $stmt->fetch(PDO::FETCH_ASSOC);
}

function addJob($pdo, $data) {
    $query = "INSERT INTO offres_emploi (user_id, titre, description, competences, experience, contrat, salaire, date_limite, nom_entreprise, secteur, adresse, email_contact, telephone, site_web, lieu_travail, horaires, nombre_postes, documents) 
              VALUES (:user_id, :titre, :description, :competences, :experience, :contrat, :salaire, :date_limite, :nom_entreprise, :secteur, :adresse, :email_contact, :telephone, :site_web, :lieu_travail, :horaires, :nombre_postes, :documents)";
    $stmt = $pdo->prepare($query);
    $stmt->execute($data);
}