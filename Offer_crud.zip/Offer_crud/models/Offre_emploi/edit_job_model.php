<?php
include '../../config/db_connect.php';

function getUserById($pdo, $user_id) {
    $query = "SELECT * FROM users WHERE user_id = :user_id";
    $stmt = $pdo->prepare($query);
    $stmt->execute([':user_id' => $user_id]);
    return $stmt->fetch(PDO::FETCH_ASSOC);
}

function getJobById($pdo, $id) {
    $query = "SELECT * FROM offres_emploi WHERE id = :id";
    $stmt = $pdo->prepare($query);
    $stmt->execute([':id' => $id]);
    return $stmt->fetch(PDO::FETCH_ASSOC);
}

function updateJob($pdo, $data) {
    $query = "UPDATE offres_emploi SET 
                titre = :titre, 
                description = :description, 
                competences = :competences, 
                experience = :experience, 
                contrat = :contrat, 
                salaire = :salaire, 
                date_limite = :date_limite, 
                nom_entreprise = :nom_entreprise, 
                secteur = :secteur, 
                adresse = :adresse, 
                email_contact = :email_contact, 
                telephone = :telephone, 
                site_web = :site_web, 
                lieu_travail = :lieu_travail, 
                horaires = :horaires, 
                nombre_postes = :nombre_postes, 
                documents = :documents 
              WHERE id = :id";
    $stmt = $pdo->prepare($query);
    $stmt->execute($data);
}