<?php
include '../../config/db_connect.php';
session_start();

// Vérifier si l'utilisateur est connecté
$isLoggedIn = isset($_SESSION["user"]) && isset($_SESSION["user"]["user_id"]);

if ($isLoggedIn) {
    $user_id = $_SESSION["user"]["user_id"];
    $query = "SELECT * FROM users WHERE user_id = :user_id";
    $stmt = $pdo->prepare($query);
    $stmt->execute([':user_id' => $user_id]);
    $user = $stmt->fetch(PDO::FETCH_ASSOC);

    $offre_id = $_GET['id'] ?? null;
    if (!$offre_id) {
        die("Erreur : ID de l'offre non transmis.");
    }

    if ($offre_id) {
        try {
            // Mettre à jour le statut de l'offre
            $query = "UPDATE offres_emploi SET statut = 'terminee' WHERE id = :id AND user_id = :user_id";
            $stmt = $pdo->prepare($query);
            $stmt->execute([':id' => $offre_id, ':user_id' => $user_id]);

            // Rediriger vers la liste des offres
            header('Location: ../../views/offre_emploi/list_jobs_view.php');
            exit;
        } catch (Exception $e) {
            die("Erreur lors de la mise à jour : " . $e->getMessage());
        }
    } else {
        die("Erreur : ID de l'offre manquant.");
    }
} else {
    die("Erreur : Vous devez être connecté pour effectuer cette action.");
}