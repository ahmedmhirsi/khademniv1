<?php
include '../../models/offre_emploi/edit_job_model.php';
session_start();
if (!isset($_SESSION["user"]) || !isset($_SESSION["user"]["user_id"])) {
    header('Location: ../auth/login.php');
    exit;
}


$user_id = $_SESSION["user"]["user_id"];
$query = "SELECT * FROM users WHERE user_id = :user_id";
$stmt = $pdo->prepare($query);
$stmt->execute([':user_id' => $user_id]);
$user = $stmt->fetch(PDO::FETCH_ASSOC);



$id = $_GET['id'] ?? null;

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $data = [
        ':titre' => $_POST['titre'],
        ':description' => $_POST['description'],
        ':competences' => $_POST['competences'],
        ':experience' => $_POST['experience'],
        ':contrat' => $_POST['contrat'],
        ':salaire' => $_POST['salaire'],
        ':date_limite' => $_POST['date_limite'],
        ':nom_entreprise' => $_POST['nom_entreprise'],
        ':secteur' => $_POST['secteur'],
        ':adresse' => $_POST['adresse'],
        ':email_contact' => $_POST['email_contact'],
        ':telephone' => $_POST['telephone'],
        ':site_web' => $_POST['site_web'],
        ':lieu_travail' => $_POST['lieu_travail'],
        ':horaires' => $_POST['horaires'],
        ':nombre_postes' => $_POST['nombre_postes'],
        ':documents' => implode(', ', $_POST['documents'] ?? []),
        ':id' => $id
    ];

    updateJob($pdo, $data);
    header('Location: ../../views/offre_emploi/list_jobs_view.php');
    exit;
}

$offre = getJobById($pdo, $id);

if (!$offre) {
    die('Offre non trouvée');
}