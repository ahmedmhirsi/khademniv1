<?php
include '../../models/offre_emploi/list_jobs_model.php';
session_start();
if (!isset($_SESSION["user"]) || !isset($_SESSION["user"]["user_id"])) {
    header('Location: ../auth/login.php');
    exit;
}


$user_id = $_SESSION["user"]["user_id"];
$query = "SELECT * FROM users WHERE user_id = :user_id";
$stmt = $pdo->prepare($query);
$stmt->execute([':user_id' => $user_id]);
$user = $stmt->fetch(PDO::FETCH_ASSOC);
$filters = [
    'titre' => $_GET['titre'] ?? '',
    'lieu' => $_GET['lieu'] ?? '',
    'salaire' => $_GET['salaire'] ?? '',
    'contrat' => $_GET['contrat'] ?? ''
];

$page = $_GET['page'] ?? 1;
$limit = 9;
$offset = ($page - 1) * $limit;

$offres = getActiveJobs($pdo, $user_id, $filters, $limit, $offset);
$totalOffres = getTotalActiveJobs($pdo, $user_id, $filters);
$totalPages = ceil($totalOffres / $limit);

$offresTerminees = getCompletedJobs($pdo, $user_id);