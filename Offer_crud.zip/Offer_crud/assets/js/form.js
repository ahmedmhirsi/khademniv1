let currentFieldset = 0;
const fieldsets = document.querySelectorAll('fieldset');

function showFieldset(index) {
    fieldsets.forEach((fieldset, i) => {
        fieldset.style.display = i === index ? 'block' : 'none';
    });
}

function validateFieldset() {
    const fieldset = fieldsets[currentFieldset];
    const inputs = fieldset.querySelectorAll('input[required], textarea[required], select[required]');
    let isValid = true;

    inputs.forEach(input => {
        // Supprimer les anciens messages d'erreur
        const errorMessage = input.nextElementSibling;
        if (errorMessage && errorMessage.classList.contains('error-message')) {
            errorMessage.remove();
        }

        // Validation pour chaque champ
        if (!input.value.trim()) {
            isValid = false;
            input.style.border = '2px solid red'; // Mettre en surbrillance le champ invalide
            addErrorMessage(input, 'Veuillez remplir ce champ.');
        } else {
            input.style.border = ''; // Réinitialiser la bordure si valide

            // Validation spécifique pour certains champs
            if (input.id === 'date_limite') {
                const today = new Date().toISOString().split('T')[0];
                if (input.value <= today) {
                    isValid = false;
                    addErrorMessage(input, 'La date limite doit être supérieure à aujourd\'hui.');
                }
            }

            if (input.id === 'telephone') {
                const phoneRegex = /^[0-9]{8}$/;
                if (!phoneRegex.test(input.value)) {
                    isValid = false;
                    addErrorMessage(input, 'Le numéro de téléphone doit contenir exactement 8 chiffres.');
                }
            }

            if (input.id === 'email_contact') {
                const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
                if (!emailRegex.test(input.value)) {
                    isValid = false;
                    addErrorMessage(input, 'Veuillez entrer une adresse email valide.');
                }
            }
        }
    });

    // Validation pour les checkboxes
    if (fieldset.querySelector('.checkbox-group')) {
        const checkboxes = fieldset.querySelectorAll('.checkbox-group input[type="checkbox"]');
        const isChecked = Array.from(checkboxes).some(checkbox => checkbox.checked);
        if (!isChecked) {
            isValid = false;
            const checkboxGroup = fieldset.querySelector('.checkbox-group');
            addErrorMessage(checkboxGroup, 'Veuillez sélectionner au moins une option.');
        }
    }

    return isValid;
}

function addErrorMessage(element, message) {
    const error = document.createElement('div');
    error.classList.add('error-message');
    error.style.color = 'red';
    error.style.fontSize = '12px';
    error.textContent = message;
    element.parentNode.insertBefore(error, element.nextSibling);
}

function nextFieldset() {
    if (validateFieldset()) {
        if (currentFieldset < fieldsets.length - 1) {
            currentFieldset++;
            showFieldset(currentFieldset);
        }
    }
}

function prevFieldset() {
    if (currentFieldset > 0) {
        currentFieldset--;
        showFieldset(currentFieldset);
    }
}

// Initial display
showFieldset(currentFieldset);