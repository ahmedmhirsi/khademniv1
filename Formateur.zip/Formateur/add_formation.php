<?php
include 'db_connect.php';
session_start();

// Vérifier si l'utilisateur est connecté et est un formateur
if (!isset($_SESSION['user']) || $_SESSION['user']['role'] !== 'formateur') {
    echo "Accès refusé.";
    exit;
}

$formateur_id = $_SESSION['user']['user_id'];

// Récupérer les informations de l'utilisateur connecté
$queryUser = "SELECT * FROM users WHERE user_id = :user_id";
$stmtUser = $pdo->prepare($queryUser);
$stmtUser->execute([':user_id' => $formateur_id]);
$user = $stmtUser->fetch(PDO::FETCH_ASSOC);

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $titre = $_POST['titre'];
    $description = $_POST['description'];
    $competences = $_POST['competences'];
    $localisation = $_POST['localisation'];
    $duree = $_POST['duree'];
    $prix = $_POST['prix'];
    $date_debut = $_POST['date_debut'];
    $date_fin = $_POST['date_fin'];
    $formateur_id = $_SESSION['user']['user_id'];

    $query = "INSERT INTO formations (titre, description, competences, localisation, duree, prix, date_debut, date_fin, formateur_id) 
              VALUES (:titre, :description, :competences, :localisation, :duree, :prix, :date_debut, :date_fin, :formateur_id)";
    $stmt = $pdo->prepare($query);
    $stmt->execute([
        ':titre' => $titre,
        ':description' => $description,
        ':competences' => $competences,
        ':localisation' => $localisation,
        ':duree' => $duree,
        ':prix' => $prix,
        ':date_debut' => $date_debut,
        ':date_fin' => $date_fin,
        ':formateur_id' => $formateur_id
    ]);

    echo "Formation ajoutée avec succès.";
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="forms.css">
    <title>Ajouter une formation</title>
</head>
<body>
<header>
    <div class="logo">Khademni</div>
    <nav>
        <a href="../../../index.php" class="<?php echo basename($_SERVER['PHP_SELF']) == 'index.php' ? 'active' : ''; ?>">Home</a>
        <a href="../../../offer/list_jobs.php" class="<?php echo basename($_SERVER['PHP_SELF']) == 'list_jobs.php' ? 'active' : ''; ?>">Offres d'emploi</a>
        <a href="../../quiz/blog.php" class="<?php echo basename($_SERVER['PHP_SELF']) == 'blog.php' ? 'active' : ''; ?>">Test & Quiz</a>
        <a href="../../paiment/pricing.php" class="<?php echo basename($_SERVER['PHP_SELF']) == 'pricing.php' ? 'active' : ''; ?>">Paiment</a>

        <?php if (!empty($user)): ?>
            <div class="profile-menu">
                <img src="../user/controllers/<?php echo htmlspecialchars($user['pdp'] ?? 'default.png'); ?>" alt="Profile Picture" class="profile-pic" style="width: 100px; height: auto; border-radius: 50%;">
                <div class="dropdown-menu">
                    <a href="../index.php">Voir Profil</a>
                    <a href="../logout.php">Se Déconnecter</a>
                </div>
            </div>
        <?php else: ?>
            <a href="login.php" class="button">Se connecter</a>
        <?php endif; ?>
    </nav>
</header>
<main>
    <fieldset>
        <legend>Ajouter une formation</legend>
        <form method="POST">
            <label for="titre">Titre :</label>
            <input type="text" name="titre" id="titre"><br>

            <label for="description">Description :</label>
            <textarea name="description" id="description"></textarea><br>

            <label for="competences">Compétences (séparées par des virgules) :</label>
            <input type="text" name="competences" id="competences"><br>

            <label for="localisation">Localisation :</label>
            <input type="text" name="localisation" id="localisation"><br>

            <label for="prix">Prix :</label>
            <input type="number" step="0.01" name="prix" id="prix"><br>

            <label for="duree">Durée :</label>
            <input type="text" name="duree" id="duree"><br>

            <label for="date_debut">Date de début :</label>
            <input type="date" name="date_debut" id="date_debut"><br>

            <label for="date_fin">Date de fin :</label>
            <input type="date" name="date_fin" id="date_fin"><br>

            <button type="submit">Ajouter</button>
        </form>
    </fieldset>
</main>
    <script>
    document.addEventListener('DOMContentLoaded', function () {
        const form = document.querySelector('form');
        const fields = [
            { id: 'titre', message: 'Le titre est obligatoire.' },
            { id: 'description', message: 'La description est obligatoire.' },
            { id: 'competences', message: 'Les compétences sont obligatoires.' },
            { id: 'localisation', message: 'La localisation est obligatoire.' },
            { id: 'duree', message: 'La durée doit être un nombre positif.', isNumber: true },
            { id: 'prix', message: 'Le prix doit être un nombre positif.', isNumber: true },
            { id: 'date_debut', message: 'La date de début est obligatoire.' },
            { id: 'date_fin', message: 'La date de fin est obligatoire.' }
        ];

        form.addEventListener('submit', function (e) {
            let isValid = true;

            // Supprimer tous les messages d'erreur existants
            document.querySelectorAll('.error-message').forEach(el => el.remove());

            fields.forEach(field => {
                const input = document.getElementById(field.id);
                const value = input.value.trim();
                let errorMessage = '';

                // Vérification des champs obligatoires
                if (!value) {
                    errorMessage = field.message;
                }

                // Vérification des nombres positifs
                if (field.isNumber && (isNaN(value) || value <= 0)) {
                    errorMessage = field.message;
                }

                // Vérification des dates
                if (field.id === 'date_fin' && value) {
                    const dateDebut = document.getElementById('date_debut').value;
                    if (new Date(dateDebut) > new Date(value)) {
                        errorMessage = 'La date de début doit être antérieure à la date de fin.';
                    }
                }

                // Afficher le message d'erreur si nécessaire
                if (errorMessage) {
                    isValid = false;
                    input.style.borderColor = 'red';

                    // Ajouter un message d'erreur sous le champ
                    const errorElement = document.createElement('div');
                    errorElement.className = 'error-message';
                    errorElement.style.color = 'red';
                    errorElement.style.fontSize = '14px';
                    errorElement.textContent = errorMessage;
                    input.parentNode.insertBefore(errorElement, input.nextSibling);
                } else {
                    input.style.borderColor = '';
                }
            });

            // Validation spécifique : vérifier que la durée correspond à la différence entre les dates
            const dureeInput = document.getElementById('duree');
            const dateDebutInput = document.getElementById('date_debut');
            const dateFinInput = document.getElementById('date_fin');

            if (dateDebutInput.value && dateFinInput.value && dureeInput.value) {
                const dateDebut = new Date(dateDebutInput.value);
                const dateFin = new Date(dateFinInput.value);
                const duree = parseInt(dureeInput.value, 10);

                // Calculer la différence en jours entre les deux dates
                const differenceEnJours = Math.ceil((dateFin - dateDebut) / (1000 * 60 * 60 * 24));

                if (differenceEnJours !== duree) {
                    isValid = false;

                    // Ajouter un message d'erreur sous le champ "Durée"
                    const errorElement = document.createElement('div');
                    errorElement.className = 'error-message';
                    errorElement.style.color = 'red';
                    errorElement.style.fontSize = '14px';
                    errorElement.textContent = `La durée doit correspondre à ${differenceEnJours} jours (calculée à partir des dates).`;
                    dureeInput.parentNode.insertBefore(errorElement, dureeInput.nextSibling);

                    dureeInput.style.borderColor = 'red';
                } else {
                    dureeInput.style.borderColor = '';
                }
            }

            // Empêcher l'envoi du formulaire si invalide
            if (!isValid) {
                e.preventDefault();
            }
        });
    });
</script>
</body>
</html>