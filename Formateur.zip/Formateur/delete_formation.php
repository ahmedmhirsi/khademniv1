<?php
include 'db_connect.php';
session_start();

// Vérifier si l'utilisateur est connecté et est un formateur
if (!isset($_SESSION['user']) || $_SESSION['user']['role'] !== 'formateur') {
    echo "Accès refusé.";
    exit;
}

$formateur_id = $_SESSION['user']['user_id'];
$id = $_GET['id'] ?? null;

if (!$id) {
    echo "Formation introuvable.";
    exit;
}

// Supprimer la formation
$query = "DELETE FROM formations WHERE id = :id AND formateur_id = :formateur_id";
$stmt = $pdo->prepare($query);
$stmt->execute([':id' => $id, ':formateur_id' => $formateur_id]);

header("Location: manage_formations.php");
exit;
?>