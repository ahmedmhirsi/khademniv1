<?php
include '../config/db_connect.php';
include '../controllers/auth_check.php';

// Récupérer les informations de l'utilisateur connecté
$queryUser = "SELECT * FROM users WHERE user_id = :user_id";
$stmtUser = $pdo->prepare($queryUser);
$stmtUser->execute([':user_id' => $formateur_id]);
$user = $stmtUser->fetch(PDO::FETCH_ASSOC);

// Récupérer les formations publiées par le formateur
$query = "SELECT * FROM formations WHERE formateur_id = :formateur_id";
$stmt = $pdo->prepare($query);
$stmt->execute([':formateur_id' => $formateur_id]);
$formations = $stmt->fetchAll(PDO::FETCH_ASSOC);

// Inclure le fichier HTML
include '../views/manage_formations_view.php';