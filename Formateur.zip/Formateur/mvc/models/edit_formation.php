<?php
include '../config/db_connect.php';
session_start();

// Vérifier si l'utilisateur est connecté et est un formateur
if (!isset($_SESSION['user']) || $_SESSION['user']['role'] !== 'formateur') {
    echo "Accès refusé.";
    exit;
}

$formateur_id = $_SESSION['user']['user_id'];
$id = $_GET['id'] ?? null;

if (!$id) {
    echo "Formation introuvable.";
    exit;
}

// Récupérer les détails de la formation
$query = "SELECT * FROM formations WHERE id = :id AND formateur_id = :formateur_id";
$stmt = $pdo->prepare($query);
$stmt->execute([':id' => $id, ':formateur_id' => $formateur_id]);
$formation = $stmt->fetch(PDO::FETCH_ASSOC);

if (!$formation) {
    echo "Formation introuvable ou vous n'avez pas les droits pour la modifier.";
    exit;
}

// Mettre à jour la formation
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $titre = $_POST['titre'];
    $description = $_POST['description'];
    $localisation = $_POST['localisation'];
    $duree = $_POST['duree'];
    $prix = $_POST['prix'];
    $date_debut = $_POST['date_debut'];
    $date_fin = $_POST['date_fin'];

    $query = "UPDATE formations SET titre = :titre, description = :description, localisation = :localisation, duree = :duree, prix = :prix, date_debut = :date_debut, date_fin = :date_fin WHERE id = :id AND formateur_id = :formateur_id";
    $stmt = $pdo->prepare($query);
    $stmt->execute([
        ':titre' => $titre,
        ':description' => $description,
        ':localisation' => $localisation,
        ':duree' => $duree,
        ':prix' => $prix,
        ':date_debut' => $date_debut,
        ':date_fin' => $date_fin,
        ':id' => $id,
        ':formateur_id' => $formateur_id
    ]);

    echo "Formation mise à jour avec succès.";
    header("Location: fetch_formations.php");
    exit;
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <link rel="stylesheet" href="../../forms.css">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Modifier une formation</title>
</head>
<body>
    <main>
    <h1>Modifier une formation</h1>
    <form method="POST">
        <label for="titre">Titre :</label>
        <input type="text" name="titre" id="titre" value="<?php echo htmlspecialchars($formation['titre']); ?>" required><br>

        <label for="description">Description :</label>
        <textarea name="description" id="description" required><?php echo htmlspecialchars($formation['description']); ?></textarea><br>

        <label for="localisation">Localisation :</label>
        <input type="text" name="localisation" id="localisation" value="<?php echo htmlspecialchars($formation['localisation']); ?>" required><br>

        <label for="duree">Durée :</label>
        <input type="text" name="duree" id="duree" value="<?php echo htmlspecialchars($formation['duree']); ?>" required><br>

        <label for="prix">Prix :</label>
        <input type="number" step="0.01" name="prix" id="prix" value="<?php echo htmlspecialchars($formation['prix']); ?>" required><br>

        <label for="date_debut">Date de début :</label>
        <input type="date" name="date_debut" id="date_debut" value="<?php echo htmlspecialchars($formation['date_debut']); ?>" required><br>

        <label for="date_fin">Date de fin :</label>
        <input type="date" name="date_fin" id="date_fin" value="<?php echo htmlspecialchars($formation['date_fin']); ?>" required><br>

        <button type="submit">Mettre à jour</button>
    </form></main>
</body>
</html>