<?php
include '../config/db_connect.php';
session_start();

// Vérifier si l'utilisateur est connecté et est un formateur
if (!isset($_SESSION['user']) || $_SESSION['user']['role'] !== 'formateur') {
    echo "Accès refusé.";
    exit;
}

$formateur_id = $_SESSION['user']['user_id'];

// Récupérer les informations de l'utilisateur connecté
$queryUser = "SELECT * FROM users WHERE user_id = :user_id";
$stmtUser = $pdo->prepare($queryUser);
$stmtUser->execute([':user_id' => $formateur_id]);
$user = $stmtUser->fetch(PDO::FETCH_ASSOC);

// Inclure le formulaire HTML
include '../views/add_formation_form.php';
?>