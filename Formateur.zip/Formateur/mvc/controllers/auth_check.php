<?php
session_start();

// Vérifier si l'utilisateur est connecté et est un formateur
if (!isset($_SESSION['user']) || $_SESSION['user']['role'] !== 'formateur') {
    echo "Accès refusé.";
    exit;
}

$formateur_id = $_SESSION['user']['user_id'];