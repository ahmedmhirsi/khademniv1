<?php
include '../config/db_connect.php';
session_start();

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Vérifier si l'utilisateur est connecté et est un formateur
    if (!isset($_SESSION['user']) || $_SESSION['user']['role'] !== 'formateur') {
        echo "Accès refusé.";
        exit;
    }

    $formateur_id = $_SESSION['user']['user_id'];

    // Récupérer les données du formulaire
    $titre = $_POST['titre'];
    $description = $_POST['description'];
    $competences = $_POST['competences'];
    $localisation = $_POST['localisation'];
    $duree = $_POST['duree'];
    $prix = $_POST['prix'];
    $date_debut = $_POST['date_debut'];
    $date_fin = $_POST['date_fin'];

    // Insérer les données dans la base de données
    $query = "INSERT INTO formations (titre, description, competences, localisation, duree, prix, date_debut, date_fin, formateur_id) 
              VALUES (:titre, :description, :competences, :localisation, :duree, :prix, :date_debut, :date_fin, :formateur_id)";
    $stmt = $pdo->prepare($query);
    $stmt->execute([
        ':titre' => $titre,
        ':description' => $description,
        ':competences' => $competences,
        ':localisation' => $localisation,
        ':duree' => $duree,
        ':prix' => $prix,
        ':date_debut' => $date_debut,
        ':date_fin' => $date_fin,
        ':formateur_id' => $formateur_id
    ]);

    echo "Formation ajoutée avec succès.";
}
?>