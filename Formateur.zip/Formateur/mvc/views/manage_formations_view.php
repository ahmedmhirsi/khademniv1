<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="../../styles.css">
    <link href="../icon.png" rel="icon">
    <title>Liste des formations</title>
</head>
<body>
<header>
    <div class="logo">Khademni</div>
    <nav>
        <a href="../../../index.php" class="<?php echo basename($_SERVER['PHP_SELF']) == 'index.php' ? 'active' : ''; ?>">Home</a>
        <a href="../../../offer/list_jobs.php" class="<?php echo basename($_SERVER['PHP_SELF']) == 'list_jobs.php' ? 'active' : ''; ?>">Offres d'emploi</a>
        <a href="../../quiz/blog.php" class="<?php echo basename($_SERVER['PHP_SELF']) == 'blog.php' ? 'active' : ''; ?>">Test & Quiz</a>
        <a href="../../paiment/pricing.php" class="<?php echo basename($_SERVER['PHP_SELF']) == 'pricing.php' ? 'active' : ''; ?>">Paiment</a>

        <?php if (!empty($user)): ?>
            <div class="profile-menu">
                <img src="../../../user/controllers/<?php echo htmlspecialchars($user['pdp'] ?? 'default.png'); ?>" alt="Profile Picture" class="profile-pic" style="width: 100px; height: auto; border-radius: 50%;">
                <div class="dropdown-menu">
                    <a href="../index.php">Voir Profil</a>
                    <a href="../logout.php">Se Déconnecter</a>
                </div>
            </div>
        <?php else: ?>
            <a href="login.php" class="button">Se connecter</a>
        <?php endif; ?>
    </nav>
</header>
<main>
    <h2>Liste des formations publiées</h2>

    <div class="job-list" id="job-list">
        <?php if (!empty($formations)): ?>
            <?php foreach ($formations as $formation): ?>
                <div class="job-card">
                    <h3 class="job-title"><?php echo htmlspecialchars($formation['titre']); ?></h3>
                    <p class="job-details">
                        <strong>Description:</strong> <?php echo htmlspecialchars($formation['description'] ?? ''); ?><br>
                        <strong>Localisation:</strong> <?php echo htmlspecialchars($formation['localisation'] ?? 'Non spécifiée'); ?><br>
                        <strong>Durée:</strong> <?php echo htmlspecialchars($formation['duree'] ?? 'Non spécifiée'); ?><br>
                        <strong>Prix:</strong> <?php echo htmlspecialchars($formation['prix']); ?> TND<br>
                        <strong>Date de début:</strong> <?php echo htmlspecialchars($formation['date_debut']); ?><br>
                        <strong>Date de fin:</strong> <?php echo htmlspecialchars($formation['date_fin']); ?><br>
                    </p>
                    <div class="actions">
                        <a href="edit_formation.php?id=<?php echo $formation['id']; ?>">Modifier</a>
                        <a href="delete_formation.php?id=<?php echo $formation['id']; ?>" class="delete" onclick="return confirm('Êtes-vous sûr de vouloir supprimer cette formation ?');">Supprimer</a>
                    </div>
                </div>
            <?php endforeach; ?>
        <?php else: ?>
            <p>Vous n'avez publié aucune formation pour le moment.</p>
        <?php endif; ?>
    </div>
</main>

<footer>
    <p>Contactez-nous : contact@jobfinder.com</p>
    <p><a href="about.html">À propos</a> | <a href="privacy.html">Politique de confidentialité</a></p>
</footer>
</body>
</html>