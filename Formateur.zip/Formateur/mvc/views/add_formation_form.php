<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="forms.css">
    <title>Ajouter une formation</title>
</head>
<body>
<header>
    <div class="logo">Khademni</div>
    <nav>
        <a href="../../../index.php">Home</a>
        <a href="../../../offer/list_jobs.php">Offres d'emploi</a>
        <a href="../../quiz/blog.php">Test & Quiz</a>
        <a href="../../paiment/pricing.php">Paiment</a>
    </nav>
</header>
<main>
    <fieldset>
        <legend>Ajouter une formation</legend>
        <form method="POST" action="process_formation.php">
            <label for="titre">Titre :</label>
            <input type="text" name="titre" id="titre"><br>

            <label for="description">Description :</label>
            <textarea name="description" id="description"></textarea><br>

            <label for="competences">Compétences (séparées par des virgules) :</label>
            <input type="text" name="competences" id="competences"><br>

            <label for="localisation">Localisation :</label>
            <input type="text" name="localisation" id="localisation"><br>

            <label for="prix">Prix :</label>
            <input type="number" step="0.01" name="prix" id="prix"><br>

            <label for="duree">Durée :</label>
            <input type="text" name="duree" id="duree"><br>

            <label for="date_debut">Date de début :</label>
            <input type="date" name="date_debut" id="date_debut"><br>

            <label for="date_fin">Date de fin :</label>
            <input type="date" name="date_fin" id="date_fin"><br>

            <button type="submit">Ajouter</button>
        </form>
    </fieldset>
</main>
</body>
</html>